SimBoolNet Package

SimBoolNet is a Cytoscape Plugin for simulation of cellular signaling pathways.
This package contains the following files:

1. "SimBoolNet.jar" and "SimBoolNet_lib.jar": Executable components (to be copied to Cytoscape plugins directory)
2. "SimBoolNet_manual.doc": User manual
3. "test_data": A folder consisting of a text file with a network example and a .cys session file
4. "source_code": Java source code of SimBoolNet.

To use SimBoolNet, please follow instructions in the user manual.

Please note that both "SimBoolNet.jar" and "SimBoolNet_lib.jar" should be copied to Cytoscape plugins folder.
 
