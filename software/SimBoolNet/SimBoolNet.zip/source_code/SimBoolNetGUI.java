package simboolnet;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
//import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.Paint;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
//import java.io.BufferedInputStream;
import java.io.BufferedWriter;
//import java.io.DataInputStream;
//import java.io.FileInputStream;
//import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.File;
//import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;
import java.util.Set;
import java.util.Stack;
import java.util.TreeSet;

import javax.swing.Box;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSlider;
import javax.swing.JSpinner;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.SpinnerNumberModel;
import javax.swing.SwingConstants;
import javax.swing.Timer;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.plot.DrawingSupplier;
import org.jfree.chart.plot.Plot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.StandardXYItemRenderer;
import org.jfree.chart.renderer.xy.XYItemRenderer;
import org.jfree.data.xy.XYDataset;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;

import cytoscape.Cytoscape;
import cytoscape.task.Task;
import cytoscape.task.TaskMonitor;
import cytoscape.task.ui.JTaskConfig;
import cytoscape.task.util.TaskManager;
import cytoscape.view.CytoscapeDesktop;
import cytoscape.view.cytopanels.CytoPanelImp;
import cytoscape.visual.ArrowShape;
import cytoscape.visual.VisualPropertyType;
import cytoscape.visual.VisualStyle;
import cytoscape.visual.calculators.BasicCalculator;
import cytoscape.visual.calculators.Calculator;
import cytoscape.visual.mappings.BoundaryRangeValues;
import cytoscape.visual.mappings.ContinuousMapping;
import cytoscape.visual.mappings.DiscreteMapping;
import cytoscape.visual.mappings.Interpolator;
import cytoscape.visual.mappings.LinearNumberToColorInterpolator;
import cytoscape.visual.mappings.LinearNumberToNumberInterpolator;
import cytoscape.visual.mappings.ObjectMapping;
import cytoscape.data.Semantics;

public class SimBoolNetGUI extends JPanel implements ActionListener, PropertyChangeListener, ChangeListener{
	private Timer timer = new Timer(100, this);
	private JButton startButton = new JButton("Run Single Simulation"),
			stopButton = new JButton("Stop Simulation"),
			pauseButton = new JButton("Pause Simulation"),
			resumeButton = new JButton("Resume Simulation"),
			batchButton = new JButton("Run Batch Simulation"),
			weightButton = new JButton("Set Edge Weights"),		
			timeActButton = new JButton("Plot single simulation results"),
			batchRegressButton = new JButton("Plot batch simulation results");
	
	
	private JSlider batchSlider = new JSlider(0, 100, SimBoolNetMain.getBatchStep());
	private JTextField batchTextField = new JTextField(Double.toString(batchSlider.getValue()/100.0), 3);
	private JSpinner stepSpinner = new JSpinner(new SpinnerNumberModel(SimBoolNetMain.getNumSteps(), 1, 999, 1));
	private JPanel mainPanel = new JPanel(new BorderLayout());
	private JFileChooser fc = new JFileChooser();
	
	private int time = 0;
	private String lastRunTime = "";
	private String lastVisStyle = "";
	
	// This is to address a bug with having multiple network views and buttons being enabled. 
	private Stack<String> networks = new Stack<String>();
	
	// Constants for visual style.
	private final Color MIN_COLOR = Color.LIGHT_GRAY, 
						MAX_COLOR = Color.RED;
	private final String VIS_STYLE = "SimBoolNet";
	private final Object DEF_OBJ_NODE_COLOR = VisualPropertyType.NODE_FILL_COLOR
						 		.getDefault(Cytoscape.getVisualMappingManager().getVisualStyle()),
						 DEF_OBJ_EDGE_WIDTH = VisualPropertyType.EDGE_LINE_WIDTH
						 		.getDefault(Cytoscape.getVisualMappingManager().getVisualStyle()),
						 DEF_OBJ_EDGE_ARROW = VisualPropertyType.EDGE_TGTARROW_SHAPE
						 		.getDefault(Cytoscape.getVisualMappingManager().getVisualStyle());
	
	// This is so that check boxes that are checked will remain checked.
	private final String CHECKED_ATTR = "checked";
	
	// This is the label table for sliders.
	private Hashtable<Integer, JLabel> sliderLabels = new Hashtable<Integer, JLabel>();
	
	private Map<String, ArrayList<Double>> nodeAct = new HashMap<String, ArrayList<Double>>();		
	BatchSim batchSim;
	
	public SimBoolNetGUI(){
		Cytoscape.getDesktop().getSwingPropertyChangeSupport().addPropertyChangeListener(this);
		((CytoPanelImp) Cytoscape.getDesktop().getCytoPanel(SwingConstants.SOUTH)).add("SimBoolNet", this);

		//Set up labels.
		for (int i = 0; i <= 100; i += 25){
			sliderLabels.put(i, new JLabel(Double.toString(i/100.0)));
		}
		
		JPanel northPanel = new JPanel(new BorderLayout()),
			   southPanel = new JPanel(new BorderLayout()),
			   northeastPanel = new JPanel(new BorderLayout()),
			   stepsPanel = new JPanel(new BorderLayout()),
			   batchPanel = new JPanel(new BorderLayout()),
			   batchSliderPanel = new JPanel(),
			   weightPanel = new JPanel(),
			   startButtonPanel = new JPanel(),
			   batchButtonPanel = new JPanel(),		   
			   plotPanel = new JPanel(); 
			
		
		// Initialize buttons.
		startButton.setEnabled(false);
		startButton.addActionListener(this);
		stopButton.setEnabled(false);
		stopButton.addActionListener(this);
		pauseButton.setEnabled(false);
		pauseButton.addActionListener(this);
		resumeButton.setEnabled(false);
		resumeButton.addActionListener(this);
		weightButton.addActionListener(this);
		weightButton.setEnabled(false);
		batchButton.addActionListener(this);
		batchButton.setEnabled(false);		
		
		timeActButton.setEnabled(false);
		timeActButton.addActionListener(this);
		batchRegressButton.setEnabled(false);
		batchRegressButton.addActionListener(this);
		
				
		// Initialize spinner. 
		stepSpinner.addChangeListener(this);
		stepSpinner.setEnabled(false);
		
		// Initialize slider (and text field).
		batchSlider.setMajorTickSpacing(25);
		batchSlider.setMinorTickSpacing(5);
		batchSlider.setPaintTicks(true);
		batchSlider.setPaintLabels(true);
		batchSlider.setLabelTable(sliderLabels);
		batchSlider.addChangeListener(this);
		batchSlider.setEnabled(false);
		batchTextField.setHorizontalAlignment(JTextField.RIGHT);
		batchTextField.setEditable(false);
		
		// Add things to panels.
		weightPanel.add(weightButton);
		stepsPanel.add(new JLabel("Iterations per Simulation:"), BorderLayout.WEST);
		stepsPanel.add(stepSpinner, BorderLayout.EAST);
		batchPanel.add(new JLabel("<html>Input Node Increment:<br/>(Batch Simulation)</html>"), BorderLayout.WEST);
		batchSliderPanel.add(batchTextField);
		batchSliderPanel.add(batchSlider);
		batchPanel.add(batchSliderPanel, BorderLayout.EAST);
		

		northeastPanel.add(weightPanel, BorderLayout.NORTH);
		northeastPanel.add(stepsPanel, BorderLayout.CENTER);
		northeastPanel.add(batchPanel, BorderLayout.SOUTH);
		northPanel.add(new JLabel("<html><b><u>Initialize:</u></b></html>"), BorderLayout.NORTH);
		northPanel.add(northeastPanel, BorderLayout.EAST);
		
		startButtonPanel.add(startButton);
		batchButtonPanel.add(batchButton);
		southPanel.add(new JLabel("<html><b><u>Simulate:</u></b></html>"), BorderLayout.NORTH);
		southPanel.add(startButtonPanel, BorderLayout.CENTER);
		southPanel.add(batchButtonPanel, BorderLayout.EAST);		

		plotPanel.add(timeActButton); 
		plotPanel.add(batchRegressButton);
		southPanel.add(plotPanel, BorderLayout.AFTER_LAST_LINE);
		
		mainPanel.add(northPanel, BorderLayout.NORTH);
		mainPanel.add(southPanel, BorderLayout.SOUTH);
		add(mainPanel);
		
		//initVisStyle();
	}

	/*---------------------------------------Visual Style Methods---------------------------------------*/

	/**
	 * Set up the visual style.
	 */
	private void initVisStyle(){
		// If style already exists, remove it.
		if (Cytoscape.getVisualMappingManager().getCalculatorCatalog().getVisualStyleNames().contains(VIS_STYLE))
			Cytoscape.getVisualMappingManager().getCalculatorCatalog().removeVisualStyle(VIS_STYLE);

		// Create new style.
		VisualStyle vs = new VisualStyle(Cytoscape.getVisualMappingManager().getVisualStyle(), VIS_STYLE);
		vs.getNodeAppearanceCalculator().getDefaultAppearance().set(VisualPropertyType.NODE_FONT_SIZE, 22);
		vs.getEdgeAppearanceCalculator().getDefaultAppearance().set(VisualPropertyType.EDGE_COLOR, Color.BLACK);
		vs.getEdgeAppearanceCalculator().setCalculator(createWidthCalc());
		vs.getEdgeAppearanceCalculator().setCalculator(createArrowCalc());
		vs.getNodeAppearanceCalculator().setCalculator(createColorCalc());
		Cytoscape.getVisualMappingManager().getCalculatorCatalog().addVisualStyle(vs);
	}

	/**
	 * Creates a calculator for edge width based on the weight of the edge.
	 * @return The new calculator.
	 */
	private Calculator createWidthCalc(){
		// Set up the mapping.
		ContinuousMapping cm = new ContinuousMapping(DEF_OBJ_EDGE_WIDTH, ObjectMapping.EDGE_MAPPING);
		cm.setControllingAttributeName(SimBoolNetMain.getWeightAttr(), Cytoscape.getCurrentNetwork(), false);

		Interpolator numToWidth = new LinearNumberToNumberInterpolator();
		cm.setInterpolator(numToWidth);

		BoundaryRangeValues bv0 = new BoundaryRangeValues(0.0, 0.0, 0.0);
		BoundaryRangeValues bv1 = new BoundaryRangeValues(5.0, 5.0, 5.0);

		cm.addPoint(0.0, bv0);
		cm.addPoint(1.0, bv1);

		return new BasicCalculator("Width calculator", cm, VisualPropertyType.EDGE_LINE_WIDTH);
	}

	/**
	 * Creates a calculator for the edge arrow type based on the interaction of the edge.
	 * Arrow shape for activate and T shape for block.
	 * @return The new calculator.
	 */
	private Calculator createArrowCalc(){
		// Set up the mapping
		DiscreteMapping dm = new DiscreteMapping(DEF_OBJ_EDGE_ARROW, ObjectMapping.EDGE_MAPPING);
		dm.setControllingAttributeName(Semantics.INTERACTION, Cytoscape.getCurrentNetwork(), false);

		dm.putMapValue(SimBoolNetMain.getActivateInter(), ArrowShape.ARROW);
		dm.putMapValue(SimBoolNetMain.getBlockInter(), ArrowShape.T);

		// Create a calculator
		return new BasicCalculator("Arrow calculator", dm, VisualPropertyType.EDGE_TGTARROW_SHAPE);
	}

	/**
	 * Create a new calculator for the node color based on the activity level of the node.
	 * @return The new calculator.
	 */
	private Calculator createColorCalc() {
		// Set up the mapping.
		ContinuousMapping cm = new ContinuousMapping(DEF_OBJ_NODE_COLOR, ObjectMapping.NODE_MAPPING);
		cm.setControllingAttributeName(SimBoolNetMain.getActivityAttr(), Cytoscape.getCurrentNetwork(), false);

		Interpolator numToColor = new LinearNumberToColorInterpolator();
		
		//String t = numToColor.toString();
		
		cm.setInterpolator(numToColor);

		BoundaryRangeValues bv0 = new BoundaryRangeValues(MIN_COLOR, MIN_COLOR,	MIN_COLOR);
		BoundaryRangeValues bv2 = new BoundaryRangeValues(MAX_COLOR, MAX_COLOR,	MAX_COLOR);

		cm.addPoint(0, bv0);
		cm.addPoint(SimBoolNetMain.getNumSteps(), bv2);

		return new BasicCalculator("Activity calculator", cm, VisualPropertyType.NODE_FILL_COLOR);
	}

	/*---------------------------------------Listener Methods---------------------------------------*/

	public void actionPerformed(ActionEvent e) {
		Object src = e.getSource();

		// Timer
		if (src == timer){
			SimBoolNetMain.nextState();
			Cytoscape.firePropertyChange(Cytoscape.ATTRIBUTES_CHANGED, null, null);
			
			// record time-series of node activities			
			String[] nodeArray = SimBoolNetMain.getNodes();
			for (String myNode : nodeArray) {
				recordNodeAct(myNode, 0.01 * SimBoolNetMain.getNodeActivity(myNode));				
			}						
			
			time++;
			if (time == SimBoolNetMain.getNumSteps()){ // finish
				timer.stop();
				time = 0;
				
				lastRunTime = new SimpleDateFormat().format(new Date());
				if (JOptionPane.showConfirmDialog(Cytoscape.getDesktop(), "Would you like to view results?",
					"Simulation Complete", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION)
					new ResultsDialog().displayResults();
				
				//SimBoolNetMain.reset(); 
				//Cytoscape.getVisualMappingManager().setVisualStyle(lastVisStyle);
				//Cytoscape.getCurrentNetworkView().setVisualStyle(lastVisStyle);
				//Cytoscape.firePropertyChange(Cytoscape.ATTRIBUTES_CHANGED, null, null);
				
				removeAll();
				add(mainPanel);
				revalidate();
				repaint();
			}
			return;
		}

		// Buttons
		else if (src == startButton){
			if (new InputDialog().selectInput()){
				removeAll();
				add(stopButton);
				add(pauseButton);
				revalidate();
				repaint();

				lastVisStyle = Cytoscape.getVisualMappingManager().getVisualStyle().getName();
				Cytoscape.getVisualMappingManager().setVisualStyle(VIS_STYLE);
				Cytoscape.getCurrentNetworkView().setVisualStyle(VIS_STYLE);
				
				// remove previous records of node activities
				SimBoolNetMain.reset();	
				nodeAct.clear();
				
				timer.start();
			}
		} 
		else if (src == stopButton){
			removeAll();
			add(mainPanel);
			revalidate();
			repaint();
			
			SimBoolNetMain.reset();
			Cytoscape.getVisualMappingManager().setVisualStyle(lastVisStyle);
			Cytoscape.getCurrentNetworkView().setVisualStyle(lastVisStyle);
			Cytoscape.firePropertyChange(Cytoscape.ATTRIBUTES_CHANGED, null, null);
			time = 0;

			timer.stop();
		} 
		else if (src == pauseButton){
			remove(pauseButton);
			add(resumeButton);
			revalidate();
			repaint();

			timer.stop();
		} 
		else if (src == resumeButton){
			remove(resumeButton);
			add(pauseButton);
			revalidate();
			repaint();
			
			timer.start();
		}
		else if (src == weightButton){
			new WeightDialog().setWeights();
			initVisStyle();
			
		}
		else if (src == batchButton){
			// Since a batch simulation takes a while (exponential time based on input size), 
			// set it up as a task with a progress bar.
			JTaskConfig jTaskConfig = new JTaskConfig();
			jTaskConfig.setOwner(Cytoscape.getDesktop());
			jTaskConfig.displayCloseButton(false);
			jTaskConfig.displayCancelButton(true);
			jTaskConfig.displayStatus(true);
			jTaskConfig.setAutoDispose(true);
			
			batchSim = new BatchSim();
			if (batchSim.getInputOutput()){
				TaskManager.executeTask(batchSim, jTaskConfig);
				batchSim.displayResults();
			}
		}
		else if (src == timeActButton) {
			if (nodeAct.isEmpty()) {
				JOptionPane.showMessageDialog(null, 
						"Please do a single simulation first.", "No Result Found", 
						JOptionPane.PLAIN_MESSAGE);
				return;
			}
			//pop up a JFrame to plot node activities time-series						
			SimuMovie simuMovie = new SimuMovie(nodeAct);			
			simuMovie.setSize(450, 400);
			simuMovie.setVisible(true);
		}		
		else if (src == batchRegressButton) {
			//if (batchSim == null) {
			if (batchSim == null || batchSim.isEmpty()) {
				JOptionPane.showMessageDialog(null, 
						"Please do a batch simulation first.", "No Result Found", 
						JOptionPane.PLAIN_MESSAGE);
				return;
			}					
			DefaultTableModel batchResult = batchSim.getResultsTable();
			String [] inputNodes = batchSim.getInputNodes();
			String[] outputNodes = batchSim.getOutputNodds();
			// sort lists of nodes alphabetically
			Arrays.sort(inputNodes, new AlphabeticComparator());
			Arrays.sort(outputNodes, new AlphabeticComparator());
			
			BatchRegressFrame batchFrame = new BatchRegressFrame(batchResult, inputNodes, outputNodes);
			batchFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
			batchFrame.setSize(450, 500);
			batchFrame.setVisible(true);			
		}
	}
	
	private void recordNodeAct(String node, double nodeActivity) {
		if (! nodeAct.containsKey(node)) {
			nodeAct.put(node, new ArrayList<Double>());
		}
		nodeAct.get(node).add(nodeActivity);		
	}

	public void stateChanged(ChangeEvent e) {
		Object src = e.getSource();
		
		if (src == stepSpinner){
			SimBoolNetMain.setNumSteps((Integer) ((JSpinner) stepSpinner).getValue());
			initVisStyle();
		}
		else if (src == batchSlider){
			batchTextField.setText(Double.toString(((JSlider) batchSlider).getValue()/100.0));
			SimBoolNetMain.setBatchStep(((JSlider) batchSlider).getValue());
		}
	}

	public void propertyChange(PropertyChangeEvent e){
		// Makes sure buttons and batch simulation are only enabled when a network view is open.
		if (e.getPropertyName().equals(CytoscapeDesktop.NETWORK_VIEW_CREATED)){		
			String name = Cytoscape.getCurrentNetworkView().getIdentifier();
			networks.push(name);
			
			initVisStyle();
			startButton.setEnabled(true);
			stopButton.setEnabled(true);
			pauseButton.setEnabled(true);
			resumeButton.setEnabled(true);
			batchButton.setEnabled(true);
			weightButton.setEnabled(true);
			batchSlider.setEnabled(true);
			stepSpinner.setEnabled(true);
			
			timeActButton.setEnabled(true);
			batchRegressButton.setEnabled(true);
		}
		if (e.getPropertyName().equals(CytoscapeDesktop.NETWORK_VIEW_DESTROYED)){
			networks.remove(Cytoscape.getCurrentNetworkView().getIdentifier());
			
			// If other network views are open, keep all buttons enabled.
			if (!networks.isEmpty()){
				Cytoscape.setCurrentNetwork(networks.peek());
				return;
			}
			
			startButton.setEnabled(false);
			stopButton.setEnabled(false);
			pauseButton.setEnabled(false);
			resumeButton.setEnabled(false);
			batchButton.setEnabled(false);
			weightButton.setEnabled(false);
			batchSlider.setEnabled(false);
			stepSpinner.setEnabled(false);
			
			timeActButton.setEnabled(false);
			batchRegressButton.setEnabled(false);
		}
	}

	/*---------------------------------------Input selection class---------------------------------------*/
	
	private class InputDialog implements ActionListener, ListSelectionListener,	MouseListener, ChangeListener{
		private JPanel inputPanel = new JPanel(new BorderLayout());
		private DefaultListModel availableListModel = new DefaultListModel(),
								 inputListModel = new DefaultListModel();
		private JList availableList = new JList(availableListModel),
					  inputList = new JList(inputListModel);
		private JButton addButton = new JButton("->"),
						removeButton = new JButton("<-"),
						selectButton = new JButton("Select all"),
						deselectButton = new JButton("Deselect all");
		private JSlider inputSlider = new JSlider(0, 100, 100);
		private JTextField inputTextField = new JTextField("1.0", 4); // level of all selected nodes in bottom panel
		private Map<String, JTextField> textFields = new HashMap<String, JTextField>();
		private Map<String, JSlider> sliders = new HashMap<String, JSlider>();
		private Map<String, JCheckBox> checkBoxes = new HashMap<String, JCheckBox>();

		private int modifierHeight = 0;
		private boolean allChanging = false;

		private InputDialog(){			
			// Initialize Lists
			availableList.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
			availableList.setVisibleRowCount(10);
			availableList.addListSelectionListener(this);
			availableList.addMouseListener(this);
			inputList.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
			inputList.setVisibleRowCount(10);
			inputList.addListSelectionListener(this);
			inputList.addMouseListener(this);

			// Set initial lists of nodes.
			String[] nodes = SimBoolNetMain.getNodes(), 
					 inputNodes = SimBoolNetMain.getInputNodes();
			for (String node : nodes)
				availableListModel.addElement(node);
			for (String node : inputNodes){
				availableListModel.removeElement(node);
				inputListModel.addElement(node);
			}

			// Initialize buttons
			addButton.setEnabled(false);
			addButton.addActionListener(this);
			removeButton.setEnabled(false);
			removeButton.addActionListener(this);
			selectButton.addActionListener(this);
			deselectButton.addActionListener(this);
			
			// Initialize slider
			inputSlider.setMajorTickSpacing(25);
			inputSlider.setMinorTickSpacing(5);
			inputSlider.setPaintTicks(true);
			inputSlider.setPaintLabels(true);
			inputSlider.setLabelTable(sliderLabels);
			inputSlider.addChangeListener(this);
			
			// Initialize text field
			inputTextField.setHorizontalAlignment(JTextField.RIGHT);
			inputTextField.setEditable(false);

			// Create panels for the components.
			JPanel buttonPanel = new JPanel(new BorderLayout()),
				   addButtonPanel = new JPanel(),
				   removeButtonPanel = new JPanel();
			addButtonPanel.add(addButton);
			removeButtonPanel.add(removeButton);
			buttonPanel.add(addButtonPanel, BorderLayout.NORTH);
			buttonPanel.add(removeButtonPanel, BorderLayout.SOUTH);

			// Initialize scroll panes.
			JScrollPane scroll1 = new JScrollPane(availableList);
			JScrollPane scroll2 = new JScrollPane(inputList);

			// To keep the list sizes consistent.
			if (availableListModel.isEmpty()){
				scroll1.setPreferredSize(scroll2.getPreferredSize());
				scroll2.setPreferredSize(scroll1.getPreferredSize());
			} 
			else if (inputListModel.isEmpty()){
				scroll2.setPreferredSize(scroll1.getPreferredSize());
				scroll1.setPreferredSize(scroll2.getPreferredSize());
			} 
			else if (scroll1.getPreferredSize().getWidth() < scroll2.getPreferredSize().getWidth()){
				scroll1.setPreferredSize(scroll2.getPreferredSize());
				scroll2.setPreferredSize(scroll1.getPreferredSize());
			} 
			else if (scroll2.getPreferredSize().getWidth() < scroll1.getPreferredSize().getWidth()){
				scroll2.setPreferredSize(scroll1.getPreferredSize());
				scroll1.setPreferredSize(scroll2.getPreferredSize());
			}

			// Add the components.
			inputPanel.add(scroll1, BorderLayout.WEST);
			inputPanel.add(scroll2, BorderLayout.EAST);
			inputPanel.add(buttonPanel, BorderLayout.CENTER);
		}

		/**
		 * Shows the dialogs for selecting input nodes and levels.
		 * @return true if the user completes the dialogs, false otherwise.
		 */
		private boolean selectInput(){
			// Choose input nodes.
			if (JOptionPane.showConfirmDialog(Cytoscape.getDesktop(), inputPanel, "Select Input Node(s)",
				JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE) == JOptionPane.OK_OPTION){
				Object[] selection = inputListModel.toArray();
	
				// If no input nodes were selected.
				if (selection.length == 0){
					if (JOptionPane.showConfirmDialog(Cytoscape.getDesktop(), 
						"Please select at least one input node.", "No Input Nodes Selected", 
						JOptionPane.OK_CANCEL_OPTION, JOptionPane.ERROR_MESSAGE) == JOptionPane.OK_OPTION)
						return selectInput();
					else
						return false;
				}
				
				String[] inputNodes = new String[selection.length];
				JPanel editorPanel = new JPanel(new BorderLayout()),
					   modifierPanel = new JPanel(new GridLayout(inputNodes.length,	1)),
					   inputPanel = new JPanel(new BorderLayout()),
					   inputSliderPanel = new JPanel();
	
				// Set up list of input nodes for choosing input levels.
				for (int i = 0; i < inputNodes.length; i++){
					inputNodes[i] = selection[i].toString();
					modifierPanel.add(addModifier(inputNodes[i]));
				}
	
				// In order to keep the dialog a reasonable size, set up a scroll
				// pane if too many input nodes (5)
				// are selected.
				JScrollPane scroll = new JScrollPane(modifierPanel);
				if (inputNodes.length > 5)
					scroll.setPreferredSize(new Dimension((int) (scroll.getPreferredSize().getWidth() + 
						scroll.getVerticalScrollBar().getPreferredSize().getWidth()), modifierHeight * 5));
	
				// Set up bottom panel.
				inputPanel.add(new JLabel("Modify all selected nodes:"), BorderLayout.WEST);
				inputSliderPanel.add(inputTextField);
				
				// for debug
				//String t = inputTextField.getText();
				//System.out.println(t);
				//---------------
				
				inputSliderPanel.add(inputSlider);
				inputPanel.add(inputSliderPanel, BorderLayout.EAST);
				
				// Put everything into final panel.
				editorPanel.add(scroll, BorderLayout.NORTH);
				editorPanel.add(selectButton, BorderLayout.WEST);
				editorPanel.add(deselectButton, BorderLayout.EAST);
				editorPanel.add(inputPanel, BorderLayout.SOUTH);
				
				// Choose input levels.
				if (JOptionPane.showConfirmDialog(Cytoscape.getDesktop(), editorPanel, "Select Input Levels", 
					JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE) == JOptionPane.OK_OPTION){
					// Clear list of input nodes from network.
					SimBoolNetMain.clearInputs();
		
					// Set input levels
					for (String node : sliders.keySet()){
						SimBoolNetMain.addInput(node, sliders.get(node).getValue() * 0.0001);
						if (checkBoxes.get(node).isSelected())
							Cytoscape.getNodeAttributes().setAttribute(node, CHECKED_ATTR, true);
						else
							Cytoscape.getNodeAttributes().setAttribute(node, CHECKED_ATTR, false);
					}
		
					return true;
				}
			}
			return false;
		}

		/**
		 * Adds a new modifier panel for the input level dialog.
		 * @param node The node that needs a modifier created.
		 * @return The new modifier.
		 */
		private JPanel addModifier(String node){
			JPanel modifierPanel = new JPanel(new BorderLayout()),
				   sliderPanel = new JPanel();
			String[] inputNodes = SimBoolNetMain.getInputNodes();
			int value = 1;			
			for (String in : inputNodes)
				if (in.equals(node))
					value = (int) (SimBoolNetMain.getInitialAmount(node));

			// Initialize text field.
			JTextField tempTextField = new JTextField(Double.toString(value), 4);
			tempTextField.setName(node);
			tempTextField.setHorizontalAlignment(JTextField.RIGHT);
			tempTextField.setEditable(false);
			textFields.put(node, tempTextField);

			// Initialize slider.
			JSlider tempSlider = new JSlider(0, 100, value*100);
			tempSlider.setName(node);
			tempSlider.setMajorTickSpacing(25);
			tempSlider.setMinorTickSpacing(5);
			tempSlider.setPaintTicks(true);
			tempSlider.setPaintLabels(true);
			tempSlider.setLabelTable(sliderLabels);
			tempSlider.addChangeListener(this);
			sliders.put(node, tempSlider);

			// Initialize check box.
			JCheckBox tempCheckBox = new JCheckBox(node);
			tempCheckBox.setName(node);
			if ((Cytoscape.getNodeAttributes().getBooleanAttribute(node, CHECKED_ATTR) != null) &&
				(Cytoscape.getNodeAttributes().getBooleanAttribute(node, CHECKED_ATTR)))
				tempCheckBox.setSelected(true);
			checkBoxes.put(node, tempCheckBox);
			
			// Add components to panel.
			modifierPanel.add(tempCheckBox, BorderLayout.WEST);
			sliderPanel.add(tempTextField);
			sliderPanel.add(tempSlider);
			modifierPanel.add(sliderPanel, BorderLayout.EAST);

			modifierHeight = (int) modifierPanel.getPreferredSize().getHeight();

			return modifierPanel;
		}

		/*---------------------------------------Listener Methods---------------------------------------*/
		
		public void actionPerformed(ActionEvent e){
			Object src = e.getSource();

			if (src == addButton){
				for (Object obj : availableList.getSelectedValues()){
					inputListModel.addElement(obj);
					availableListModel.removeElement(obj);
				}
				addButton.setEnabled(false);
			} 
			else if (src == removeButton){
				for (Object obj : inputList.getSelectedValues()){
					availableListModel.addElement(obj);
					inputListModel.removeElement(obj);
				}
				removeButton.setEnabled(false);
			}
			else if (src == selectButton)
				for (String node : checkBoxes.keySet())
					checkBoxes.get(node).setSelected(true);
			else if (src == deselectButton)
				for (String node : checkBoxes.keySet())
					checkBoxes.get(node).setSelected(false);
		}

		public void valueChanged(ListSelectionEvent e){
			JList src = (JList) e.getSource();
			if (src == availableList)
				addButton.setEnabled(true);
			else if (src == inputList)
				removeButton.setEnabled(true);
		}
		
		public void stateChanged(ChangeEvent e){
			JSlider src = (JSlider) e.getSource();

			if (src == inputSlider){
				allChanging = true;
				inputTextField.setText(Double.toString(src.getValue()/100.0));
				//inputTextField.setText(Double.toString(src.getValue()));
				for (String node : sliders.keySet())
					if (checkBoxes.get(node).isSelected())
						sliders.get(node).setValue(inputSlider.getValue());
				allChanging = false;
			}
			else if (sliders.containsValue(src)){
				textFields.get(src.getName()).setText(Double.toString(src.getValue()/100.0));
				if (!allChanging)
					checkBoxes.get(src.getName()).setSelected(false);
			}
		}
		
		public void mouseClicked(MouseEvent e){
			if (e.getClickCount() == 2){
				Object src = e.getSource();
				if (src == availableList)
					addButton.doClick();
				else if (src == inputList)
					removeButton.doClick();
			}

		}

		public void mouseEntered(MouseEvent e){}
		public void mouseExited(MouseEvent e){}
		public void mousePressed(MouseEvent e){}
		public void mouseReleased(MouseEvent e){}
	}

	/*---------------------------------------Results display class---------------------------------------*/

	private class ResultsDialog{
		String results = getResults();

		JTextArea inputTextArea = new JTextArea(results.substring(12, results.indexOf("Edge Weights:")).trim(), 
						10, 30),
				  weightTextArea = new JTextArea(results.substring(results.indexOf("Edge Weights:") + 13,
						results.indexOf("Simulation Results:")).trim(), 10, 30),
				  resultsTextArea = new JTextArea(results.substring(results.indexOf("Simulation Results:") + 19).
						trim(),	10, 30);

		/**
		 * Creates a formatted String to display the results of the simulation.
		 * @return The String representing the results.
		 */
		private String getResults(){
			// First set of information: list of input nodes and their input levels.
			String results = "Input Nodes:";
			for (String node : SimBoolNetMain.getInputNodes())
				results += "\n" + node + ":\t" + SimBoolNetMain.getInitialAmount(node);

			// Second set of information: list of edges and their weights.
			results += "\n\nEdge Weights:";
			for (String edge : SimBoolNetMain.getEdges())
				results += "\n" + edge + ":\t" + SimBoolNetMain.getEdgeWeight(edge);

			// Third set of information: list of final activity levels for each node.
			results += "\n\nSimulation Results:";
			for (String node : SimBoolNetMain.getNodes())
				//results += "\n" + node + ":\t" + SimBoolNetMain.getNodeActivity(node)/SimBoolNetMain.getNumSteps();
				results += "\n" + node + ":\t" + 0.01 * SimBoolNetMain.getNodeActivity(node);
			return results;
		}

		/**
		 * Shows a dialog displaying the results of the simulation.
		 */
		private void displayResults(){
			// Create scroll panes for the text areas.
			JScrollPane inputScrollPane = new JScrollPane(inputTextArea), 
						weightScrollPane = new JScrollPane(weightTextArea), 
						resultsScrollPane = new JScrollPane(resultsTextArea);

			// Create a tabbed pane to hold the scroll panes.
			JTabbedPane resultsTabbedPane = new JTabbedPane();
			resultsTabbedPane.add("Input Nodes", inputScrollPane);
			resultsTabbedPane.add("Edge Weights", weightScrollPane);
			resultsTabbedPane.add("Simulation Results", resultsScrollPane);

			// Create a containing panel to hold the tabbed pane and question
			// whether to save.
			JPanel resultsPanel = new JPanel(new BorderLayout());
			resultsPanel.add(resultsTabbedPane, BorderLayout.NORTH);
			resultsPanel.add(new JLabel("Save results to file?", SwingConstants.CENTER), BorderLayout.SOUTH);

			// Display dialog.
			if (JOptionPane.showConfirmDialog(Cytoscape.getDesktop(), resultsPanel, "Simulation Results",
				JOptionPane.YES_NO_OPTION, JOptionPane.PLAIN_MESSAGE) == JOptionPane.YES_OPTION)
				saveResults();
		}

		/**
		 *  Asks the user where to save the results to.
		 */
		private void saveResults(){
			boolean append = false;

			if (fc.showSaveDialog(Cytoscape.getDesktop()) == JFileChooser.APPROVE_OPTION){
				if (fc.getSelectedFile().exists()){
					String[] options ={"Overwrite", "Append", "Cancel"};

					// If file already exists, ask whether to overwrite or append to file.
					int choice = JOptionPane.showOptionDialog(Cytoscape.getDesktop(),
						"File already exists. Would you like to overwrite or append to existing file?",
						"Save Simulation Results", JOptionPane.YES_NO_CANCEL_OPTION,
						JOptionPane.QUESTION_MESSAGE, null,	options, null);
					if (choice == JOptionPane.NO_OPTION)
						append = true;
					else if (choice != JOptionPane.YES_OPTION)
						return;
				}

				writeToFile(append);
			}
		}

		/**
		 * Write the results to the selected file.
		 * @param append Whether to append to (true) or overwrite (false) an existing file.
		 */
		private void writeToFile(boolean append){
			try{
				BufferedWriter out = new BufferedWriter(new FileWriter(fc.getSelectedFile(), append));

				if (append)
					out.write(SimBoolNetMain.SEPARATOR + SimBoolNetMain.SEPARATOR + "----------------------------------" + 
						SimBoolNetMain.SEPARATOR + SimBoolNetMain.SEPARATOR);

				out.write(lastRunTime + SimBoolNetMain.SEPARATOR + SimBoolNetMain.SEPARATOR + "Single Simulation" + 
					SimBoolNetMain.SEPARATOR + SimBoolNetMain.SEPARATOR + "Iterations: " + 
					SimBoolNetMain.getNumSteps()+ SimBoolNetMain.SEPARATOR + SimBoolNetMain.SEPARATOR + 
					results.replaceAll("\n", SimBoolNetMain.SEPARATOR));

				out.close();
			} catch (Exception e){System.out.println(e.getStackTrace());}
		}
	}

	/*---------------------------------------Batch simulation class---------------------------------------*/

	private class BatchSim implements Task, ActionListener,	ListSelectionListener, MouseListener{
		// Note: Much of the code from this class is copied from the InputDialog and ResultsDialog classes
		// (with changes of course).
		
		private TaskMonitor taskMonitor;
		
		private boolean halted = false;
		private Map<String, Integer> inputLevels = new HashMap<String, Integer>();
		private Map<String, Double> savedInputs = new HashMap<String, Double>();
		private String[] inputNodes = new String[0],
						 outputNodes = new String[0];
		private double step = 0, 
					   percent = 0;

		private JPanel selectPanel = new JPanel(new BorderLayout());
		private DefaultListModel availableListModel = new DefaultListModel(),
								 inputListModel = new DefaultListModel(),
								 outputListModel = new DefaultListModel();
		private JList availableList = new JList(availableListModel),
					  ioList = new JList();
		private JButton addButton = new JButton("->"),
						removeButton = new JButton("<-");
		private DefaultTableModel resultsTableModel = new DefaultTableModel();
		private JTable resultsTable = new JTable(resultsTableModel);

		private final String INPUT = "Input", 
							 OUTPUT = "Output";

		private BatchSim(){			
			// Initialize Lists
			availableList.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
			availableList.setVisibleRowCount(10);
			availableList.addListSelectionListener(this);
			availableList.addMouseListener(this);
			ioList.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
			ioList.setVisibleRowCount(10);
			ioList.addListSelectionListener(this);
			ioList.addMouseListener(this);

			// Save the current list of input nodes.
			String[] inputNodes = SimBoolNetMain.getInputNodes();
			for (String node : inputNodes)
				savedInputs.put(node, SimBoolNetMain.getInitialAmount(node));
			
			// Set initial lists of nodes.
			SimBoolNetMain.clearInputs();
			String[] nodes = SimBoolNetMain.getNodes();
			for (String node : nodes) 
				availableListModel.addElement(node);

			// Initialize Buttons
			addButton.setEnabled(false);
			addButton.addActionListener(this);
			removeButton.setEnabled(false);
			removeButton.addActionListener(this);

			// Create panels for the components.
			JPanel buttonPanel = new JPanel(new BorderLayout()),
				   addButtonPanel = new JPanel(),
				   removeButtonPanel = new JPanel();
			addButtonPanel.add(addButton);
			buttonPanel.add(addButtonPanel, BorderLayout.NORTH);
			removeButtonPanel.add(removeButton);
			buttonPanel.add(removeButtonPanel, BorderLayout.SOUTH);

			// Initialize scrollpanes.
			JScrollPane scroll1 = new JScrollPane(availableList);
			JScrollPane scroll2 = new JScrollPane(ioList);

			// To keep the list sizes consistent.
			if (availableListModel.isEmpty()){
				scroll1.setPreferredSize(scroll2.getPreferredSize());
				scroll2.setPreferredSize(scroll1.getPreferredSize());
			} else if (inputListModel.isEmpty() || outputListModel.isEmpty()){
				scroll2.setPreferredSize(scroll1.getPreferredSize());
				scroll1.setPreferredSize(scroll2.getPreferredSize());
			} else if (scroll1.getPreferredSize().getWidth() < scroll2.getPreferredSize().getWidth()){
				scroll1.setPreferredSize(scroll2.getPreferredSize());
				scroll2.setPreferredSize(scroll1.getPreferredSize());
			} else if (scroll2.getPreferredSize().getWidth() < scroll1.getPreferredSize().getWidth()){
				scroll2.setPreferredSize(scroll1.getPreferredSize());
				scroll1.setPreferredSize(scroll2.getPreferredSize());
			}

			// Initialize table.
			resultsTable.setCellSelectionEnabled(false);
			resultsTable.setColumnSelectionAllowed(false);
			resultsTable.setDragEnabled(false);
			resultsTable.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
			resultsTable.setFillsViewportHeight(true);

			// Add the components.
			selectPanel.add(scroll1, BorderLayout.WEST);
			selectPanel.add(scroll2, BorderLayout.EAST);
			selectPanel.add(buttonPanel, BorderLayout.CENTER);
		}

		public boolean isEmpty() {
			if (resultsTableModel.getRowCount() == 0) {
				return true;
			} else {
				return false;
			}
		}
		
		public DefaultTableModel getResultsTable() {
			return resultsTableModel;
		}
		public String[] getInputNodes() {
			return inputNodes;
		}
		public String[] getOutputNodds() {
			return outputNodes;
		}
		
		/**
		 * Displays the dialogs to choose the input and output nodes for the batch simulation.
		 * @return true if the use completes the dialogs, false otherwise.
		 */
		private boolean getInputOutput(){
			// Get input nodes.
			String[] input = getSelection(INPUT);
			if (input == null){
				halted = true;
				return false;
			}

			// Get output nodes.
			String[] output = getSelection(OUTPUT);
			if (output == null){
				halted = true;
				return false;
			}

			// Set up column names.
			String[] columnNames = new String[input.length + output.length];
			for (int i = 0; i < columnNames.length; i++){
				columnNames[i] = (i < input.length) ? input[i] : output[i
						- input.length];
			}
			resultsTableModel.setColumnIdentifiers(columnNames);

			inputNodes = input;
			outputNodes = output;
			halted = false;
			return true;
		}

		/**
		 * Displays the actual selection dialog.
		 * @param list inputList for choosing input nodes, outputList for choosing output nodes.
		 * @return The list of selected nodes, null if the user cancels.
		 */
		private String[] getSelection(String list){
			if (list == INPUT)
				ioList.setModel(inputListModel);
			else if (list == OUTPUT)
				ioList.setModel(outputListModel);

			if (JOptionPane.showConfirmDialog(Cytoscape.getDesktop(), selectPanel, 
				"Select " + list + " Node(s)", JOptionPane.OK_CANCEL_OPTION, 
				JOptionPane.PLAIN_MESSAGE) == JOptionPane.CANCEL_OPTION)
				return null;

			Object[] selection = ((DefaultListModel) ioList.getModel()).toArray();

			// If no input nodes were selected.
			if (selection.length == 0){
				if (JOptionPane.showConfirmDialog(Cytoscape.getDesktop(), "Please select at least one "
					+ list.toLowerCase() + " node.", "No " + list + " Nodes Selected",	JOptionPane.OK_CANCEL_OPTION,
					JOptionPane.ERROR_MESSAGE) == JOptionPane.OK_OPTION)
					return getSelection(list);
				else
					return null;
			}

			String[] nodes = new String[selection.length];
			for (int i = 0; i < selection.length; i++)
				nodes[i] = (String) selection[i];

			return nodes;
		}

		public void setTaskMonitor(TaskMonitor arg0){
			taskMonitor = arg0;
		}

		public String getTitle(){
			return "Running Batch Simulation";
		}

		public void halt(){
			halted = true;
		}

		/**
		 * Runs the batch simulation.
		 */
		public void run(){
			// Prepare for simulation.
			for (String node : inputNodes)
				inputLevels.put(node, 0);
			step = 100.0 / Math.pow(Math.ceil(100.0 / SimBoolNetMain.getBatchStep()) + 1, inputNodes.length);
			SimBoolNetMain.reset();
			Cytoscape.firePropertyChange(Cytoscape.ATTRIBUTES_CHANGED, null, null);

			// Run batch simulation
			taskMonitor.setStatus("Running...");
			recRun(0);

			// Clear states afterward.
			SimBoolNetMain.reset();
			SimBoolNetMain.clearInputs();

			// Restore the original list of input nodes.
			for (String node : savedInputs.keySet())
				SimBoolNetMain.addInput(node, savedInputs.get(node));

			if (halted)
				return;
		}

		/**
		 * Recursively iterates through the list of input nodes for the batch simulation.
		 * @param i The position of the current input node.
		 */
		private void recRun(int i){
			// Base case: actually run the simulations with the current levels of input nodes.
			if (i == inputNodes.length - 1){
				for (int j = 0; j <= 100; j += SimBoolNetMain.getBatchStep()){
					if (halted)
						return;

					// Set new input levels.
					inputLevels.put(inputNodes[i], j);
					for (String node : inputLevels.keySet())
						SimBoolNetMain.addInput(node, inputLevels.get(node) / 100.0);

					// Set new status message.
					String status = "Running... (";
					for (String node : inputNodes)
						status += node + ": " + inputLevels.get(node) + ", ";
					status = status.substring(0, status.length() - 2) + ")";
					taskMonitor.setStatus(status);

					// Do the complete simulation.
					for (int k = 0; k < SimBoolNetMain.getNumSteps(); k++){
						if (halted)
							return;
						SimBoolNetMain.nextState();
					}

					// Store the results.
					Double[] results = new Double[inputNodes.length + outputNodes.length];
					for (int k = 0; k < results.length; k++)
						//results[k] = (k < inputNodes.length) ? inputLevels.get(inputNodes[k])/100.0 : 
							//SimBoolNetMain.getNodeActivity(outputNodes[k - inputNodes.length])/SimBoolNetMain.getNumSteps();
						results[k] = (k < inputNodes.length) ? inputLevels.get(inputNodes[k]) * 0.01:	
							SimBoolNetMain.getNodeActivity(outputNodes[k - inputNodes.length]) * 0.01;
					resultsTableModel.addRow(results);

					SimBoolNetMain.reset();

					// Update progress bar.
					if ((percent += step) < 0.5)
						taskMonitor.setPercentCompleted(1);
					else
						taskMonitor.setPercentCompleted((int) Math.round(percent));
					
					//Make sure that it does a 100% step.
					if ((j < 100) && (j + SimBoolNetMain.getBatchStep() > 100))
						j = 100 - SimBoolNetMain.getBatchStep();
				}
			}

			//Recursive case: Call the recursion for each step of this input node.
			if (i < inputNodes.length - 1)
				for (int j = 0; j <= 100; j += SimBoolNetMain.getBatchStep()){
					if (halted)
						return;

					inputLevels.put(inputNodes[i], j);
					recRun(i + 1);
					
					//Make sure that it does a 100% step.
					if ((j < 100) && (j + SimBoolNetMain.getBatchStep() > 100))
						j = 100 - SimBoolNetMain.getBatchStep();
				}
		}

		/**
		 * Displays the results dialog.
		 */
		private void displayResults(){
			lastRunTime = new SimpleDateFormat().format(new Date());
			if (JOptionPane.showConfirmDialog(Cytoscape.getDesktop(), "Would you like to view results?",
				"Simulations Completed.", JOptionPane.YES_NO_OPTION) == JOptionPane.NO_OPTION)
				return;
			
			JPanel panel = new JPanel(new BorderLayout());
			JScrollPane scroll = new JScrollPane(resultsTable);
			
			// Make sure the table isn't too large - the scroll pane will keep it to a max of 10 rows and
			// 5 columns visible at a time.
			int cellWidth = (int) resultsTable.getCellRect(0, 0, true).getWidth(),
				numColumns = resultsTable.getColumnCount(),
				width = (numColumns < 5)? cellWidth * numColumns : cellWidth * 5,
				rowHeight = resultsTable.getRowHeight(),
				numRows = resultsTable.getRowCount(),
				height = (numRows < 10)? rowHeight * numRows : rowHeight * 10; 
			resultsTable.setPreferredScrollableViewportSize(new Dimension(width, height));
			
			panel.add(scroll, BorderLayout.NORTH);
			panel.add(new JLabel("Save results to file?", SwingConstants.CENTER), BorderLayout.SOUTH);
			
			// This is to fix a graphical issue where the scroll pane would be too wide if there are less than
			// 3 columns and a scroll bar - probably caused by the JOptionPane.showConfirmationDialog() method.
			// Conversely, the option pane now clips about a pixel on the Yes and No buttons if the table only
			// has two columns, but that is (arguably) more pleasing graphically.
			JOptionPane pane = new JOptionPane(panel, JOptionPane.PLAIN_MESSAGE, JOptionPane.YES_NO_OPTION);
			JDialog dialog = pane.createDialog("Simulation complete.");
			pane.setPreferredSize(new Dimension((int) (panel.getPreferredSize().getWidth() + 
				pane.getPreferredSize().getWidth() - panel.getSize().getWidth()), 
				(int) pane.getPreferredSize().getHeight()));
			dialog.pack();
			dialog.setVisible(true);
			if (pane.getValue().equals(JOptionPane.YES_OPTION))
				saveResults();
		}
		
		/**
		 * Ask the use where to save the results.
		 */
		private void saveResults(){
			boolean append = false;

			if (fc.showSaveDialog(Cytoscape.getDesktop()) == JFileChooser.APPROVE_OPTION){
				if (fc.getSelectedFile().exists()){
					String[] options ={ "Overwrite", "Append", "Cancel" };

					// If file already exists, ask whether to overwrite or
					// append to file.
					int choice = JOptionPane.showOptionDialog(Cytoscape.getDesktop(),
						"File already exists. Would you like to overwrite or append to existing file?",
						"Save Simulation Results", JOptionPane.YES_NO_CANCEL_OPTION,
						JOptionPane.QUESTION_MESSAGE, null,	options, null);
					if (choice == JOptionPane.NO_OPTION)
						append = true;
					else if (choice == JOptionPane.CANCEL_OPTION)
						return;
				}

				writeToFile(append);
			}
		}
		
		/**
		 * Write the results to file.
		 * @param append Whether to append to (true) or overwrite (false) an existing file.
		 */
		private void writeToFile(boolean append){
			try{
				BufferedWriter out = new BufferedWriter(new FileWriter(fc.getSelectedFile(), append));

				if (append)
					out.write("\n\n----------------------------------\n\n".replaceAll("\n", SimBoolNetMain.SEPARATOR));
				
				out.write(lastRunTime + SimBoolNetMain.SEPARATOR + SimBoolNetMain.SEPARATOR + "Batch Simulation" +
						SimBoolNetMain.SEPARATOR + SimBoolNetMain.SEPARATOR + "Iterations per Simulation: " + 
						SimBoolNetMain.getNumSteps() + SimBoolNetMain.SEPARATOR + SimBoolNetMain.SEPARATOR +
						"Edge Weights:" + SimBoolNetMain.SEPARATOR);
				
				// Write edge weights.
				String[] edges = SimBoolNetMain.getEdges();
				for (String edge : edges){
					out.write(edge + "\t" + SimBoolNetMain.getEdgeWeight(edge) + SimBoolNetMain.SEPARATOR);
				}
				
				// Write results.
				out.write(SimBoolNetMain.SEPARATOR + "Simulation Results:" + SimBoolNetMain.SEPARATOR);
				for (String node : inputNodes)
					out.write(node + "\t");
				for (int i = 0; i < outputNodes.length; i++){
					out.write(outputNodes[i]);
					if (i < outputNodes.length - 1)
						out.write("\t");
				}	
				out.write(SimBoolNetMain.SEPARATOR);
				for (int i = 0; i < resultsTableModel.getRowCount(); i++){
					for (int j = 0; j < resultsTableModel.getColumnCount(); j++){
						out.write(resultsTableModel.getValueAt(i, j).toString());
						if (j < resultsTableModel.getColumnCount() - 1)
							out.write("\t");
					}
					if (i < resultsTableModel.getRowCount() - 1)
						out.write(SimBoolNetMain.SEPARATOR);
				}
				
				out.close();
			} catch (Exception e){
				System.out.println(e.getStackTrace());
			}
		}

		
		/*---------------------------------------Listener Methods---------------------------------------*/
		public void actionPerformed(ActionEvent e){
			Object src = e.getSource();

			if (src == addButton){
				for (Object obj : availableList.getSelectedValues()){
					((DefaultListModel) ioList.getModel()).addElement(obj);
					availableListModel.removeElement(obj);
				}
				addButton.setEnabled(false);
			} 
			else if (src == removeButton){
				for (Object obj : ioList.getSelectedValues()){
					availableListModel.addElement(obj);
					((DefaultListModel) ioList.getModel()).removeElement(obj);
				}
				removeButton.setEnabled(false);
			}
		}

		public void valueChanged(ListSelectionEvent e){
			JList src = (JList) e.getSource();
			
			if (src == availableList)
				addButton.setEnabled(true);
			else if (src == ioList)
				removeButton.setEnabled(true);
		}

		public void mouseClicked(MouseEvent e){
			if (e.getClickCount() == 2){
				Object src = e.getSource();
				if (src == availableList)
					addButton.doClick();
				else if (src == ioList)
					removeButton.doClick();
			}

		}

		public void mouseEntered(MouseEvent e){}
		public void mouseExited(MouseEvent e){}
		public void mousePressed(MouseEvent e){}
		public void mouseReleased(MouseEvent e){}	
	
	//	public void showBatchRegress() {
	//	}
	
	}
	
	/*---------------------------------------Edge weight editor class---------------------------------------*/
	private class WeightDialog implements ActionListener, ChangeListener{
		private Map<String, JTextField> textFields = new HashMap<String, JTextField>();
		private Map<String, JSlider> sliders = new HashMap<String, JSlider>();
		private Map<String, JCheckBox> checkBoxes = new HashMap<String, JCheckBox>();
		private JButton selectButton = new JButton("Select all"),
						deselectButton = new JButton("Deselect all");
		private JSlider activateSlider = new JSlider(0, 100, (int) Math.round(SimBoolNetMain.getActivateWeight()*100)),
						blockSlider = new JSlider(0, 100, (int) Math.round(SimBoolNetMain.getBlockWeight()*100));
		private JTextField activateTextField = new JTextField(Double.toString(activateSlider.getValue()/100.0), 3),
		   				   blockTextField = new JTextField(Double.toString(blockSlider.getValue()/100.0), 3);
		
		private int modifierHeight = 0;
		private boolean allChanging = false;
		
		private WeightDialog(){			
			// Initialize sliders.
			activateSlider.setMajorTickSpacing(25);
			activateSlider.setMinorTickSpacing(5);
			activateSlider.setPaintTicks(true);
			activateSlider.setPaintLabels(true);
			activateSlider.setLabelTable(sliderLabels);
			activateSlider.addChangeListener(this);
			blockSlider.setMajorTickSpacing(25);
			blockSlider.setMinorTickSpacing(5);
			blockSlider.setPaintTicks(true);
			blockSlider.setPaintLabels(true);
			blockSlider.setLabelTable(sliderLabels);
			blockSlider.addChangeListener(this);
			
			// Initialize text fields.
			activateTextField.setHorizontalAlignment(JTextField.RIGHT);
			activateTextField.setEditable(false);
			blockTextField.setHorizontalAlignment(JTextField.RIGHT);
			blockTextField.setEditable(false);
			
			selectButton.addActionListener(this);
			deselectButton.addActionListener(this);
			
			
		}
		
		/**
		 * Display the dialog for the user to change edge weights.
		 */
		private void setWeights(){
			String[] edges = SimBoolNetMain.getEdges();
			JPanel modifierPanel = new JPanel(new GridLayout(edges.length, 1)),
				   editorPanel = new JPanel(new BorderLayout()),
				   activatePanel = new JPanel(new BorderLayout()),
				   activateSliderPanel = new JPanel(),
				   blockPanel = new JPanel(new BorderLayout()),
				   blockSliderPanel = new JPanel(),
				   southPanel = new JPanel(new BorderLayout());

			// Set up intermediate panels.
			activatePanel.add(new JLabel("Activation Edges:"), BorderLayout.WEST);
			activateSliderPanel.add(activateTextField);
			activateSliderPanel.add(activateSlider);
			activatePanel.add(activateSliderPanel, BorderLayout.EAST);
			blockPanel.add(new JLabel("Blockage Edges:"), BorderLayout.WEST);
			blockSliderPanel.add(blockTextField);
			blockSliderPanel.add(blockSlider);
			blockPanel.add(blockSliderPanel, BorderLayout.EAST);
			southPanel.add(new JLabel("Modify all selected edges:"), BorderLayout.NORTH);
			southPanel.add(activatePanel, BorderLayout.CENTER);
			southPanel.add(blockPanel, BorderLayout.SOUTH);
			
			for (String edge : edges)
				modifierPanel.add(addModifier(edge));

			// In order to keep the dialog a reasonable size, set up a scroll
			// pane if too many input nodes (5)
			// are selected.
			JScrollPane scroll = new JScrollPane(modifierPanel);
			if (edges.length > 5)
				scroll.setPreferredSize(new Dimension((int) (scroll.getPreferredSize().getWidth() + 
					scroll.getVerticalScrollBar().getPreferredSize().getWidth()), modifierHeight * 5));
			
			// Put everything into final panel.
			editorPanel.add(scroll, BorderLayout.NORTH);
			editorPanel.add(selectButton, BorderLayout.WEST);
			editorPanel.add(deselectButton, BorderLayout.EAST);
			editorPanel.add(southPanel, BorderLayout.SOUTH);
			
			// Choose weights.
			if (JOptionPane.showConfirmDialog(Cytoscape.getDesktop(), editorPanel, "Edit Edge Weights", 
				JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE) == JOptionPane.OK_OPTION){
					for (String edge : edges){
						SimBoolNetMain.setEdgeWeight(edge, ((double) sliders.get(edge).getValue())/100);
						if (checkBoxes.get(edge).isSelected())
							Cytoscape.getEdgeAttributes().setAttribute(edge, CHECKED_ATTR, true);
						else
							Cytoscape.getEdgeAttributes().setAttribute(edge, CHECKED_ATTR, false);
					}
			}
		}

		/**
		 * Adds a new modifier panel.
		 * @param edge The edge that needs a modifier created.
		 * @return The new modifier.
		 */
		private JPanel addModifier(String edge){
			JPanel modifierPanel = new JPanel(new BorderLayout()),
				   sliderPanel = new JPanel();
			int value = (int) Math.round(SimBoolNetMain.getEdgeWeight(edge) * 100);

			// Initialize text field.
			JTextField tempTextField = new JTextField(Double.toString(value/100.0), 3);
			tempTextField.setName(edge);
			tempTextField.setHorizontalAlignment(JTextField.RIGHT);
			tempTextField.setEditable(false);
			textFields.put(edge, tempTextField);
			
			// Initialize check box.
			JCheckBox tempCheckBox = new JCheckBox(edge);
			tempCheckBox.setName(edge);
			if ((Cytoscape.getEdgeAttributes().getBooleanAttribute(edge, CHECKED_ATTR) != null) &&
				(Cytoscape.getEdgeAttributes().getBooleanAttribute(edge, CHECKED_ATTR)))
				tempCheckBox.setSelected(true);
			checkBoxes.put(edge, tempCheckBox);

			// Initialize slider.
			JSlider tempSlider = new JSlider(0, 100, value);
			tempSlider.setName(edge);
			tempSlider.setMajorTickSpacing(25);
			tempSlider.setMinorTickSpacing(5);
			tempSlider.setPaintTicks(true);
			tempSlider.setPaintLabels(true);
			tempSlider.setLabelTable(sliderLabels);
			tempSlider.addChangeListener(this);
			sliders.put(edge, tempSlider);

			// Add components to panel.
			sliderPanel.add(tempTextField);
			sliderPanel.add(tempSlider);
			modifierPanel.add(tempCheckBox, BorderLayout.WEST);
			modifierPanel.add(sliderPanel, BorderLayout.EAST);

			modifierHeight = (int) modifierPanel.getPreferredSize().getHeight();

			return modifierPanel;
		}
		

		/*---------------------------------------Listener Methods---------------------------------------*/
		
		public void actionPerformed(ActionEvent e) {
			JButton src = (JButton) e.getSource();
			
			if (src == selectButton)
				for (String edge : checkBoxes.keySet())
					checkBoxes.get(edge).setSelected(true);
			if (src == deselectButton)
				for (String edge : checkBoxes.keySet())
					checkBoxes.get(edge).setSelected(false);
		}

		public void stateChanged(ChangeEvent e) {
			JSlider src = (JSlider) e.getSource();

			if (src == activateSlider){
				allChanging = true;
				activateTextField.setText(Double.toString(activateSlider.getValue()/100.0));
				for (String edge : checkBoxes.keySet())
					if (checkBoxes.get(edge).isSelected() && 
						SimBoolNetMain.getEdgeInteraction(edge).equals(SimBoolNetMain.getActivateInter()))
						sliders.get(edge).setValue(activateSlider.getValue());
				allChanging = false;
			}
			else if (src == blockSlider){
				allChanging = true;
				blockTextField.setText(Double.toString(blockSlider.getValue()/100.0));
				for (String edge : sliders.keySet())
					if (checkBoxes.get(edge).isSelected() && 
						SimBoolNetMain.getEdgeInteraction(edge).equals(SimBoolNetMain.getBlockInter()))
						sliders.get(edge).setValue(blockSlider.getValue());
				allChanging = false;
			}
			else if (sliders.containsValue(src))
				textFields.get(src.getName()).setText(Double.toString(src.getValue()/100.0));
				if (!allChanging)
					checkBoxes.get(src.getName()).setSelected(false);
		}
	}
	
	// Plot time-series of node activities from single-mode simulation		
	private class SimuMovie extends JFrame implements ActionListener, ChangeListener, ListSelectionListener  
	{
		// GUI components
		private DefaultListModel availableNodeList = new DefaultListModel();
		private DefaultListModel plotNodeList = new DefaultListModel();	
		private JList availableJList;
		private JList plotJList = new JList();

		private JButton addButton = new JButton("Add >>");
		private JButton removeButton = new JButton("<<Remove");
		private JButton plotButton = new JButton("Plot");
		private JButton saveButton = new JButton("Save"); 
	
		private JPanel inputPanel = new JPanel();
		private JPanel exportPanel = new JPanel();	
		private ChartPanel chartPanel;
		
		private BorderLayout layout;		
		
		// Data set
		XYSeriesCollection nodeActSeries;
		
		private SimuMovie(Map<String, ArrayList<Double>> nodeAct) {		
			super("Single Result Plot");
			
			// initialize series
			nodeActSeries = new XYSeriesCollection();			
			for (String node : nodeAct.keySet()) {
				final XYSeries series = new XYSeries(node);
				ArrayList<Double> actList = nodeAct.get(node);
				for (int i = 0; i < actList.size(); i++) {
					series.add(i, actList.get(i));
				}				
				nodeActSeries.addSeries(series);
			}
			
			layout = new BorderLayout( 5, 5 );
			setLayout( layout );

			// get the list of names of all nodes (series keys) 
			int nodeNum = nodeActSeries.getSeriesCount();
			for (int i = 0; i < nodeNum; i++) {
				Object nodeName = nodeActSeries.getSeriesKey(i);
				availableNodeList.addElement(nodeName);
			}			
			// sort the list alphabetically
			Object[] nodeArray = availableNodeList.toArray();
			Arrays.sort(nodeArray, new AlphabeticComparator());
			availableNodeList.removeAllElements();
			for (int i = 0; i < nodeArray.length; i++) {
				availableNodeList.addElement(nodeArray[i]);				
			}
			availableJList = new JList(availableNodeList);
			
		
			// select plot nodes
			availableJList.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
			availableJList.setVisibleRowCount(4);
			availableJList.addListSelectionListener(this);
			//availableJList.addMouseListener(this);
			
			plotJList.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
			plotJList.setVisibleRowCount(4);
			plotJList.addListSelectionListener(this);
			//plotJList.addMouseListener(this);		
			
			addButton.setEnabled(false);
			addButton.addActionListener(this);
			removeButton.setEnabled(false);
			removeButton.addActionListener(this);
		
			JPanel selectButtonPanel = new JPanel(new BorderLayout());
			selectButtonPanel.add(addButton, BorderLayout.NORTH);
			selectButtonPanel.add(removeButton, BorderLayout.SOUTH);
		
			JScrollPane scroll1 = new JScrollPane(availableJList);
			JScrollPane scroll2 = new JScrollPane(plotJList);

			// To keep the list sizes consistent.
			if (availableNodeList.isEmpty()){
				scroll1.setPreferredSize(scroll2.getPreferredSize());
				scroll2.setPreferredSize(scroll1.getPreferredSize());
			} 
			else if (plotNodeList.isEmpty()){
				scroll2.setPreferredSize(scroll1.getPreferredSize());
				scroll1.setPreferredSize(scroll2.getPreferredSize());
			} 
			else if (scroll1.getPreferredSize().getWidth() < scroll2.getPreferredSize().getWidth()){
				scroll1.setPreferredSize(scroll2.getPreferredSize());
				scroll2.setPreferredSize(scroll1.getPreferredSize());
			} 
			else if (scroll2.getPreferredSize().getWidth() < scroll1.getPreferredSize().getWidth()){
				scroll2.setPreferredSize(scroll1.getPreferredSize());
				scroll1.setPreferredSize(scroll2.getPreferredSize());
			}
		
			// Add text labels of available nodes
			JPanel availableNodePane = new JPanel(new BorderLayout());
			availableNodePane.add(new JLabel("Available nodes"), BorderLayout.NORTH);
			availableNodePane.add(scroll1, BorderLayout.SOUTH);
			// Add text labels of plot nodes
			JPanel plotNodePane = new JPanel(new BorderLayout());
			plotNodePane.add(new JLabel("Nodes to plot"), BorderLayout.NORTH);
			plotNodePane.add(scroll2, BorderLayout.SOUTH);
						
			// Add components in input panel 
			inputPanel.add(availableNodePane, BorderLayout.WEST);
			inputPanel.add(selectButtonPanel, BorderLayout.CENTER);
			inputPanel.add(plotNodePane, BorderLayout.EAST);
			add(inputPanel, BorderLayout.WEST);
		
			// Add blank chart panel
			XYSeriesCollection dataset = new XYSeriesCollection(); // a dummy dataset	
			JFreeChart chart = createChart(dataset);
			chartPanel = new ChartPanel(chart);			
			chartPanel.setPreferredSize(new java.awt.Dimension(500, 270));
			chartPanel.setMouseZoomable(true, false);
			add(chartPanel, BorderLayout.NORTH);        
        
			// Layout export buttons
			plotButton.addActionListener(this);
			exportPanel.add(plotButton);
			saveButton.addActionListener(this);
			exportPanel.add(saveButton);
			add(exportPanel, BorderLayout.EAST);
			
		}
		
		private JFreeChart createChart(XYDataset dataset) {			
			JFreeChart chart = ChartFactory.createXYLineChart(
	      		"Change of node activities", "Time", "Node Activities", 
	       		dataset, 
	        	PlotOrientation.VERTICAL, true, false, false);
			Plot plot = chart.getPlot();
			plot.setBackgroundPaint(Color.lightGray);
			return chart;
		}
	
		private void saveSeries() 
		{
			JFileChooser fc = new JFileChooser();
			if (fc.showSaveDialog(null) != JFileChooser.APPROVE_OPTION) {
				return;
			}
			File outFile = fc.getSelectedFile();			
			if (outFile.exists()) {				
				String[] options ={"OK", "Cancel"};
				int choice = JOptionPane.showOptionDialog(null, 
					"File already exists. Is it ok to overwrite it?", 
					"Save series to text file",
					JOptionPane.YES_NO_CANCEL_OPTION,
					JOptionPane.QUESTION_MESSAGE, null,	options, null);
				if (choice == JOptionPane.NO_OPTION)				
					return;					
			}
						
			try {				
				BufferedWriter out = new BufferedWriter(new FileWriter(outFile, false));
				int nodeNum = nodeActSeries.getSeriesCount();
				for (int i = 0; i < nodeNum; i++) {
					String seriesName = (String)nodeActSeries.getSeriesKey(i);
					out.write(seriesName + ": ");
					
					XYSeries s = nodeActSeries.getSeries(i);
					int stepCount = s.getItemCount();
					for (int j = 0; j < stepCount; j++) {
						Number y = s.getY(j); 						
						if (j < stepCount - 1)
							out.write(y+",");
						else 
							out.write(y+"\n");						
					}
				}			
				out.close();				
			} catch (Exception e) { 
				System.out.println(e.getStackTrace());
			}
		}
			
		public void actionPerformed(ActionEvent e) {
			if (e.getSource() == addButton) {			
				for (Object	obj : availableJList.getSelectedValues()) {
					plotNodeList.addElement(obj);
					availableNodeList.removeElement(obj);
					plotJList.setListData(plotNodeList.toArray());
				}			
			} 
			
			else if (e.getSource() == removeButton) {
				for (Object	obj : plotJList.getSelectedValues()) {
					availableNodeList.addElement(obj);
					plotNodeList.removeElement(obj);
					plotJList.setListData(plotNodeList.toArray());
				}			
			}
						
			else if (e.getSource() == plotButton) { // Update xy lines plot				
				XYSeriesCollection dataset = new XYSeriesCollection();			
				// pick series of plotNodeList				
				Object[] toPlotNode = plotNodeList.toArray();
				for (Object key : toPlotNode) {				
					XYSeries series = new XYSeries(key.toString());
					ArrayList<Double> actList = nodeAct.get(key);
					for (int i = 0; i < actList.size(); i++) {
						series.add(i, actList.get(i));
					}				
					dataset.addSeries(series);
				}				
								
				// update chart 
				chartPanel.removeAll();						
				JFreeChart chart = createChart(dataset);
				chartPanel.setChart(chart);			
				chartPanel.revalidate();
				add(chartPanel, BorderLayout.NORTH);								
			} 
			
			else if (e.getSource() == saveButton) { // Export nodeActSeries to text file
				saveSeries();
			}
			
			layout.layoutContainer(getContentPane()); //?		 
		}
						
		public void valueChanged(ListSelectionEvent e) {
			JList src = (JList) e.getSource();
			if (src == availableJList)
				addButton.setEnabled(true);
			else if (src == plotJList)
				removeButton.setEnabled(true);
		}
	
		public void stateChanged(ChangeEvent e) {
		// TODO Auto-generated method stub
		
		}	
	}

	private class AlphabeticComparator implements Comparator {
		public int compare(Object o1, Object o2) {
		    String s1 = (String) o1;
		    String s2 = (String) o2;
		    return s1.toLowerCase().compareTo(s2.toLowerCase());
		}
	}
	
	// JFrame for plotting batch simulation results
	private class BatchRegressFrame extends JFrame implements ActionListener 
	{	
		// data
		private DefaultTableModel resultsTableModel = new DefaultTableModel();	
		private String [] inputNodes; // to be replaced
		private String [] outputNodes; // to be replaced
		
		private Map<String, Set<String>> inputLevels = new HashMap<String, Set<String>>(); 		
		private Map<String, String> marginLevelControl = new HashMap<String, String>(); // selected control level for a marginal input node
		private String predictNode;
		private String respondNode;
		private XYSeriesCollection scatterSeries = new XYSeriesCollection();
		
		// GUI components
		private JPanel marginInputPanel;
		private JComboBox predictBox;
		private JComboBox responseBox;
		private JPanel regressNodePanel;
		private JButton plotButton;
		private ChartPanel chartPanel;
		
		private BorderLayout layout;
		
		public BatchRegressFrame(DefaultTableModel batchResultsTable, String [] myInputNodes, String [] myOutputNodes)
		{
			super("Batch Result Plot");
		
			// get data
			resultsTableModel = batchResultsTable;
			inputNodes = myInputNodes;
			outputNodes = myOutputNodes;
			
			getInputLevels();
			marginInputPanel = getMarginInputPanel();		
			//JScrollPane marginScroll = new JScrollPane(marginInputPanel);
			//marginScroll.setSize(100, 80);
			//if (inputNodes.length > 3) {
			//	marginScroll.setPreferredSize(new Dimension((int) (marginScroll.getPreferredSize().getWidth() + 
			//		marginScroll.getVerticalScrollBar().getPreferredSize().getWidth()), 4));
			//}			
			
			// select predictor node and responsive node
			regressNodePanel = new JPanel();
			predictBox = new JComboBox(inputNodes);
			//predictBox.setPreferredSize(new Dimension(20, 1));
			predictBox.addItemListener(
				new ItemListener()
				{
					public void itemStateChanged(ItemEvent event) {
						if ( event.getStateChange() == ItemEvent.SELECTED) {
							predictNode = (String)predictBox.getSelectedItem();						
						}					
					}	
				}
			);
			predictNode = predictBox.getItemAt(0).toString(); // default item
			
			responseBox = new JComboBox(outputNodes);
			responseBox.addItemListener(
				new ItemListener()
				{
					public void itemStateChanged(ItemEvent event) {
						if ( event.getStateChange() == ItemEvent.SELECTED)
							respondNode = (String)responseBox.getSelectedItem();
					}				
				}
			);
			respondNode = responseBox.getItemAt(0).toString(); // default item
			
			JPanel predictPanel = new JPanel();
			predictPanel.add(new JLabel("Predictor node"));
			predictPanel.add(predictBox);
			JPanel responsePanel = new JPanel();
			responsePanel.add(new JLabel("Responsive node"));
			responsePanel.add(responseBox);
			
			Box axisBox = Box.createVerticalBox();			
			axisBox.add(Box.createRigidArea(new Dimension(10, 7)));
			axisBox.add(predictPanel);
			axisBox.add(Box.createRigidArea(new Dimension(10, 7)));
			axisBox.add(responsePanel);
			
			plotButton = new JButton("Plot");
			plotButton.addActionListener(this);					
			axisBox.add(Box.createRigidArea(new Dimension(10, 20)));
			axisBox.add(plotButton);

			regressNodePanel.add(axisBox);
			
			//JPanel exportPanel = new JPanel();
			//exportPanel.add(plotButton);
			
			// Plot the default chart
			getScatterSeries();	
			JFreeChart chart = createChart(scatterSeries);
			chartPanel = new ChartPanel(chart);
			chartPanel.setPreferredSize(new java.awt.Dimension(500, 270));
	        chartPanel.setMouseZoomable(true, true);
	        		
			// Layout components
			layout = new BorderLayout( 5, 5 );
			setLayout(layout);
			add(chartPanel, BorderLayout.NORTH);
			add(marginInputPanel, BorderLayout.WEST);			
			add(regressNodePanel, BorderLayout.CENTER);
			//add(exportPanel, BorderLayout.SOUTH);
			
		}
				
		private void getInputLevels() 
		{		
			int numCol = resultsTableModel.getColumnCount();
			int numRow = resultsTableModel.getRowCount();
			
			for (int i = 0; i < inputNodes.length; i++) {
				String node = inputNodes[i];
				
				// find column of that node
				int myColumn = -1;
				for (int col = 0; col < numCol; col++) {
					String columnName = resultsTableModel.getColumnName(col);
					if (node.equals(columnName)) {
						myColumn = col;
						break;
					}				
				}
				if (myColumn == -1) {
					System.out.println("Column name " + 
							node + " is not found in batch input list");
					return;
				}
				
				// scan the column to get all possible levels
				Set<String> levels = new TreeSet<String>();
				for (int row = 0; row < numRow; row++) {										
					Object myLevel = resultsTableModel.getValueAt(row, myColumn);
					levels.add(myLevel.toString());
				}
				inputLevels.put(node, levels);			
			}
		}
		
		private JPanel getMarginInputPanel()
		{
			int numInputNodes = inputNodes.length;
			JPanel marginPanel = new JPanel();
			
			// set input levels
			Box marginBox = Box.createVerticalBox();
			marginBox.add( Box.createRigidArea( new Dimension(10, 7)));
			marginBox.add(new JLabel("Marginal control"));
			for (int i = 0; i < numInputNodes; i++) {
				final String inNode = inputNodes[i];							
				
				// get combo box
				Set<String> levelSet;
				if (inputLevels.containsKey(inNode)) {
					levelSet = inputLevels.get(inNode);
				} else {
					System.out.println("Input node " + 
							inNode + " has no available levels");
					return null;
				}
				final JComboBox levelCombo = new JComboBox(levelSet.toArray());
				levelCombo.addItemListener(
					new ItemListener()
					{			
						public void itemStateChanged(ItemEvent event) {
							if( event.getStateChange() == ItemEvent.SELECTED ) {
								marginLevelControl.put(inNode, levelCombo.getSelectedItem().toString());
							}
						}			
					}
				);			
				// initialize default control level 
				String defaultLevel = levelCombo.getItemAt(0).toString();
				marginLevelControl.put(inNode, defaultLevel);
			
				// layout
				JPanel oneRowPane = new JPanel(new BorderLayout());
				oneRowPane.add(new JLabel(inNode), BorderLayout.WEST);								
				oneRowPane.add(levelCombo, BorderLayout.EAST);
				
				marginBox.add( Box.createRigidArea( new Dimension(12, 8)));
				marginBox.add(oneRowPane);
			}
			marginPanel.add(marginBox);
			
			return marginPanel;
		}
		
		/* *
		 *  Filter out rows in resultsTableModel not satisfying marginal control
		 *  and get scatter points of predictor and responsive nodes 
		 */
		private void getScatterSeries()
		{
			XYSeries series = new XYSeries(respondNode);
			int rowNum = resultsTableModel.getRowCount();
			int colNum = resultsTableModel.getColumnCount();
			for (int rowId = 0; rowId < rowNum; rowId ++) {
				Double predictValue = -1.0;
				Double responseValue = -1.0;
				boolean selected = true;
				for (int colId = 0; colId < colNum; colId++) {
					String colName = resultsTableModel.getColumnName(colId);
					if (marginLevelControl.containsKey(colName) && !colName.equals(predictNode)) {
						String control = marginLevelControl.get(colName);
						String value = resultsTableModel.getValueAt(rowId, colId).toString();
						if (!value.equals(control)) {
							selected = false;
							break;
						}
					}
					if (colName.equals(predictNode)) {
						predictValue = (Double)resultsTableModel.getValueAt(rowId, colId);
					}
					if (colName.equals(respondNode)) {
						responseValue = (Double)resultsTableModel.getValueAt(rowId, colId);
					}
				}
				if (selected) {
					series.add(predictValue, responseValue);
				}
			}		
			
			scatterSeries.addSeries(series); // todo: multiple responsive nodes in future
		}
			
		private JFreeChart createChart(XYSeriesCollection dataset) 
		{
			JFreeChart chart = ChartFactory.createScatterPlot(null, predictNode, respondNode, dataset,
					PlotOrientation.VERTICAL, true, false, false);
			XYPlot plot = (XYPlot) chart.getPlot();
			XYItemRenderer scatterRenderer = plot.getRenderer();			
			
			StandardXYItemRenderer regressionRenderer = new StandardXYItemRenderer();
			regressionRenderer.setBaseSeriesVisibleInLegend(false);
			plot.setDataset(1, regress(dataset));
			plot.setRenderer(1, regressionRenderer);
			plot.setBackgroundPaint(Color.lightGray);
			
			DrawingSupplier ds = plot.getDrawingSupplier();
			
			for (int i = 0; i < dataset.getSeriesCount(); i++) {
				Paint paint = ds.getNextPaint();
				scatterRenderer.setSeriesPaint(i, paint);
				regressionRenderer.setSeriesPaint(i, paint);
			}
			
			// customize range axis
			NumberAxis rangeAxis = (NumberAxis)plot.getRangeAxis();
			rangeAxis.setAutoRangeIncludesZero(true);
			rangeAxis.setAutoRangeMinimumSize(1.0);
			
			return chart;
		}

		private XYDataset regress(XYSeriesCollection data) 
		{
			double xMin = Double.MAX_VALUE, xMax = 0;
			for (int i = 0; i < data.getSeriesCount(); i++) {
				XYSeries ser = data.getSeries(i);
				for (int j = 0; j < ser.getItemCount(); j++) {
					double x = ser.getX(j).doubleValue();
					if (x < xMin) {
						xMin = x;
					}
					if (x > xMax) {
						xMax = x;
					}
				}
			}
			// Create a 2-point series 
			XYSeriesCollection coll = new XYSeriesCollection();
			for (int i = 0; i < data.getSeriesCount(); i++) {
				XYSeries ser = data.getSeries(i);
				int n = ser.getItemCount();
				double sx = 0, sy = 0, sxx = 0, sxy = 0, syy = 0;
				for (int j = 0; j < n; j++) {
					double x = ser.getX(j).doubleValue();
					double y = ser.getY(j).doubleValue();
					sx += x;
					sy += y;
					sxx += x * x;
					sxy += x * y;
					syy += y * y;
				}
				double b = (n * sxy - sx * sy) / (n * sxx - sx * sx);
				double a = sy / n - b * sx / n;
				XYSeries regr = new XYSeries(ser.getKey());
				regr.add(xMin, a + b * xMin);
				regr.add(xMax, a + b * xMax);
				coll.addSeries(regr);
			}
			return coll;
		}
		
		public void actionPerformed(ActionEvent e) {		
			if (e.getSource() == plotButton) {
				chartPanel.removeAll();
				scatterSeries.removeAllSeries();
				getScatterSeries();			
				JFreeChart chart = createChart(scatterSeries);
				chartPanel.setChart(chart);			
				chartPanel.revalidate();
				add(chartPanel, BorderLayout.NORTH);
				
			}
			
			layout.layoutContainer(getContentPane());
		}
		
	}
	
}