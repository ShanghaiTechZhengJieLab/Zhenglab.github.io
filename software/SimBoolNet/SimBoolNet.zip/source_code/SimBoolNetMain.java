package simboolnet;

import cytoscape.plugin.CytoscapePlugin;

public class SimBoolNetMain extends CytoscapePlugin{
	private static SimBoolNetModel myNet = new SimBoolNetModel();
	
	private static String activityAttr = "Degree", 
						  weightAttr = "Weight",
						  activateInter = "+", 
						  blockInter = "-";
	private static final double blockWeight = 0.8, 
						  activateWeight = 0.8;
	private static int batchStep = 25,
					   numSteps = 100;
	
	// This is so that line breaks will show up correctly in Notepad (which uses \n\r instead of \n).
	public final static String SEPARATOR = System.getProperty("line.separator");

    public SimBoolNetMain(){
    	new SimBoolNetGUI();
    }
    

    /*--------------------------------Methods for interacting with network model.----------------------------*/
    
    /**
     * Calls the network's getInputNodes() method.
     * @return An array of input nodes (in String format) in the network.
     */
	public static String[] getInputNodes(){
		return myNet.getInputNodes();
	}

	/**
	 * Calls the network's getNodes() method.
	 * @return An array of nodes (in String format) in the network.
	 */
	public static String[] getNodes(){
		return myNet.getNodes();
	}

	/**
	 * Calls the network's getEdges() method.
	 * @return An array of edges (in String format) in the network.
	 */
	public static String[] getEdges(){
		return myNet.getEdges();
	}
	
	/**
	 * Calls the network's getNodeActivity() method.
	 * @param node The node whose activity level is requested. 
	 * @return The activity level of the node.
	 */
	public static double getNodeActivity(String node){
		return myNet.getNodeActivity(node);
	}

	/**
	 * Calls the network's getInitialAmount() method.
	 * @param node The node whose initial amount is requested.
	 * @return The initial amount of the node.
	 */
	public static double getInitialAmount(String node){
		return myNet.getInitialAmount(node);
	}

	/**
	 * Calls the network's getEdgeWeight() method.
	 * @param edge The edge whose weight is requested.
	 * @return The weight of the edge.
	 */
	public static double getEdgeWeight(String edge){
		return myNet.getEdgeWeight(edge);
	}
	
	/**
	 * Calls the network's setEdgeWeight() method.
	 * @param edge The edge whose weight is being set.
	 * @param weight The weight to be set.
	 */
	public static void setEdgeWeight(String edge, double weight){
		myNet.setEdgeWeight(edge, weight);
	}
	
	/**
	 * Calls the network's getEdgeInteraction() method.
	 * @param edge The edge whose interaction is requested.
	 * @return The interaction type of the edge.
	 */
	public static String getEdgeInteraction(String edge){
		return myNet.getEdgeInteraction(edge);
	}
	
	/**
	 * Calls the network's nextState() method.
	 */
	public static void nextState(){
		myNet.nextState();
	}

	/**
	 * Calls the networks reset() method.
	 */
	public static void reset(){
		myNet.reset();
	}

	/**
	 * Calls the network's setInput() method.
	 * @param node The input node.
	 * @param amount The input level.
	 */
	public static void addInput(String node, double amount){
		myNet.addInput(node, amount);
	}

	/**
	 * Calls the network's clearInputs() method.
	 */
	public static void clearInputs(){
		myNet.clearInputs();
	}
	
	/*--------------------------------Getters and setters----------------------------*/
	
	/**
	 * @return The default weight for activate edges.
	 */
	public static double getActivateWeight(){
		return activateWeight;
	}	

	/**
	 * @return The weight for block edges.
	 */
	public static double getBlockWeight(){
		return blockWeight;
	}
	
	/**
	 * @return The increase amount for each step in a batch simulation.
	 */
	public static int getBatchStep(){
		return batchStep;
	}
	
	/**
	 * 
	 * @param batchStep The new increase amount for each batch step.
	 */
	public static void setBatchStep(int batchStep){
		SimBoolNetMain.batchStep = batchStep;
	}
	
	/**
	 * 
	 * @param numSteps The amount of steps per simulation.
	 */
	public static void setNumSteps(int numSteps){
		SimBoolNetMain.numSteps = numSteps;
	}
	
	/**
	 * @return The attribute used for activity level.
	 */
	public static String getActivityAttr(){
		return activityAttr;
	}
	
	/**
	 * @return The attribute used for edge weights.
	 */
	public static String getWeightAttr(){
		return weightAttr;
	}
	
	/**
	 * @return The interaction used for activate edges.
	 */
	public static String getActivateInter(){
		return activateInter;
	}
	
	/**
	 * @return The interaction used for block edges.
	 */
	public static String getBlockInter(){
		return blockInter;
	}
	
	/**
	 * @return The amount of steps to run for a single simulation.
	 */
	public static int getNumSteps(){
		return numSteps;
	}
}