package simboolnet;

import giny.model.Edge;
import giny.model.Node;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.Arrays;

import cytoscape.Cytoscape;
import cytoscape.data.Semantics;

public class SimBoolNetModel{

	private Map<String, Double> inputNodes = new HashMap<String, Double>(),
								amountChanged = new HashMap<String, Double>();
	int currentStep = 0;
	
	/*----------------------------------Methods for returning information.----------------------------------*/
	
	/**
	 * @return An array of input nodes (in String form).
	 */
	public String[] getInputNodes(){
		// Check to make sure the list of input nodes doesn't contain any from another network.
		Set<String> inputs = inputNodes.keySet();
		String[] nodes = getNodes();
		Arrays.sort(nodes, String.CASE_INSENSITIVE_ORDER);
		for (String str : inputs)
			if (Arrays.binarySearch(nodes, str, String.CASE_INSENSITIVE_ORDER) < 0)
				inputs.remove(str);
		return inputs.toArray(new String[0]);
	}
	
	/**
	 * @return An array of nodes (in String form).
	 */
	public String[] getNodes(){
		ArrayList<String> nodes = new ArrayList<String>();
		Iterator<Node> nodesIter = Cytoscape.getCurrentNetwork().nodesIterator();
		while (nodesIter.hasNext())
			nodes.add(nodesIter.next().getIdentifier());
		Collections.sort(nodes, String.CASE_INSENSITIVE_ORDER);
		
		return nodes.toArray(new String[0]);
	}
	
	/**
	 * @return An array of edges (in String form).
	 */
	public String[] getEdges(){
		ArrayList<String> edges = new ArrayList<String>();
		Iterator<Edge> edgesIter = Cytoscape.getCurrentNetwork().edgesIterator();
		while (edgesIter.hasNext())
			edges.add(edgesIter.next().getIdentifier());
		Collections.sort(edges, String.CASE_INSENSITIVE_ORDER);
		return edges.toArray(new String[0]);
	}
	
	/**
	 * @param node The node whose activity level is requested.
	 * @return The activity level of the node.
	 */
	public double getNodeActivity(String node){
		try{
			return Cytoscape.getNodeAttributes().getDoubleAttribute(node, SimBoolNetMain.getActivityAttr());
		}catch(NullPointerException e){
			Cytoscape.getNodeAttributes().setAttribute(node, SimBoolNetMain.getActivityAttr(), 0.0);
			
			return 0;
		}
	}
	
	/**
	 * @param node The node whose initial amount is requested.
	 * @return The initial amount (input level for input nodes, 0 for all others) of the node.
	 */
	public double getInitialAmount(String node){
		try{
			return inputNodes.get(node);
		}catch(NullPointerException e){
			return 0;
		}
	}

	/**
	 * @param edge The edge whose weight is requested.
	 * @return The weight of the edge.
	 */
	public double getEdgeWeight(String edge){
		try{
			return Cytoscape.getEdgeAttributes().getDoubleAttribute(edge, SimBoolNetMain.getWeightAttr());
		}catch(NullPointerException e){
			double weight = SimBoolNetMain.getActivateWeight();
			if (Cytoscape.getEdgeAttributes().getStringAttribute(edge, Semantics.INTERACTION).equals(SimBoolNetMain.getBlockInter()))
				weight = SimBoolNetMain.getBlockWeight();
			Cytoscape.getEdgeAttributes().setAttribute(edge, SimBoolNetMain.getWeightAttr(), weight);
			
			return weight;
		}
	}
	
	/**
	 * @param edge The edge whose interaction type is requested.
	 * @return The interaction type of the edge.
	 */
	public String getEdgeInteraction(String edge){
		return Cytoscape.getEdgeAttributes().getStringAttribute(edge, Semantics.INTERACTION);
	}
	
	/*----------------------------------Methods for altering the network.----------------------------------*/
	
	/**
	 * Resets the activity level of every node to 0.
	 */
	public void reset(){
		currentStep = 0;
		amountChanged.clear();
		
		Iterator<Node> nodesIter = Cytoscape.getCurrentNetwork().nodesIterator();
		while (nodesIter.hasNext()){
			String node = nodesIter.next().getIdentifier();
			amountChanged.put(node, 0.0);
			Cytoscape.getNodeAttributes().setAttribute(node, SimBoolNetMain.getActivityAttr(), 0.0);
		}
	}
	
	/**
	 * Adds a node to the list of input nodes.
	 * @param node The new input node.
	 * @param amount The input level of the new input node.
	 */
	public void addInput(String node, double amount){
		inputNodes.put(node, amount);
	}

	/**
	 * Clears the list of input nodes.
	 */
	public void clearInputs(){
		inputNodes.clear();
	}
	
	/**
	 * Set the weight of the specified edge
	 * @param edge The edge whose weight is being set.
	 * @param weight The weight of the edge.
	 */
	public void setEdgeWeight(String edge, double weight){
		Cytoscape.getEdgeAttributes().setAttribute(edge, "Weight", weight);
	}
	
	/**
	 * Calculates the next state in the network. 
	 * This algorithm is modified from a similar algorithm written by Pawel Przytycki.
	 */
	public void nextState()
	{	
		currentStep ++;
		
		// These temp lists will be used to calculate the new activity level at the end of the step. 
		Map<String, ArrayList<Double>> tempActive = new HashMap<String, ArrayList<Double>>(),
									   tempBlock = new HashMap<String, ArrayList<Double>>();
		
		// Prepare nodes and lists for calculation.
		Iterator<Node> nodesIter = Cytoscape.getCurrentNetwork().nodesIterator();
		while (nodesIter.hasNext()) {
			String node = nodesIter.next().getIdentifier();
			tempActive.put(node, new ArrayList<Double>());
			if (inputNodes.keySet().contains(node))
				tempActive.get(node).add(inputNodes.get(node));
			tempBlock.put(node, new ArrayList<Double>());
			if (!amountChanged.containsKey(node))
				amountChanged.put(node, 0.0);
			if (Cytoscape.getNodeAttributes().getDoubleAttribute(node, SimBoolNetMain.getActivityAttr()) == null)
				Cytoscape.getNodeAttributes().setAttribute(node, SimBoolNetMain.getActivityAttr(), 0.0);
		}
		
		// Iterate through nodes, see what each node will activate and block, and add the activation or blockage
		// amount into the respective temp list.
		nodesIter = Cytoscape.getCurrentNetwork().nodesIterator();
		while (nodesIter.hasNext()) {
			String sourceNode = nodesIter.next().getIdentifier();
			if (amountChanged.get(sourceNode) > 0) {
				Iterator<Edge> edgesIter = Cytoscape.getCurrentNetwork().edgesIterator();
				while (edgesIter.hasNext()) {
					Edge e = edgesIter.next();
					if (e.getSource().getIdentifier().equals(sourceNode)) {
						String targetNode = e.getTarget().getIdentifier(),
							interaction = Cytoscape.getEdgeAttributes().getStringAttribute(e.getIdentifier(), 
								Semantics.INTERACTION);
						// activation
						if (interaction.equals(SimBoolNetMain.getActivateInter()))
							tempActive.get(targetNode).add(amountChanged.get(sourceNode) * 
								getEdgeWeight(e.getIdentifier()));
						// blockage
						else if (interaction.equals(SimBoolNetMain.getBlockInter()))
							tempBlock.get(targetNode).add(amountChanged.get(sourceNode) * 
								getEdgeWeight(e.getIdentifier()));
						
					}
				}
			}
		}
		
		amountChanged.clear();
		
		//Update the activity level of each node based on the amounts in the temp lists.
		nodesIter = Cytoscape.getCurrentNetwork().nodesIterator();
		while (nodesIter.hasNext()) {
			String node = nodesIter.next().getIdentifier();
			double act = 1.0, block = 1.0;
			for (double i : tempActive.get(node)) {
				act *= 1.0 - i;
			}
			for (double i : tempBlock.get(node)) {
				block *= 1.0 - i;
			}
			
			//double val = block * (1 - act);
			//double val = (block *(1 - act)) / currentStep;
			double currentAct = 0.01 * Cytoscape.getNodeAttributes().getDoubleAttribute(node, SimBoolNetMain.getActivityAttr());
			double val = (block *(1 - act)) * (1 - currentAct);
			
			// update network state
			amountChanged.put(node, val);						
			Cytoscape.getNodeAttributes().setAttribute(node, SimBoolNetMain.getActivityAttr(), 
				 100.0*(currentAct + val));
		}
	}
}