      ============================================================
      * LDsplit (Association studies of recombination hotspots)  *
      *                       Version 1.0                        *
      *                        2 August, 2013                    *
      *                                                          *
      *          LDsplit is licensed under Open GPL.             *
      *      Copyright (c) 2011-12 by Prof. Jie Zheng		 *
      *      	  School of Computer Engineering		 *
      *     Nanyang Technological University, Singpoare          *
      *     		Email: ZhengJie@ntu.edu.sg          	 *
      *                   All rights reserved.                   *
      ============================================================


Thank you for your interest in LDsplit!  As we continue to
improve LDsplit, updated versions will be made available on the LDsplit website, 
whose URL is:

http://www.ntu.edu.sg/home/zhengjie/software/LDsplit.htm


If you are reading this file, you have probably successfully unzipped the
LDsplit.zip file.  Here's what we've included:

  README.txt    	What you are currently reading
  LDsplit_manual	User manual of LDsplit

  LICENSE.txt   	An overview of how LDsplit may be licensed, along with the
                	full text of the Non-Commercial Use License Agreement;
                	please read this carefully before proceeding to use LDsplit

  LDsplit.jar   	A Java archive file containing all the compiled LDsplit code,
                	which you can use to run LDsplit

  toy raw input data/   Toy test data (sites and locs files) for LDsplit Users which 
			were downloaded from Hapmap. They are in the format of 
			LDhat (http://www.stats.ox.ac.uk/~mcvean/LDhat/instructions.html)
		
  toy result file/	The JAVA serialization file containing recombination profiles, 
			which can be loaded back to LDsplit for visualization

  src/          	A directory containing the Java source code of LDsplit

  Lookup/		Look-up tables used by LDhat for speed of computation

  Win32/		Executable files of LDhat runnable under Windows

  Linux/		Executable files of LDhat runnable under Linux (tested on Ubuntu 8, Fedora 18)

  Mac/			Executable files of LDhat runnable under Mac (tested on Mac lion 10.7)
  
For more details of installation and usage, please check out the user manual of LDsplit,
also available at  URL:

http://www.ntu.edu.sg/home/zhengjie/software/LDsplit/LDsplit_manual.pdf

Note: 

1. After unzipping the LDsplit package (using say WinZip), please do NOT move LDsplit.jar file 
outside the original folder, because it need to find the lookup files in the "Lookup" folder. 
For convenient access under Windows, you may create a shortcut to the LDsplit.jar file and 
paste the shortcut link in any folder you like (such as the desktop). 

2. LDsplit takes some time to finish the running of "Calculate recombination profiles". After 
you load input files, set the parameters and push the "Start" button, the progress bar may appear 
"frozen" for the first few minutes (depending on input size and parameters), but actually it is 
running. After a while, the progress bar will show percentage of work already done. Your patience 
is very much appreciated.


For any questions or comments, please feel free to contact Dr. Jie Zheng 
by email: zhengjie@ntu.edu.sg. Thank you!


Last updated: 2nd August, 2013
