/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package ld_split_graphy_interface;

/**
 *
 * @author Yang Peng  2011.Nov.19, NTU, Singpaore
 */

public class ConfigureContainer {

       private static String JudgeVisualization = null;
       private static String finalresultFile = null;
       private static String sitesFile = null;
       private static String locsFile = null;
       private static String OutputFile = "outputFile";
       private static String VisualizationResultFilePath = null;
       private static Integer RandomSampleNumber = 100;
       private static Integer IterationTime = 20000;
       private static Integer Rhomap_Samp = 200;
       private static Integer Rhomap_Burn = 1000;
       private static Double MAF = 0.3;
       private static boolean RadioChoice = false;
       private static String legendFile = null;
       private static String phaseFile = null;
       private static Integer startsnp = 1;
       private static Integer endsnp = 10;


       public static boolean CheckingParameter(){
             if(IterationTime < 5000){
                 ParameterChecking.ErrorInforming("IterationTime should be larger than 5,000");

                 return false;
             }
 
             if(Rhomap_Samp < 100 || Rhomap_Samp > (IterationTime*0.1) ){
                 ParameterChecking.ErrorInforming("Rhomap_Samp should be more than 100 and less than one fifth of Rhomap -ite");

                 return false;
             }

             if(Rhomap_Burn <= 0){
                 ParameterChecking.ErrorInforming("Rhomap_Burn should be Positive Integer");
                 return false;
             }
 
             if(RandomSampleNumber < 50 || RandomSampleNumber > 1000){
                 ParameterChecking.ErrorInforming("Number of Permutation should be between 50 and 1000");
                 return false;
             }

             if(MAF < 0 || MAF > 1){
                ParameterChecking.ErrorInforming("Value scale of MAF is between 0 and 1");
             }


             if( sitesFile.equals("")  || locsFile.equals("") ){
                 ParameterChecking.ErrorInforming("inputfile should not be null");
                 return false;
             }
             
             return true;
       }

       public static boolean CheckingParameter1() {
    	   if( legendFile.equals("")  || phaseFile.equals("")  ){
          	 ParameterChecking.ErrorInforming("inputfile should not be null");
          	 return false;
           }

           if( startsnp<=0  || endsnp<=0  ){
          	 ParameterChecking.ErrorInforming("start snp and end snp should be positive integer");
          	 return false;
           }
           
           if( endsnp <= startsnp ){
          	 ParameterChecking.ErrorInforming("start snp should be smaller than end snp ");
          	 return false;
           }
           
           return true;
   			
       }
       
       public static void SetVisualizationChoice(String VisualizationChoice) {
             JudgeVisualization = VisualizationChoice;
       }

       public static String GetVisualizationChoice(){
            return JudgeVisualization;
       }

       public static void SetRadioChoice(boolean radioChoice) {
             RadioChoice = radioChoice;
       }

       public static boolean GetRadioChoice(){
            return RadioChoice;
       }

       public static void SetFinalResultFile(String finalresult){
             finalresultFile = finalresult;
       }

       public static String GetFinalResultFile(){
             return finalresultFile;
       }

       public static void SetSitesFile(String sitesfile){
             sitesFile = sitesfile;
       }

       public static String GetSitesFile(){
             return sitesFile;
       }

       public static void SetLocsFile(String locsfile){
             locsFile = locsfile;
       }

       public static String GetLocsFile(){
             return locsFile;
       }

       public static void SetOutputFile(String outputfile){
            OutputFile = outputfile;
       }

       public static String GetOutputFile(){
             return OutputFile;
       }

       public static void SetVisualizationResultFilePath(String Path){
             VisualizationResultFilePath = Path;
       }

       public static String GetVisualizationResultFilePath(){
              return VisualizationResultFilePath;
       }

       public static void SetIterationTime(Integer iterationTime){
             IterationTime =  iterationTime;
       }

       public static Integer GetIterationTime(){
             return IterationTime;
       }

       public static void SetRhomap_Samp(Integer rhomap_Samp){
             Rhomap_Samp = rhomap_Samp;
       }

       public static Integer GetRhomap_Samp(){
             return Rhomap_Samp;
       }

       public static void SetRhomap_Burn(Integer rhomap_Burn){
             Rhomap_Burn = rhomap_Burn;
       }

       public static Integer GetRhomap_Burn(){
             return Rhomap_Burn;
       }

       public static void SetRandomSample(Integer sampleNumber){
             RandomSampleNumber =  sampleNumber;
       }

       public static Integer GetRandomSample(){
             return RandomSampleNumber;
       }

       public static void SetMAF(Double maf){
             MAF = maf;
       }

       public static Double GetMAF(){
            return MAF;
       }

	public static String GetLegendFile() {
		// TODO Auto-generated method stub
		return null;
	}

	public static String GetPhaseFile() {
		// TODO Auto-generated method stub
		return null;
	}

	public static Object GetStartSnp() {
		// TODO Auto-generated method stub
		return null;
	}

	public static Object GetEndSnp() {
		// TODO Auto-generated method stub
		return null;
	}

	public static String GetSampleFile() {
		// TODO Auto-generated method stub
		return null;
	}

	public static String getLegendFile() {
		return legendFile;
	}

	public static void setLegendFile(String legendFile) {
		ConfigureContainer.legendFile = legendFile;
	}

	public static String getPhaseFile() {
		return phaseFile;
	}

	public static void setPhaseFile(String phaseFile) {
		ConfigureContainer.phaseFile = phaseFile;
	}

	public static Integer getEndsnp() {
		return endsnp;
	}

	public static void setEndsnp(Integer endsnp) {
		ConfigureContainer.endsnp = endsnp;
	}

	public static Integer getStartsnp() {
		return startsnp;
	}

	public static void setStartsnp(Integer startsnp) {
		ConfigureContainer.startsnp = startsnp;
	}


}
