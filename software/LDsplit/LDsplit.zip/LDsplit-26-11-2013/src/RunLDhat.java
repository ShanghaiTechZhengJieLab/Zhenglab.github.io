package ld_split_graphy_interface;

import java.awt.Frame;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Random;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;


class StreamCleaner extends Thread
{
	InputStream is;
	String type;

	StreamCleaner(InputStream is, String type) {
		this.is = is;
		this.type = type;
	}

	public void run() {
		try {
			InputStreamReader isr = new InputStreamReader(is);
			BufferedReader br = new BufferedReader(isr);
			String line = null;
			while ( (line = br.readLine()) != null) {
				//System.out.println(type + ">" + line);
			}

		} catch (Exception ioe) {
		    ParameterChecking.ErrorInforming(ioe.toString());
                    ParameterChecking.ErrorInforming("Running process failed. Please check the LDHat executable files.");
                    ioe.printStackTrace();
                    System.exit(0);
                    return;
		}
	}

}


class RunLDhat
{
	// External applications and data
	private String exe_dir = null;
	private String rhomap_cmd = null;
	private String lkgen_cmd = null;
	private String stat_cmd = null;
	private String lkFileDir = null;
	// input files
	private String sitesFile = null;
	private String locsFile = null;
        private String Iteration = "20000";  //default number of Rhomap -Its
        private String Rhomap_Samp = "200";  //default number of Rhomap -Samp
        private String Rhomap_Burn = "1000"; //default number of Rhomap -Burn

	// a unique folder to store intermediate files (like rates.txt and res.txt)
	// to avoid name conflicts among multiple LDhat runs
	
	// output data
	private ArrayList<Float> meanRhoList = new ArrayList<Float>();
	// constructor
	public RunLDhat(String sites_file, String locs_file)
	{
		sitesFile = sites_file;
		locsFile = locs_file;
                if(ConfigureContainer.GetIterationTime() != 0)
                    Iteration = Integer.toString(ConfigureContainer.GetIterationTime());
                if(ConfigureContainer.GetRhomap_Samp() != 0)
                    Rhomap_Samp = Integer.toString(ConfigureContainer.GetRhomap_Samp());
                if(ConfigureContainer.GetRhomap_Burn() != 0)
                    Rhomap_Burn = Integer.toString(ConfigureContainer.GetRhomap_Burn());

		initConfigure();
		// create a unique directory for running LDhat
		Random generator = new Random();
		Integer r = new Integer(generator.nextInt());
		runDir = new File("run_" + r.toString());
                //System.out.println("runDir--------------------: " + runDir);
		if ( ! runDir.mkdir() ) {
			System.out.println("Fail to create directory" + runDir);
			System.exit(1);
		}
		// TODO: adjust parameters of LDhat

	}

        private static File pRinFile = null;
        private static File LkinFile = null;
        private static Process proc = null;
        public static File runDir = null;
        
        public static void kissprocess() 
        {
            try {
                Thread.sleep(500);
            } catch (InterruptedException ex) {
                Logger.getLogger(RunLDhat.class.getName()).log(Level.SEVERE, null, ex);
            }
            proc.destroy();
        }


	private void initConfigure()
	{
		String osName = System.getProperty("os.name").toLowerCase();
		
		System.out.println("OS: " + osName); // debug

                String path = new File(getClass().getResource("").getPath()).getParentFile().getParentFile().getPath();
                
                path = path.substring(6, path.length());
                path = path.replaceAll("%20"," ");
                path = path.replaceAll("/", "\\\\");
                System.out.println("the path is: "+path);


		//if (osName.equals("Windows NT") || osName.equals("Windows 7") || osName.equals("Windows XP") || osName.equals("Windows 8")) {
		if(osName.indexOf("win") >= 0) {
                		exe_dir ="G:\\program_project\\LD_Split_software\\java_project\\ldhat_exe\\";

                        rhomap_cmd = path + "\\Win32\\rhomap.exe";
                        lkgen_cmd = path + "\\Win32\\lkgen_VS2.exe";
                        stat_cmd = path + "\\Win32\\stat.exe";
						lkFileDir = path + "\\Lookup\\";
                        String command = lkgen_cmd + " -lk " + lkFileDir + " -nseq ";
                        System.out.println("the command is " + command);


		} //else if (osName.equals("Linux") || osName.equals("Unix")) {
		else if(osName.indexOf("linux")>=0){
						//exe_dir = "/home/zhengj/project/LDsplit_java/ldhat_exe/";
						String pathlinux = new File(getClass().getResource("").getPath()).getParentFile().getParentFile().getPath();
                        System.out.println("the route of LDhat is:///////////////////////// "+pathlinux);
                        pathlinux = pathlinux.substring(5, pathlinux.length());
                        pathlinux = pathlinux.replaceAll("%20"," ");
                        System.out.println("the path of LDhat under linux is:///////////////////////// "+pathlinux);
                        exe_dir = "/media/HENRY_YANG/";
                        rhomap_cmd = pathlinux + "/Linux/rhomap";
                        lkgen_cmd = pathlinux + "/Linux/lkgen";
                        stat_cmd = pathlinux + "/Linux/stat";
                        lkFileDir = pathlinux + "/Lookup/";
		} //else if (osName.equals("Mac")) {
		else if(osName.indexOf("mac")>=0) {
			//exe_dir = "/home/zhengj/project/LDsplit_java/ldhat_exe/";
			String pathMac = new File(getClass().getResource("").getPath()).getParentFile().getParentFile().getPath();
            System.out.println("the route of LDhat is:///////////////////////// "+pathMac);
            pathMac = pathMac.substring(5, pathMac.length());
            pathMac = pathMac.replaceAll("%20"," ");
            System.out.println("the path of LDhat under Mac is:///////////////////////// "+pathMac);
            exe_dir = "/media/HENRY_YANG/";
            rhomap_cmd = pathMac + "/Mac/rhomap";
            lkgen_cmd = pathMac + "/Mac/lkgen";
            stat_cmd = pathMac + "/Mac/stat";
            lkFileDir = pathMac + "/Lookup/";
			
		}
		

	}


	private static boolean deleteDir(File dir) {
		if (dir.isDirectory()) {
			String[] children = dir.list();
			for (int i=0; i < children.length; i++) {
				if (! (deleteDir(new File(dir, children[i]))) ) {
					return false;
				}
			}
		}
		return dir.delete();
	}


	private void runRhomap() {

		try {
			// generate lk file on the fly using lkgen
			getLk(sitesFile);

			String parameter = " -its "+Iteration+" -samp "+Rhomap_Samp+" -burn "+Rhomap_Burn+" -no_file";
                        // " -its 20000 -samp 200 -burn 1000 -prefix test -no_file"
			String command = rhomap_cmd + " -seq " + sitesFile.replaceAll(" ", "\" \"") + " -loc " + locsFile.replaceAll(" ", "\" \"") +
					" -lk " + runDir.getAbsolutePath() + System.getProperty("file.separator") + "new_lk.txt"
					+ parameter;

			Runtime rt = Runtime.getRuntime();
			proc = rt.exec(command, null, runDir);                            //  run LDhat programme

			StreamCleaner outputCleaner = new StreamCleaner(proc.getInputStream(), "OUTPUT");
			StreamCleaner errorCleaner = new StreamCleaner(proc.getErrorStream(), "ERROR");
			errorCleaner.start();
			outputCleaner.start();

			// test ------------------------
			// Under Windows, send "Return" key to rhomap.exe to terminate
			PrintWriter pw = new PrintWriter(new OutputStreamWriter(proc.getOutputStream()));
			pw.write('\n');
			pw.flush();
			//------------------------------

			int exitVal = proc.waitFor();
			if (exitVal != 0) {
				System.err.println("Process exitValue in runRhomap(): " + exitVal);
			}

		} catch (Throwable t) {
			t.printStackTrace();
                        ParameterChecking.ErrorInforming(t.toString());
                        ParameterChecking.ErrorInforming("Running process failed. Please check the LDHat executable files");
                        System.exit(0);
                        return;
		}

	}

	private void runStat(String infile)
	{
		String command = stat_cmd + " -input " + infile.replaceAll(" ", "\" \"") + " -burn 10";
		try {
			Runtime rt = Runtime.getRuntime();
			proc = rt.exec(command, null, runDir);

			StreamCleaner outputCleaner = new StreamCleaner(proc.getInputStream(), "OUTPUT");
			StreamCleaner errorCleaner = new StreamCleaner(proc.getErrorStream(), "ERROR");
			errorCleaner.start();
			outputCleaner.start();

			int exitVal = proc.waitFor();
			if (exitVal != 0) {
				System.err.println("Process exitValue in runStat(): " + exitVal);
			}

		} catch (Throwable t) {
			t.printStackTrace();
                        ParameterChecking.ErrorInforming(t.toString());
                        ParameterChecking.ErrorInforming("Running process failed. Please check the LDHat executable files.");
                        System.exit(0);
                        return;
		}
	}

	private void parseRho(String infileName) throws FileNotFoundException
	{
		pRinFile = new File(runDir, infileName);
		Scanner scanner = new Scanner(new FileReader(pRinFile));
		//ArrayList<Float> meanRhoList = new ArrayList<Float>();
		try {
			String head = scanner.nextLine();
			while (scanner.hasNextLine()) {
				String line = scanner.nextLine();
				// get mean rho values
				String[] items = line.split("\\s+");
				meanRhoList.add(Float.valueOf(items[2]));
			}
		} finally {
			scanner.close();
		}

		meanRhoList.remove(0); // remove the total distance
	}

	public ArrayList<Float> getMeanRhoList()
	{
		return meanRhoList;
	}

	// 12/3/10
	private void getLk(String siteFile) throws FileNotFoundException
	{
		// get number of sequences
            System.out.println("getLK_scanner before");
		LkinFile = new File(siteFile);
		Scanner scanner = new Scanner(new FileReader(LkinFile));
		int numSeq = -1;
                System.out.println("getLK_scanner");
		try {
			if (scanner.hasNext()) {
				String line = scanner.nextLine();
				String[] items = line.split("\\s+");
				numSeq = Integer.parseInt(items[0]);

			} else {
				System.out.println("Cannot recognize site file of " + siteFile);
			}
		} finally {
			scanner.close();
		}
 System.out.println("getLK_scanner after");
		// select a precomputed lk file
		String existLkFile = null;
		if (numSeq <= 50) {
			existLkFile = "lk_n50_t0.001";
		} else if (numSeq <= 100) {
			existLkFile = "lk_n100_t0.001";
		} else if (numSeq <= 120) {
			existLkFile = "lk_n120_t0.001";
		} else if (numSeq <= 192) {
			existLkFile = "lk_n192_t0.001";
		} else {
			System.out.println("Input number of sequences is too big: " + numSeq);
		}

		// call lkgen
		String command = lkgen_cmd + " -lk " + lkFileDir.replaceAll(" ", "\" \"") + existLkFile + " -nseq " + numSeq;
                
                System.out.println("the command is " + command);
		try {
			Runtime rt = Runtime.getRuntime();
			proc = rt.exec(command, null, runDir);
                        
			StreamCleaner inputCleaner = new StreamCleaner(proc.getInputStream(), "INPUT");
			StreamCleaner errorCleaner = new StreamCleaner(proc.getErrorStream(), "ERROR");

                        errorCleaner.start();
			inputCleaner.start();
                        //outputCleaner.start();

                        PrintWriter pw = new PrintWriter(new OutputStreamWriter(proc.getOutputStream()));
			pw.write("\n");
			pw.flush();

                        System.out.println("getLK_scanner waiting before");

			int exitVal = proc.waitFor();
                        System.out.println("getLK_scanner waiting after");
			if (exitVal != 0) {
				System.err.println("Process exitValue in getLk(): " + exitVal);
			}
		} catch (Throwable t) {
			t.printStackTrace();
                        ParameterChecking.ErrorInforming(t.toString());
                        ParameterChecking.ErrorInforming("Running process failed. Please check the LDHat executable files.");
                        System.exit(0);
                        return;
		}
	}

	public boolean run()
	{
		runRhomap();
		runStat("rates.txt");
		try {
			parseRho("res.txt");
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
                        ParameterChecking.ErrorInforming(e.toString());
                        ParameterChecking.ErrorInforming("Running process failed. Please check the LDHat executable files.");
                        System.exit(0);
                        return false;
		}
		// clean up
		if (! deleteDir(runDir) ) {
			System.out.println("Fail to delete directory " + runDir.toString());
		}
                return true;
	}

}


