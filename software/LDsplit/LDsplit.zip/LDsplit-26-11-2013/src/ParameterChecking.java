/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package ld_split_graphy_interface;

import java.awt.Frame;
import javax.swing.JOptionPane;





/**
 *
 * @author Yang Peng
 * created in October 2011
 */
public class ParameterChecking {

       public static void ErrorInforming(String ErrorInformation){
              Frame notice = new Frame();
              JOptionPane.showMessageDialog(notice, ErrorInformation);
       }

}
