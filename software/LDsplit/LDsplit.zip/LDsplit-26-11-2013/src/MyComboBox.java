package ld_split_graphy_interface;

import java.awt.*;
import javax.swing.*;

class MyComboBox extends AbstractListModel implements ComboBoxModel {
	String selecteditem = null;
	private String[] test;
		
	public MyComboBox(String[] test){
		this.test = test;
	}
	
	public Object getSelectedItem() {
	   return selecteditem;
	}
	public void setSelectedItem(Object item) {
	   selecteditem = (String) item;
	}
	public Object getElementAt(int index) {
	   return test[index];
	}
	public int getSize() {
	   return test.length;
	}
	public int getIndex() {
	   for (int i = 0; i < test.length; i++) {
	    if (test[i].equals(getSelectedItem()))
	     return i;
	    break;
	   }
	   return 0;
	}
}