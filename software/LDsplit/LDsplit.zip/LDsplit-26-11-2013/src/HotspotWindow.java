// Author: Yang Peng, Nov. 19th, 2011, NTU, Singapore
// last update: Nov. 19th, 2011

package ld_split_graphy_interface;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Serializable;
import java.io.Writer;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Random;
import java.util.Scanner;
//
// A class to host SNP data and running LDsplit
// Author: Jie Zheng, at NCBI/NLM/NIH, email: zhengj@ncbi.nlm.nih.gov
// Created: 09 Dec. 2010
// Last updated: 16 Dec. 2010


public class HotspotWindow implements Serializable
{

	ArrayList<String> hapSeq = new ArrayList<String>();
	ArrayList<Float> snpPos = new ArrayList<Float>(); // in unit of kb

	Double minMaf = ConfigureContainer.GetMAF();
	ArrayList<Float> snpMaf = new ArrayList<Float>();
	// whole and split rho maps
	ArrayList<Float> wholeRhoMap = new ArrayList<Float> ();

	public class PairRhoMap implements Serializable
	{
		ArrayList<Float> r0 = new ArrayList<Float> ();
		ArrayList<Float> r1 = new ArrayList<Float> ();

		public void set(ArrayList<Float> mRhoA, ArrayList<Float> mRhoB) {
			r0 = mRhoA;
			r1 = mRhoB;
		}

		public ArrayList<Float> get(int allele) {
			if (allele == 0) {
				return r0;
			} else if (allele == 1) {
				return r1;
			} else {
				System.err.println("allele is not 0 or 1: " + Integer.toString(allele));
				return null;
			}
		}
	}

        HashMap<Integer, PairRhoMap> splitRhoMaps = new HashMap<Integer, PairRhoMap>();
        HashMap<Integer, PairRhoMap> RandomRhoMaps = new HashMap<Integer, PairRhoMap>();


        public HashMap<Integer, PairRhoMap> GetHashMap(){
            return splitRhoMaps;
        }


        public HashMap<Integer, PairRhoMap> GetRandomHashMap(){
            return RandomRhoMaps;
        }

        
        public ArrayList<Float> GetWholeRhoMap()
        {
            return wholeRhoMap;
        }


        public ArrayList<Float> GetSNPMAF ()
        {
            return snpPos;
        }

	// constructor
	public HotspotWindow() {

	}

	// load SNP data in LDhat format
	public boolean loadSnp(String sitesFileName, String locsFileName) throws FileNotFoundException
	{
		// parse sites files
		File sitesFile = new File(sitesFileName);
		Scanner scanner = new Scanner(new FileReader(sitesFile));
		int numSeq = 0;
                int numSNIP = 0;
		try {
			if(scanner.hasNext()) {
				String line = scanner.nextLine();
				String[] items = line.split("\\s+");
				numSeq = Integer.parseInt(items[0]);
                                numSNIP = Integer.parseInt(items[1]);
                                System.out.println("numSeq: "+numSeq);
			}

			int seqCount = 0;
			while (scanner.hasNext()) {
				String line = scanner.nextLine();
				if ( line.startsWith(">") == false ) {
					hapSeq.add(line);
					seqCount ++;
                                }
			}
                        System.out.println("seqCount: "+seqCount);
                        if(seqCount != numSeq){
                                    ParameterChecking.ErrorInforming("number of Permutation unequal to annotation in site file");
                                    return false;
                                }
                        assert(seqCount == numSeq);
                        
		}catch(Exception ex)
                {
                        System.out.print(ex);
                        ParameterChecking.ErrorInforming("Something wrong in site file, please check the format of site file.");
                        return false;
                }finally {
			scanner.close();
		}

		// parse locs file
		File locsFile = new File(locsFileName);
		scanner = new Scanner(new FileReader(locsFile));
		try {
			int numSnp = 0;
			if (scanner.hasNext()) {
				String line = scanner.nextLine();
				String[] items = line.split("\\s+");
				numSnp = Integer.parseInt(items[0]);
			}

			int snpCount = 0;
			while (scanner.hasNext()) {
				String line = scanner.nextLine();
				snpPos.add(new Float(line));
				snpCount ++;
			}
                        if(numSnp != snpCount){
                            ParameterChecking.ErrorInforming("Number of SNIP unequal to annotation in locs file");
                            return false;
                        }
                        System.out.println("numSNIP: "+snpCount);
                        if(numSNIP != snpCount){
                            ParameterChecking.ErrorInforming("Number of SNIP in locs file unequal to one in site file");
                            return false;
                        }
                        assert(numSnp == snpCount);
		
                }catch(Exception ex){
                        System.out.print(ex);
                        ParameterChecking.ErrorInforming("Something wrong in loc file, please check the format of loc file.");
                        return false;
                }finally {
			scanner.close();
		}

		// check consistency of data
		Iterator<String> itr = hapSeq.iterator();
		while (itr.hasNext()) {
			String hap = (String)itr.next();
			// TODO: allow other type of letters like [ACGT?]

			if (hap.length() != snpPos.size()) {
				ParameterChecking.ErrorInforming("Haplotype length unequal to number of SNP");
                                System.out.println("Haplotype length unequal to number of SNP");
				return false;
			}
		}
		return true;
	}

	// debug
	public boolean test_snp()
	{
		System.out.println("number of haplotypes: " + hapSeq.size());
		if(hapSeq.size() < 20 || hapSeq.size() > 192)  return false;

                for (int i = 0; i < hapSeq.size(); ++i) {
			System.out.println(hapSeq.get(i));
		}

		System.out.println("SNP locations: ");
		for (int i=0; i < snpPos.size(); ++i) {
			System.out.println(snpPos.get(i).toString());
		}

                return true;
	}

	// calculate MAFs (minor allele frequencies) of SNPs
	public void countMaf()
	{
		for (int i=0; i < snpPos.size(); ++i) {
			int num0 = 0;
			int num1 = 0;
			char firstChar = hapSeq.get(0).charAt(i);
                        for (int j = 0; j < hapSeq.size(); ++j) {
				String hap = hapSeq.get(j);
				if(hap.charAt(i) == '0' || hap.charAt(i) == '1')
                                {
                                    if (hap.charAt(i) == '0') {
					num0 ++;
                                    } else {
                                            num1 ++;
                                    }
                                }
                                else{ // allow other type of data, such as 'ATGC'
                                    if (hap.charAt(i) == firstChar)
                                        num0 ++;
                                    else
                                        num1 ++;
                                }
			}
			assert(num0 + num1 == hapSeq.size());
			Float maf = (float)num0 / (float)hapSeq.size();
			if (maf > 0.5) {
				maf = 1 - maf;
			}
			snpMaf.add(maf);
		}
	}


	// split haplotype samples
	private void splitPopu(int snpId, ArrayList<String> hap0, ArrayList<String> hap1)
	{
	      char OneType = hapSeq.get(0).charAt(snpId);
              for (int i = 0; i < hapSeq.size(); ++i) {
			String hap = hapSeq.get(i);
			char allele = hap.charAt(snpId);
			if (allele == '0') {
				hap0.add(hap);
			} else if (allele == '1') {
				hap1.add(hap);
			}
                        if(allele != '0' && allele != '1')
                        {
				
                                if(allele == OneType){
                                   hap0.add(hap);
                                }else {
                                   hap1.add(hap);
                                   //return;
                                }
                         }
		}
	}


        // randomly split haplotype samples
        private void splitPopuRandom(int snpId, ArrayList<String> hap0, ArrayList<String> hap1)
        {
            ArrayList<Integer> RandomList = new ArrayList<Integer> ();
            Random generator = new Random();
            Integer scalenumber = new Integer(hapSeq.size());
            // randomly generate 0~99 list
            while(RandomList.size() < scalenumber){
                 Integer randomInt = new Integer( generator.nextInt(hapSeq.size()) );  //
                 if( !RandomList.contains(randomInt) ){
                     RandomList.add(randomInt);
                 }
            }
            
            Integer SplitNum = new Integer(generator.nextInt((int)(hapSeq.size()*0.4))+(int)(hapSeq.size()*0.3));
            // select random strings in hapSeq into hap0;
            Integer RandomIndex = new Integer(0);
            while(RandomIndex < SplitNum){
                Integer HapMapIndex = RandomList.get(RandomIndex);
                hap0.add( hapSeq.get(HapMapIndex) );
                RandomIndex++;
            }
            // select random strings in hapSeq into hap1
            while(RandomIndex< scalenumber){
                 Integer HapMapIndex = RandomList.get(RandomIndex);
                 hap1.add( hapSeq.get(HapMapIndex));
                 RandomIndex++;
            }

        }

	// calculate rho map of a sub-sample of haplotypes
	public ArrayList<Float> subRhomap(ArrayList<String> subHap)
	{
		// export a sub-sample in LDhat format
		Random generator = new Random();
		Integer randInt = new Integer( generator.nextInt() );
		String uniqueSuffix = randInt.toString();
		// get absolute path to the sub files
		String currentDir = System.getProperty("user.dir");
		String subSiteFile = currentDir + "/subSite" + uniqueSuffix;
		String subLocFile = currentDir + "/subLoc" + uniqueSuffix;

		try {
			exportLDhatData(subHap, snpPos, subSiteFile, subLocFile);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
                System.out.println("runldhat start");
		// call LDhat
		
                RunLDhat mLDhat_runner = new RunLDhat(subSiteFile, subLocFile);
                if(mLDhat_runner.run() == false)
                {
                    ParameterChecking.ErrorInforming("Running process failed. Please check the LDHat executable files.");
                    System.exit(0);
                }

                System.out.println("runldhat start");
		// clean up sub-sample files
		File siteFile = new File(subSiteFile);
		if (siteFile.exists()) {
			boolean successDel = siteFile.delete();
			if (!successDel) {
				throw new IllegalArgumentException("fail to delete file " + subSiteFile);
			}
		}      

		File locFile = new File(subLocFile);
		if (locFile.exists()) {
			boolean successDel = locFile.delete();
			if (!successDel) {
				throw new IllegalArgumentException("fail to delete file " + locFile);
			}
		}        
		// return rho maps
		return mLDhat_runner.getMeanRhoList();
	}

	// export SNP data in LDhat format
	public void exportLDhatData(ArrayList<String> hapSeq, ArrayList<Float> snpPos,
								 String newSiteFile, String newLocFile)
									throws FileNotFoundException, IOException
	{
		int numSnp = hapSeq.get(0).length();
		// write sites
		File siteFile = null;
		try {
			siteFile = new File(newSiteFile);
			if (!siteFile.exists()) {
				siteFile.createNewFile();
			}
		} catch ( SecurityException securityException) {
			System.err.println("You do not have write access to this file.");
			System.exit(1);
		}

		if (!siteFile.canWrite()) {
			throw new IllegalArgumentException("File cannot be written: " + siteFile);
		}

		Writer output = new BufferedWriter( new FileWriter(siteFile) );
		try {
			String headline = String.format("%d %d %d", hapSeq.size(), numSnp, 1);
			output.write(headline + "\n");
			for (int i = 0; i < hapSeq.size(); ++i) {
				String seqId = String.format(">seq%d", i);
				output.write(seqId + "\n" + hapSeq.get(i) + "\n");
			}
		} finally {
			output.close();
		}

		// write locs
		File locFile = new File(newLocFile);
		if (!locFile.exists()) {
			locFile.createNewFile();
		}

		if (!locFile.canWrite()) {
			throw new IllegalArgumentException("File cannot be written: " + locFile);
		}
		Writer locOutput = new BufferedWriter( new FileWriter(locFile) );
		try {
			float regionLength = snpPos.get(snpPos.size() - 1) - snpPos.get(0);
			String headline = String.format("%d %f L", numSnp, regionLength);
			locOutput.write(headline + "\n");
			for (int i = 0; i < snpPos.size(); ++i) {
				locOutput.write(snpPos.get(i).toString() + "\n");
			}
		} finally {
			locOutput.close();
		}

	}

        // LDHat samples
        public void WholeRhoSnp()
	{
		// check maf

		ArrayList<String> hap0 = new ArrayList<String> ();

		for (int i = 0; i < hapSeq.size(); ++i) {
                        String hap = hapSeq.get(i);
                        hap0.add(hapSeq.get(i));
               }
                // calculate split rho maps of sub-samples
                
		wholeRhoMap = subRhomap(hap0);
                
                ///////////////////////////////////// test programming
                System.out.println("wholeRhoMap: "+wholeRhoMap.size());
                Iterator iterator =  wholeRhoMap.iterator();
                while(iterator.hasNext())
                {
                    System.out.print(iterator.next()+" ");
                }
                System.out.println();
	}


	// split haplotype samples by a SNP
	public void splitOneSnp(int snpId)
	{
		// check maf
		assert(snpMaf.get(snpId) >= minMaf);
		// get two samples of haplotypes with 0 allele and 1 allele
		ArrayList<String> hap0 = new ArrayList<String> ();
		ArrayList<String> hap1 = new ArrayList<String> ();

		splitPopu(snpId, hap0, hap1);    // divide sequence to two parts

		ArrayList<Float> r0 = new ArrayList<Float> ();
		ArrayList<Float> r1 = new ArrayList<Float> ();
		r0 = subRhomap(hap0);
		r1 = subRhomap(hap1);

                ///////////////////////////////////// test programming
                System.out.println("ro: "+r0.size());
                Iterator iterator =  r0.iterator();
                while(iterator.hasNext())
                {
                    System.out.print(iterator.next()+" ");
                }
                System.out.println();
                /////////////////////////////////////////////////////////////

		// save rho maps
		PairRhoMap splitRho = new PairRhoMap();
		splitRho.set(r0, r1);
		splitRhoMaps.put(new Integer(snpId), splitRho);

	}

        public void splitOneSnpRandom(int snpId)
        {
                //assert(snpMaf.get(snpId) >= minMaf);
		// get two samples of haplotypes with 0 allele and 1 allele
                //ArrayList<Float> R0 = new ArrayList<Float> ();
                //ArrayList<Float> R1 = new ArrayList<Float> ();
		ArrayList<String> hap0 = new ArrayList<String> ();
		ArrayList<String> hap1 = new ArrayList<String> ();

		splitPopuRandom(snpId, hap0, hap1);    // divide sequence to two parts
		// calculate split rho maps of sub-samples
		ArrayList<Float> r0 = new ArrayList<Float> ();
		ArrayList<Float> r1 = new ArrayList<Float> ();
		r0 = subRhomap(hap0);
		r1 = subRhomap(hap1);

                System.out.println("ro: "+r0.size());
                Iterator iterator =  r0.iterator();
                while(iterator.hasNext())
                {
                    System.out.print(iterator.next()+" ");
                }
                System.out.println();

		// save rho maps
		PairRhoMap splitRho = new PairRhoMap();
		splitRho.set(r0, r1);
		//splitRhoMaps.put(new Integer(snpId), splitRho);
                RandomRhoMaps.put(new Integer(snpId), splitRho);
        }

	// Return IDs of "split SNPs" qualified by MAF
	public ArrayList<Integer> splitSnps()
	{
		countMaf();
		ArrayList<Integer> splitSnp = new ArrayList<Integer>();
		for (int i=0; i < snpPos.size(); ++i) {
			if (snpMaf.get(i) >= minMaf) {
				splitSnp.add( new Integer(i) );
			}
		}
		return splitSnp;
	}
	// split scan with progress bar
	// out of date: move to the SwingWorker subclass of LDsplitRunner
	public void splitScan()
	{
		countMaf();
		for (int i=0; i < snpPos.size(); ++i) {
			if (snpMaf.get(i) >= minMaf) {
				splitOneSnp(i);

				// for debug
				System.out.println("finish SNP " + i + " out of " + snpPos.size());
			}
		}
		// debug--------------
		// output all split rho maps
		for (Integer snpId : splitRhoMaps.keySet()) {
			PairRhoMap pairRho = splitRhoMaps.get(snpId);

			System.out.println("split at SNP " + snpId.toString() + "\n");
			ArrayList<Float> r0 = pairRho.get(0);
			ArrayList<Float> r1 = pairRho.get(1);
			System.out.println("r0: " + r0);
			System.out.println("r1: " + r1);
		}

	}

}




