package ld_split_graphy_interface;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FileDialog;
import java.awt.Frame;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingWorker;

@SuppressWarnings("serial")
public class LDsplitRunner1 extends JFrame
{
        
	public final JButton startJButton = new JButton("Start");
	public final JButton cancelJButton = new JButton("Cancel");


    final JFrame loadfileframe = new JFrame();
    	
    	//two input files - legend phase 
        private final JLabel LegendFileLabel = new JLabel("Path to legend file:");
        private final JTextField LegendFiletxtfiled=new JTextField(ConfigureContainer.getLegendFile());
        private JButton LegendFileButton = new JButton("Load");
        private JLabel PhaseFileLabel = new JLabel("Path to phase file:");
        private final JTextField PhaseFiletxtfiled=new JTextField(ConfigureContainer.getPhaseFile());
        private JButton PhaseFileButton = new JButton("Load");
        
 
        // parameter button
        private JLabel StartsnpLabel = new JLabel("Start SNP:");
        private final JTextField Startsnptxtfield=new JTextField(ConfigureContainer.getStartsnp().toString());
        private JLabel EndsnpLabel = new JLabel("End SNP:");
        private final JTextField Endsnptxtfield=new JTextField(ConfigureContainer.getEndsnp().toString());

        private JLabel NoteLabel = new JLabel("Note: all haplotypes in phase file are used to generate files.");
        //panel
        private JPanel panelRouter = new JPanel();
        private JPanel panelParameter = new JPanel();
        private JPanel panelRunning = new JPanel();


        // input data
        private static String work_dir = null;
        private static String legendFile = null;
        private static String phaseFile = null;
        private static String resultFile = null;
      
        
        private boolean LDsplitFrameClose = false;

        // main operations
        public CutWindow cutwindow = null;
        private LDsplitCaller caller;                                     // class LDsplitCaller  caller



	private  void initConfigure()
	{
		//String osName = System.getProperty("os.name").toLowerCase();
		//if (osName.indexOf("win")>=0) {
		//	work_dir = "D:\\netbeansprogramme\\JUnitTest\\src\\ld_split_graphy_interface";              
		//
		//} else if (osName.indexOf("linux")>=0) {
		//	work_dir = "/home/zhengj/project/LDsplit_java";            
		//}         

                legendFile = ConfigureContainer.getLegendFile();
                phaseFile = ConfigureContainer.getPhaseFile();
      

	}

	

        public void SetFile_dir(String strdir)
        {
            legendFile = strdir;
        };

	// constructor
	public LDsplitRunner1()
	{
                super("Generate inputfiles");
                //initConfigure();
                setLayout( new BorderLayout());

                panelRouter.setBorder(BorderFactory.createTitledBorder(BorderFactory.createEtchedBorder(), "Input Files"));
                //panelRouter.setLayout(new FlowLayout(2,3));
                LegendFiletxtfiled.setColumns(50);
                panelRouter.add(LegendFileLabel);
                panelRouter.add(LegendFiletxtfiled);
                panelRouter.add(LegendFileButton);
                LegendFileButton.addActionListener(
                        new ActionListener()
                        {
                            public void actionPerformed(ActionEvent e)
                            {
                                Frame loadfileframe = new Frame();
                                FileDialog filedialog = new FileDialog(loadfileframe,"open final data file dialog",FileDialog.LOAD);
                                filedialog.setVisible(true);
                                String str = filedialog.getDirectory()+ filedialog.getFile();
                                System.out.println(str);
                                LegendFiletxtfiled.setText(str);
                            }
                        });

                PhaseFiletxtfiled.setColumns(50);
                panelRouter.add(PhaseFileLabel);
                panelRouter.add(PhaseFiletxtfiled);
                panelRouter.add(PhaseFileButton);
                PhaseFileButton.addActionListener(
                        new ActionListener()
                        {
                            public void actionPerformed(ActionEvent e)
                            {
                                Frame loadfileframe = new Frame();
                                FileDialog filedialog = new FileDialog(loadfileframe,"open final data file dialog",FileDialog.LOAD);
                                filedialog.setVisible(true);
                                String str = filedialog.getDirectory()+ filedialog.getFile();
                                System.out.println(str);
                                PhaseFiletxtfiled.setText(str);
                            }
                        });
                
               

                panelParameter.setBorder(BorderFactory.createTitledBorder(BorderFactory.createEtchedBorder(), "Parameter Setting"));

                Startsnptxtfield.setColumns(5);
                panelParameter.add(StartsnpLabel);
                panelParameter.add(Startsnptxtfield);

                Endsnptxtfield.setColumns(5);
                panelParameter.add(EndsnpLabel);
                panelParameter.add(Endsnptxtfield);

                panelParameter.add(NoteLabel);
                
                panelRunning.setBorder(BorderFactory.createTitledBorder(BorderFactory.createEtchedBorder(), "Running Processing"));
                panelRunning.setLayout(new BorderLayout());

		JPanel centerJPanel = new JPanel();
		

		//centerJPanel.add(loadResultJButton);                
		JPanel southJPanel = new JPanel();
		southJPanel.add(startJButton);
        startJButton.setEnabled(true);

				southJPanel.add(cancelJButton);
                cancelJButton.setEnabled(false);

                panelRunning.add(centerJPanel, BorderLayout.CENTER);
                panelRunning.add(southJPanel, BorderLayout.SOUTH);

		// Add action listener to "Start" button to launch LDsplitCaller
		startJButton.addActionListener(
			new ActionListener()
			{
				public void actionPerformed(ActionEvent e)
				{
				    // load configure file
                    ConfigureContainer.setPhaseFile(PhaseFiletxtfiled.getText());
                    ConfigureContainer.setLegendFile(LegendFiletxtfiled.getText());
                    ConfigureContainer.setStartsnp(Integer.parseInt(Startsnptxtfield.getText()));
                    ConfigureContainer.setEndsnp(Integer.parseInt(Endsnptxtfield.getText()));  

                    initConfigure();
 
					caller = new LDsplitCaller();

					startJButton.setEnabled(false);
					cancelJButton.setEnabled(true);
                    LegendFileButton.setEnabled(false);
                    PhaseFileButton.setEnabled(false);
					caller.execute();
				}
			}
		);

		cancelJButton.addActionListener(
			new ActionListener()
			{
				public void actionPerformed(ActionEvent e) {

                      JFrame frame = new JFrame();
			          int res = JOptionPane.showConfirmDialog(frame, "Would ou like to cancel the process?",
			        		  "Cancel Process", JOptionPane.YES_NO_OPTION);
                        if(res == JOptionPane.YES_OPTION) {
                            RunLDhat.kissprocess();
                            caller.cancel();
                            caller = null;
                        }
				}
			}
		);

                addWindowListener(new WindowAdapter(){
                    public   void   windowClosing(WindowEvent   e)
                    {
                        LDsplitFrameClose =  true;
                        ConfigureFrame.LoadRawButton.setEnabled(true);
                        ConfigureFrame.LoadResultButton.setEnabled(true);
                        ConfigureFrame.CutButton.setEnabled(true);
                    }
                });

		add(panelRouter, BorderLayout.CENTER);
		add(panelParameter, BorderLayout.NORTH);          
		add(panelRunning, BorderLayout.SOUTH);

                
		if(System.getProperty("os.name").toLowerCase().indexOf("mac")>=0){
			setSize(900,300);
		}else{
			setSize(800,300);
		}
		
        setResizable(false);
		setVisible(true);
	}

	class LDsplitCaller extends SwingWorker<Integer, Integer>
	{
		private boolean stopped = false;
        
		public LDsplitCaller(){
			// TODO Auto-generated constructor s
		}

		protected Integer doInBackground() throws Exception
		{
			 // checking the parameter
            if(ConfigureContainer.CheckingParameter1() == false){    
                cancel();
                return -1;
            }
            
            // load source data and score data
           
            cutwindow = new CutWindow();
            int result = cutwindow.loadFiles(legendFile, phaseFile);
            System.out.println(result);
			if(result == 1){ //cannot find file
                 cancel();
                 return -1;   
            }else if( result == 3){
                ParameterChecking.ErrorInforming("Input sequence number should be more than 20 and less than 192");
                cancel();
                return -1;
            }else if( result == 2){
                ParameterChecking.ErrorInforming("The format of file is not right");
                cancel();
                return -1;
            }else if( result == 4){
            	ParameterChecking.ErrorInforming("endsnp exceeds the maximum number of SNPs");
                cancel();
                return -1;
            }
			
			
             //------------------------------------------------------------------------------------------------//
                        if (stopped || LDsplitFrameClose) {                        // return the GUI stopped in void done.cancel();
                              return -1;
                        }
           
            //------------------------------------------------------------------------------------------------//
			
			
			return 1;
		}

		protected void done()
		{
			//System.out.println("done");
			startJButton.setEnabled(true);
			cancelJButton.setEnabled(false);

			if (stopped || LDsplitFrameClose) {
                  return;
            }
                        
            JFrame frame = new JFrame();
			int n = JOptionPane.showConfirmDialog(frame, "Would ou like to save files?",
					"export LDsplit result", JOptionPane.YES_NO_OPTION);
			if (n == JOptionPane.YES_OPTION) {
				JFileChooser fc = new JFileChooser();
				fc.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
				
				int retVal = fc.showSaveDialog(frame);                 // let frame to become a showDialog
				if (retVal == JFileChooser.APPROVE_OPTION) {
					File resultFile = fc.getSelectedFile();   // where is the selected file
					String path = resultFile.getPath();

					
					//generate two file to target
					if( !generateFiles( path) ){
						ParameterChecking.ErrorInforming("error in generating inputfiles");
					}
					
					LegendFileButton.setEnabled(true);
                    PhaseFileButton.setEnabled(true);
                    
				} else {
					LegendFileButton.setEnabled(true);
                    PhaseFileButton.setEnabled(true);
					System.out.println("save file cancelled by user");
				}
			} else if (n == JOptionPane.NO_OPTION) {
				LegendFileButton.setEnabled(true);
                PhaseFileButton.setEnabled(true);
				System.out.println("Don't save it!");
			}
                        ///// loading to visualization model
                        cutwindow = null;
                        

                        
		}

		public void cancel ()
		{
			stopped = true;
                        startJButton.setEnabled(true);
                        cancelJButton.setEnabled(false);
                        LegendFileButton.setEnabled(true);
                        PhaseFileButton.setEnabled(true);
                        cutwindow = null;
			// TODO: more actions like ask user to confirm cancelation
		}
		
		
		public boolean generateFiles( String path) {
			
			ArrayList<Double> loc = new ArrayList<Double>();
			loc = cutwindow.getLoc();
			ArrayList<String> site = cutwindow.getSite();

			// .site file generation
			File siteFile;
			if(System.getProperty("os.name").toLowerCase().indexOf("win")>=0){
				siteFile = new File(path + "\\input.site");
			}else{
				siteFile = new File(path + "/input.site");
			}
			
			try {
				FileWriter siteFW = new FileWriter(siteFile);
				BufferedWriter siteBW = new BufferedWriter(siteFW);
				siteBW.write(site.size() + " " + loc.size() + " 1");
				siteBW.newLine();

				// Loop through all and write the Haplotype with format heading
				for (int i = 0; i < site.size(); i++) {
					siteBW.write(">Seq" + i);
					siteBW.newLine();
					siteBW.write(site.get(i));
					siteBW.newLine();
				}
				siteBW.close();
				siteFW.close();
			} catch (FileNotFoundException e) {
				return false;
			} catch (IOException e) {
				return false;
			}


			// .loc file generation
			File locFile;
			if(System.getProperty("os.name").toLowerCase().indexOf("win")>=0){
				locFile = new File(path + "\\input.loc");
			}else{
				locFile = new File(path + "/input.loc");
			}
			
			try {
				double lastLoc = loc.get(loc.size() - 1);
				double physicalLength = lastLoc - loc.get(0) + 1;
				FileWriter locFW = new FileWriter(locFile);
				BufferedWriter locBW = new BufferedWriter(locFW);

				// Writes heading
				locBW.write(loc.size() + " " + physicalLength + " L");
				locBW.newLine();

				// Loop through all and write the locations
				for (int i = 0; i < loc.size(); i++) {
					// Writes current location - start location + 0.01
					locBW.write("" + (loc.get(i) - loc.get(0) + 0.01));
					locBW.newLine();
				}
				locBW.close();
				locFW.close();
			} catch (FileNotFoundException e) {
				return false;
			} catch (IOException e) {
				return false;
			}
			return true;
		}
		
		
		
	}
}
