package ld_split_graphy_interface;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;



public class CutWindow {
	private String legendFile;
	private String phaseFile;
	private String resultFile;
	private int startsnp, endsnp;
	private ArrayList<Double> loc = new ArrayList<Double>();
	private ArrayList<String> site = new ArrayList<String>();
	
	public CutWindow() {
		if(ConfigureContainer.getStartsnp() != 0)
			startsnp = ConfigureContainer.getStartsnp();
        if(ConfigureContainer.getEndsnp() != 0)
        	endsnp = ConfigureContainer.getEndsnp();

	}
	
	public int loadFiles(String legendFile, String phaseFile ) {
		
		//read legend file
		String s = null;
		ArrayList<String> legend_data = new ArrayList<String>();
		File f = new File(legendFile);
		
		if (f.exists()) {
		    System.out.println("file is there shit");
		    try {
		    	BufferedReader br = new BufferedReader(new InputStreamReader( new FileInputStream(f)));
		    	while ((s = br.readLine()) != null) {
		    		legend_data.add(s);
		    	}
		    	
		    } catch (Exception e) {
		    	e.printStackTrace();
		    }
		}else{
		    //System.out.println("cannot find file");
		    return 1;
		}
		
		//read phase file
		s = null;
		ArrayList<String> phase_data = new ArrayList<String>();
		File f1 = new File(phaseFile);
		
		if (f1.exists()) {
		    System.out.println("file is there shit");
		    try {
		    	BufferedReader br = new BufferedReader(new InputStreamReader( new FileInputStream(f1)));
		    	while ((s = br.readLine()) != null) {
		    		phase_data.add(s);
		    	}
		    	
		    } catch (Exception e) {
		    	e.printStackTrace();
		    }
		}else{
		    //System.out.println("cannot find file");
		    return 1;
		}
		
		//check format
		//parse legend file
		ArrayList<Integer> legend = new ArrayList<Integer>(); //store position info.
		for(int i=1;i<legend_data.size();i++){ //omit the first line
			String line_legend = legend_data.get(i) ;
			String[] result = line_legend.split("\\t+|\\s+");
			if( result.length != 4){ // some line lack element
				return 2;
			}else{
				legend.add( Integer.parseInt(result[1]) );
			}
		}
		int total_snp_no = legend.size(); // num of snps
		

		//parse phase file
		ArrayList<String> phase = new ArrayList<String>(); //store haplotype info.
		for(int i=0;i<phase_data.size();i++){ 
			String line_phase = phase_data.get(i) ;
			//line_phase = line_phase.replaceAll("\\s+|\\t+","");
			String[] result = line_phase.split("\\s+|\\t+");
			if( result.length != total_snp_no){ // some line lack element
				//System.out.println("aaa="+result.length+"bbb="+total_snp_no+"i="+i);
				return 2;
			}else{
				//String temp = .replaceAll("\line_phase\s+|\\t+","");
				//for(int ii=0;ii<result.length;ii++){
				//	temp+=result[ii];
				//}
				phase.add(line_phase);
			}
		}
		
		if(endsnp>total_snp_no){
			return 4;
		}else if( phase.size() < 20 || phase.size() > 192){
			return 3;
		}
		
		// generate inputfiles
		System.out.println("ksksksk");
		loc = generateLoc(startsnp, endsnp, legend); 
		site = extractHaplotype(startsnp, endsnp, phase); 
		
		
		return 0;
		
	}


	
	private ArrayList<Double> generateLoc(int startSNP, int endSNP, ArrayList<Integer> legend ) {
		ArrayList<Double> loc = new ArrayList<Double>();
	
			int lineCount=1;
			for(int i=0;i<legend.size();i++){				
				if (lineCount >= startSNP && lineCount <= endSNP) {
					loc.add(legend.get(i) / 1000.0);	
				}
				lineCount++;	
			}

		return loc;
	}
	
	private ArrayList<String> extractHaplotype(int startSNP, int endSNP, ArrayList<String> phase) {
		ArrayList<String> sampleHap = new ArrayList<String>();
		
			int lineCount = 0;
			for (int i = 0; i < phase.size(); i++) {
					// Read, substring the Haplotype and add to ArrayList
					String temp = phase.get(i).substring(startSNP*2-2, endSNP*2-1);
					temp = temp.replaceAll("\\s+|\\t+","");
					sampleHap.add(temp);
					lineCount++;
			}

		return sampleHap;
	}

	
	
	
	
	

	public String getLegendFile() {
		return legendFile;
	}


	public void setLegendFile(String legendFile) {
		this.legendFile = legendFile;
	}


	public String getPhaseFile() {
		return phaseFile;
	}


	public void setPhaseFile(String phaseFile) {
		this.phaseFile = phaseFile;
	}

	public int getStartsnp() {
		return startsnp;
	}

	public void setStartsnp(int startsnp) {
		this.startsnp = startsnp;
	}

	public int getEndsnp() {
		return endsnp;
	}

	public void setEndsnp(int endsnp) {
		this.endsnp = endsnp;
	}

	public ArrayList<Double> getLoc() {
		return loc;
	}

	public void setLoc(ArrayList<Double> loc) {
		this.loc = loc;
	}

	public ArrayList<String> getSite() {
		return site;
	}

	public void setSite(ArrayList<String> site) {
		this.site = site;
	}


}
