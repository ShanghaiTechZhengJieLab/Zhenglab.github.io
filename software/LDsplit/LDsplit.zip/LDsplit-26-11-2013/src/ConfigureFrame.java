// Author: Yang Peng, 2011. Nov.19th, NTU, Singapore

package ld_split_graphy_interface;

import javax.swing.*;
import java.awt.*;

import javax.swing.AbstractButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

import java.awt.BorderLayout;
import java.awt.FileDialog;
import java.awt.Frame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

import ld_split_graphy_interface.HotspotWindow.PairRhoMap;


public class ConfigureFrame extends JFrame {

    private  JButton SettingJButton = new JButton("Load");
    private  JButton cancelJButton = new JButton("Cancel");

    public static JButton LoadRawButton = new JButton("Calculate recombination profiles");
    public static  JButton LoadResultButton = new JButton("Load recombination profiles");
    public static  JButton CutButton = new JButton("Generate input files");
    private  JPanel panelRadio = new JPanel();

    public static JPanel JfreechartPanel = new JPanel();
    public static JPanel HotspotPanel = new JPanel();

    public static JPanel HistogramPanel = new JPanel();
    public static JPanel TablelistPanel = new JPanel();

    public static LDsplitRunner ldsplitRunner = null;
    public static LDsplitRunner1 ldsplitRunner1 = null;

    public static JFrame configureframe = new JFrame("LDsplit: Association Studies of Recombination Hotspots");

    private JFreeChartTest jfreechart;

    private void Init(){

         configureframe.setLayout(new BorderLayout());
         panelRadio.add(CutButton);
         panelRadio.add(LoadRawButton);
         panelRadio.add(LoadResultButton);
         


    ActionListener sliceActionListener = new ActionListener() {
      public void actionPerformed(ActionEvent actionEvent) {
        AbstractButton RadioButton = (AbstractButton) actionEvent.getSource();
        if(actionEvent.getSource() == LoadRawButton){
             ConfigureContainer.SetRadioChoice(false);
             LoadRawButton.setEnabled(false);
             LoadResultButton.setEnabled(false);
             //CutButton.setEnabled(false);
             ldsplitRunner = new LDsplitRunner();
        }

        if(actionEvent.getSource() == CutButton){
        	ConfigureContainer.SetRadioChoice(false);
            LoadRawButton.setEnabled(false);
            LoadResultButton.setEnabled(false);
            //CutButton.setEnabled(false);
            ldsplitRunner1 = new LDsplitRunner1();
        }
        
        if(actionEvent.getSource() == LoadResultButton){
 
                        final JFrame ft = new JFrame();
                        
                        FileDialog filedialog = new FileDialog(ft, "open data file dialog " , FileDialog.LOAD);
                        filedialog.setVisible(true);
                        String FileResultStr = filedialog.getDirectory() + filedialog.getFile();
                        System.out.println(FileResultStr);
                        ConfigureContainer.SetRadioChoice(true);
                        ConfigureContainer.SetFinalResultFile(FileResultStr);
                        FileInputStream inputfile = null;
                        ObjectInputStream objectinput = null;
                        
                        try {
                            inputfile = new FileInputStream(FileResultStr.toString());
                            objectinput = new ObjectInputStream(inputfile);
                            JFreeChartTest.hotspotRandomWindow = (HotspotWindow) objectinput.readObject();
                        } catch (FileNotFoundException ex) {
                            Logger.getLogger(JFreeChartTest.class.getName()).log(Level.SEVERE, null, ex);
                        } catch (IOException ex) {
                            Logger.getLogger(JFreeChartTest.class.getName()).log(Level.SEVERE, null, ex);
                        } catch (ClassNotFoundException ex) {
                            Logger.getLogger(JFreeChartTest.class.getName()).log(Level.SEVERE, null, ex);
                        }
                        HashMap<Integer, PairRhoMap> hashmap = JFreeChartTest.hotspotRandomWindow.GetHashMap();
                        ArrayList<Float> snpPos = JFreeChartTest.hotspotRandomWindow.GetSNPMAF();
                        jfreechart = new JFreeChartTest(hashmap, snpPos, JFreeChartTest.hotspotRandomWindow);

                        ConfigureFrame.JfreechartPanel.removeAll();
                        ConfigureFrame.JfreechartPanel.revalidate();
                        ConfigureFrame.HistogramPanel.removeAll();
                        ConfigureFrame.HistogramPanel.revalidate();
                        ConfigureFrame.TablelistPanel.removeAll();
                        ConfigureFrame.TablelistPanel.revalidate();  

                        ConfigureFrame.JfreechartPanel.setLayout(new BorderLayout());
                        ConfigureFrame.JfreechartPanel.add(jfreechart.sliderJPanel, BorderLayout.NORTH);
                        ConfigureFrame.JfreechartPanel.add(jfreechart.chartPanel, BorderLayout.CENTER);
                        ConfigureFrame.JfreechartPanel.add(jfreechart.southJPanel, BorderLayout.SOUTH);
                        ConfigureFrame.JfreechartPanel.setVisible(true);
                        ConfigureFrame.configureframe.add(ConfigureFrame.JfreechartPanel, BorderLayout.CENTER);
                        
                        HistogramPanel.setPreferredSize(new Dimension(300,200));
                        HistogramPanel.setBorder(BorderFactory.createTitledBorder(BorderFactory.createEtchedBorder(), "Random permutation tests"));
                        TablelistPanel.setPreferredSize(new Dimension(300, 200));
                        TablelistPanel.setBorder(BorderFactory.createTitledBorder(BorderFactory.createEtchedBorder(), "P-values of hotspot-SNP associations"));

                        HotspotPanel.setLayout(new GridLayout(2,1));
                        HotspotPanel.add(HistogramPanel);
                        HotspotPanel.add(TablelistPanel);
                        HotspotPanel.setPreferredSize(new Dimension(300,400));
                        //add(HistogramPanel, BorderLayout.EAST);
                        configureframe.add(HotspotPanel, BorderLayout.EAST);
                                             
                        ConfigureFrame.configureframe.setVisible(true);
                 
        }

      }
    };

    SettingJButton.addActionListener(
         new ActionListener(){
               public void actionPerformed(ActionEvent e){

             }
         }
            
            );

    LoadRawButton.addActionListener(sliceActionListener);
    LoadResultButton.addActionListener(sliceActionListener);
    CutButton.addActionListener(sliceActionListener);

      configureframe.add(panelRadio,BorderLayout.NORTH);
     
      JfreechartPanel.setPreferredSize(new Dimension(500,400));
      JfreechartPanel.setBorder(BorderFactory.createTitledBorder(BorderFactory.createEtchedBorder(), "Recombination Profiles"));
      configureframe.add(JfreechartPanel,BorderLayout.CENTER);

      HistogramPanel.setPreferredSize(new Dimension(300,200));
      HistogramPanel.setBorder(BorderFactory.createTitledBorder(BorderFactory.createEtchedBorder(), "Random permutation tests"));
      TablelistPanel.setPreferredSize(new Dimension(300, 200));
      TablelistPanel.setBorder(BorderFactory.createTitledBorder(BorderFactory.createEtchedBorder(), "P-values of hotspot-SNP associations"));

      HotspotPanel.setLayout(new GridLayout(2,1));
      HotspotPanel.add(HistogramPanel);
      HotspotPanel.add(TablelistPanel);
      HotspotPanel.setPreferredSize(new Dimension(300,400));
      //add(HistogramPanel, BorderLayout.EAST);
      configureframe.add(HotspotPanel, BorderLayout.EAST);

      configureframe.setSize(1250,700);
      configureframe.setVisible(true);

  }

  public ConfigureFrame(){
       Init();
       String path_dir_2 = this.getClass().getResource("").getFile();
       path_dir_2 = path_dir_2.substring(1, path_dir_2.length());
       path_dir_2 = path_dir_2.replaceAll("/", "\\\\");
       System.out.println("the path_2 is: "+path_dir_2);

       String path_dir_3 = this.getClass().getProtectionDomain().getCodeSource().getLocation().getPath();
       path_dir_3 = path_dir_3.substring(1, path_dir_3.length());
       path_dir_3 = path_dir_3.replaceAll("/", "\\\\");

       System.out.println("the path_3 is: "+path_dir_3);

       String path = new File(getClass().getResource("").getPath()).getParentFile().getPath();
       System.out.println("the path is: "+path);
  }

  public static void main(String args[]) {
 
        int Length = args.length;
        if(Length <= 0 ){
        ConfigureFrame jradiobutton = new ConfigureFrame();
        jradiobutton.configureframe.setDefaultCloseOperation(EXIT_ON_CLOSE);
        jradiobutton.setDefaultCloseOperation(EXIT_ON_CLOSE);
        }
        else{
            Map<String, Integer> ParameterIndex = new HashMap<String, Integer>();
            ParameterIndex.put("-visual", 0);
            ParameterIndex.put("-i", 1);
            ParameterIndex.put("-r", 2);
            ParameterIndex.put("-site", 3);
            ParameterIndex.put("-loc", 4);
            ParameterIndex.put("-o", 5);
            ParameterIndex.put("-n", 6);
            ParameterIndex.put("-rb", 7);
            ParameterIndex.put("-rs", 8);
            ParameterIndex.put("-m", 9);
            
            for(int i = 0; i < Length; i++){
                System.out.println(args[i]);
                //String argumentString = args[i];
                
                Integer argumentIndex = ParameterIndex.get(args[i]);
                //tring InputFile = "";
                if(argumentIndex == null) argumentIndex = -1;
                switch(argumentIndex){
                    case 0:
                        ConfigureContainer.SetVisualizationChoice(args[++i]);
                        break;
                    case 1:
                         ConfigureContainer.SetIterationTime(Integer.parseInt(args[++i]));
                        break;
                    case 2:
                        ConfigureContainer.SetRandomSample(Integer.parseInt(args[++i]));
                        break;
                    case 3:
                        //InputFile = "";
                        ConfigureContainer.SetSitesFile(args[++i]);
                        //InputFile += args[++i];
                        break;
                    case 4:
                        //InputFile = "";
                        ConfigureContainer.SetLocsFile(args[++i]);
                        //InputFile += args[++i];
                        break;
                    case 5:
                        //InputFile = "";
                        ConfigureContainer.SetVisualizationResultFilePath(args[++i]);
                        //InputFile += args[++i];
                        break;
                    case 6:
                        ConfigureContainer.SetOutputFile(args[++i]);
                        break;
                    case 7:
                        ConfigureContainer.SetRhomap_Burn(Integer.parseInt(args[++i]));
                        break;
                    case 8:
                        ConfigureContainer.SetRhomap_Samp(Integer.parseInt(args[++i]));
                        break;
                    case 9:
                        ConfigureContainer.SetMAF(Double.parseDouble(args[++i]));
                        break;
                    case -1:
                        //InputFile += " ";
                        //InputFile += args[i];
                        break;
                }
            }
            String VisualizationChoice = ConfigureContainer.GetVisualizationChoice();
            if(VisualizationChoice.compareTo("1") == 0)
            {
                ConfigureFrame jradiobutton = new ConfigureFrame();
                jradiobutton.configureframe.setDefaultCloseOperation(EXIT_ON_CLOSE);
                jradiobutton.setDefaultCloseOperation(EXIT_ON_CLOSE);
            }
            else{
                BufferedWriter logoutputBufferedWriter = null;
                try {
                        
                    HotspotWindow hotspotWindow_Run = new HotspotWindow();
                    String sitesFile = ConfigureContainer.GetSitesFile();
                    String locsFile = ConfigureContainer.GetLocsFile();
                    //logoutputBufferedWriter=new BufferedWriter(new FileWriter((ConfigureContainer.GetVisualizationResultFilePath() + "\\log").toString()));
                    //logoutputBufferedWriter.write("0\n");
                    //logoutputBufferedWriter.flush();
                    //logoutputBufferedWriter.close();

			if (hotspotWindow_Run.loadSnp(sitesFile, locsFile) != false) {
                        ArrayList<Integer> splitSnp = new ArrayList<Integer>();
				splitSnp = hotspotWindow_Run.splitSnps();
                        if (hotspotWindow_Run.test_snp() == false) {
                            ParameterChecking.ErrorInforming("Input sequence number should be more than 20 and less than 192");
                            return;
                        }
                        hotspotWindow_Run.WholeRhoSnp();
                        // for random generate snip plot
                        Integer RANDOMEXAMPLENUMBER = ConfigureContainer.GetRandomSample();
                        for (int countRandom = 0; countRandom < RANDOMEXAMPLENUMBER; ++countRandom) {
                            //hotspotWindow.splitOneSnp(count);
                            hotspotWindow_Run.splitOneSnpRandom(countRandom);
                            //logoutputBufferedWriter.reset();
                            Float percentage = ((float)countRandom) / ((float)(RANDOMEXAMPLENUMBER + splitSnp.size())) * 100;
                           // logoutputBufferedWriter=null;
                            //logoutputBufferedWriter=new BufferedWriter(new FileWriter((ConfigureContainer.GetVisualizationResultFilePath() + "\\log").toString()));
                            //logoutputBufferedWriter.write(""+percentage.toString()+"\n");
                            //logoutputBufferedWriter.flush();
                            //logoutputBufferedWriter.close();
                        }
                        //------------------------------------------------------------------------------------------------//
                        // split one

                        for (int countSplit = 0; countSplit < splitSnp.size(); ++countSplit) {
                           
                            int snpId = splitSnp.get(countSplit).intValue(); //
                            hotspotWindow_Run.splitOneSnp(snpId); // split one snp(snpId)
                            System.out.printf("finish SNP %d\n\n", snpId);
                            Float percentage = (float)(RANDOMEXAMPLENUMBER + countSplit) / (float)(RANDOMEXAMPLENUMBER + splitSnp.size())* 100 ;
                           // logoutputBufferedWriter=null;
                            //logoutputBufferedWriter=new BufferedWriter(new FileWriter((ConfigureContainer.GetVisualizationResultFilePath() + "\\log").toString()));
                            //logoutputBufferedWriter.write(""+percentage.toString()+"\n");
                            //logoutputBufferedWriter.flush();
                            //logoutputBufferedWriter.close();
                            
                        }
			}
                    ObjectOutputStream output;
                    try {
                        output = new ObjectOutputStream(new FileOutputStream((ConfigureContainer.GetVisualizationResultFilePath()+"\\"+ConfigureContainer.GetOutputFile()).toString())); // resultfile to be a outputstream
                        output.writeObject(hotspotWindow_Run); // call hotspotWindow directly save hotspot window object into a file
                        if (output != null) {
                            output.close();
                        } else {
                            System.err.println("No data is written to file " + ConfigureContainer.GetVisualizationResultFilePath().toString());
                        }
                    } catch (IOException ioException) {
                        System.err.println("Error opening or closing file " + ConfigureContainer.GetVisualizationResultFilePath().toString());
                    }

                    hotspotWindow_Run = null;

		} catch ( IOException ex ) {
			Logger.getLogger(ConfigureFrame.class.getName()).log(Level.SEVERE, null, ex);
		}
                /*
                finally {
                    try {
                        logoutputBufferedWriter.close();
                    } catch (IOException ex) {
                        Logger.getLogger(ConfigureFrame.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }*/

            }
        }
    };
}
