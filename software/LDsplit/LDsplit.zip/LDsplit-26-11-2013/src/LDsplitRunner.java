package ld_split_graphy_interface;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FileDialog;
import java.awt.Frame;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.JTextField;
import javax.swing.SwingWorker;

import java.util.HashMap;

import ld_split_graphy_interface.HotspotWindow.PairRhoMap;

public class LDsplitRunner extends JFrame
{
        
	public final JButton startJButton = new JButton("Start");
	public final JButton cancelJButton = new JButton("Cancel");
	private final JProgressBar progressBar = new JProgressBar();

        private final JButton showresult = new JButton("Show");

	final JFrame loadfileframe = new JFrame();

        private final JLabel siteFileLabel = new JLabel("Path to sites file:");
        private final JTextField SiteFiletxtfiled=new JTextField(ConfigureContainer.GetSitesFile());
        private JButton SiteFileButton = new JButton("Load");
        private JLabel LocsFileLabel = new JLabel("Path to locs file:");
        private final JTextField LocsFiletxtfiled=new JTextField(ConfigureContainer.GetLocsFile());
        private JButton LocsFileButton = new JButton("Load");
        // parameter button
        private JLabel IterationLabel = new JLabel("Rhomap -ite:");
        private final JTextField Iterationtxtfiled=new JTextField(ConfigureContainer.GetIterationTime().toString());
        private JLabel RandomSampleLabel = new JLabel("# of Permutation:");
        private final JTextField RandomSampletxtfiled=new JTextField(ConfigureContainer.GetRandomSample().toString());
        private JLabel RhomapSampLabel = new JLabel("Rhomap -samp:");
        private final JTextField RhomapSamptxtfiled = new JTextField(ConfigureContainer.GetRhomap_Samp().toString());
        private JLabel RhomapBurnLabel = new JLabel("Rhomap -burn:");
        private final JTextField RhomapBurntxtfiled = new JTextField(ConfigureContainer.GetRhomap_Burn().toString());
        private JLabel MAFLabel = new JLabel("MAF:");
        private final JTextField MAFtxtfiled = new JTextField(ConfigureContainer.GetMAF().toString());
        //panel
        private JPanel panelRouter = new JPanel();
        private JPanel panelParameter = new JPanel();
        private JPanel panelRunning = new JPanel();


        // input data
	private static String work_dir = null;
	private static String sitesFile = null;
	private static String locsFile = null;
        private static String resultFile;

        // set the value of number of random examples
        private Integer RANDOMEXAMPLENUMBER = 200;

        private boolean LDsplitFrameClose = false;

        // main operations
	//public static HotspotWindow hotspotWindow = null;          // class HotspotWindow  hotspotWindow
        public HotspotWindow hotspotWindow_Run = null;
        private LDsplitCaller caller;                                     // class LDsplitCaller  caller



	private  void initConfigure()
	{
		/*String osName = System.getProperty("os.name");
		if (osName.equals("Windows NT") || osName.equals("Windows 7") || osName.equals("Windows XP")) {
			work_dir =
                                "D:\\netbeansprogramme\\JUnitTest\\src\\ld_split_graphy_interface";
                                //"U:/project/LDsplit_java";                      

		} else if (osName.equals("Linux") || osName.equals("Unix")) {
			work_dir = "/home/zhengj/project/LDsplit_java";            
		}*/
		//sitesFile = work_dir + "/toy_data/fg11_yri.site";        
		//locsFile = work_dir + "/toy_data/fg11_yri.loc";          

                sitesFile = ConfigureContainer.GetSitesFile();
                locsFile = ConfigureContainer.GetLocsFile();
                resultFile = ConfigureContainer.GetFinalResultFile();
                RANDOMEXAMPLENUMBER = ConfigureContainer.GetRandomSample();

	}

	

        public void SetFile_dir(String strdir)
        {
            sitesFile = strdir;
        };

	// constructor
	public LDsplitRunner()
	{
                super("Run LDsplit");
                //initConfigure();
		setLayout( new BorderLayout());

                panelRouter.setBorder(BorderFactory.createTitledBorder(BorderFactory.createEtchedBorder(), "Input Files"));
                //panelRouter.setLayout(new FlowLayout(2,3));
                SiteFiletxtfiled.setColumns(50);
                panelRouter.add(siteFileLabel);
                panelRouter.add(SiteFiletxtfiled);
                panelRouter.add(SiteFileButton);
                SiteFileButton.addActionListener(
                        new ActionListener()
                        {
                            public void actionPerformed(ActionEvent e)
                            {
                                Frame loadfileframe = new Frame();
                                FileDialog filedialog = new FileDialog(loadfileframe,"open final data file dialog",FileDialog.LOAD);
                                filedialog.setVisible(true);
                                String str = filedialog.getDirectory()+ filedialog.getFile();
                                System.out.println(str);
                                SiteFiletxtfiled.setText(str);
                            }
                        });

                LocsFiletxtfiled.setColumns(50);
                panelRouter.add(LocsFileLabel);
                panelRouter.add(LocsFiletxtfiled);
                panelRouter.add(LocsFileButton);
                LocsFileButton.addActionListener(
                        new ActionListener()
                        {
                            public void actionPerformed(ActionEvent e)
                            {
                                Frame loadfileframe = new Frame();
                                FileDialog filedialog = new FileDialog(loadfileframe,"open final data file dialog",FileDialog.LOAD);
                                filedialog.setVisible(true);
                                String str = filedialog.getDirectory()+ filedialog.getFile();
                                System.out.println(str);
                                LocsFiletxtfiled.setText(str);
                            }
                        });

                panelParameter.setBorder(BorderFactory.createTitledBorder(BorderFactory.createEtchedBorder(), "Parameter Setting"));

                Iterationtxtfiled.setColumns(5);
                panelParameter.add(IterationLabel);
                panelParameter.add(Iterationtxtfiled);

                RhomapSamptxtfiled.setColumns(5);
                panelParameter.add(RhomapSampLabel);
                panelParameter.add(RhomapSamptxtfiled);

                RhomapBurntxtfiled.setColumns(5);
                panelParameter.add(RhomapBurnLabel);
                panelParameter.add(RhomapBurntxtfiled);

                RandomSampletxtfiled.setColumns(5);
                panelParameter.add(RandomSampleLabel);
                panelParameter.add(RandomSampletxtfiled);

                MAFtxtfiled.setColumns(5);
                panelParameter.add(MAFLabel);
                panelParameter.add(MAFtxtfiled);
		
                panelRunning.setBorder(BorderFactory.createTitledBorder(BorderFactory.createEtchedBorder(), "Running Processing"));
                panelRunning.setLayout(new BorderLayout());

		JPanel centerJPanel = new JPanel();
		progressBar.setStringPainted(true);
		centerJPanel.add(progressBar);
		//centerJPanel.add(loadResultJButton);                
		JPanel southJPanel = new JPanel();
		southJPanel.add(startJButton);
                startJButton.setEnabled(true);

		southJPanel.add(cancelJButton);
                cancelJButton.setEnabled(false);

                panelRunning.add(centerJPanel, BorderLayout.CENTER);
                panelRunning.add(southJPanel, BorderLayout.SOUTH);

		// Add action listener to "Start" button to launch LDsplitCaller
		startJButton.addActionListener(
			new ActionListener()
			{
				public void actionPerformed(ActionEvent e)
				{
				    // load configure file
                                        ConfigureContainer.SetLocsFile(LocsFiletxtfiled.getText());
                                        ConfigureContainer.SetSitesFile(SiteFiletxtfiled.getText());
                                        ConfigureContainer.SetIterationTime(Integer.parseInt(Iterationtxtfiled.getText()));
                                        ConfigureContainer.SetRhomap_Samp(Integer.parseInt(RhomapSamptxtfiled.getText()));
                                        ConfigureContainer.SetRhomap_Burn(Integer.parseInt(RhomapBurntxtfiled.getText()));
                                        ConfigureContainer.SetRandomSample(Integer.parseInt(RandomSampletxtfiled.getText()));
                                        ConfigureContainer.SetMAF(Double.parseDouble(MAFtxtfiled.getText()));

                                        initConfigure();
                                    // run progress.......
                                        progressBar.setValue(0);
					caller = new LDsplitCaller();
					caller.addPropertyChangeListener(  
						new PropertyChangeListener(){
							public void propertyChange(PropertyChangeEvent evt) {
								if (evt.getPropertyName().equals("progress")) {
									// update progress bar
									int newValue = (Integer) evt.getNewValue();
									progressBar.setValue(newValue);
								}
							}
						}
					);

					startJButton.setEnabled(false);
					cancelJButton.setEnabled(true);
                                        SiteFileButton.setEnabled(false);
                                        LocsFileButton.setEnabled(false);
					caller.execute();
				}
			}
		);

		cancelJButton.addActionListener(
			new ActionListener()
			{
				public void actionPerformed(ActionEvent e) {

                                        JFrame frame = new JFrame();
			                int res = JOptionPane.showConfirmDialog(frame, "Would ou like to cancel the process?",
					"Cancel Process", JOptionPane.YES_NO_OPTION);
                                        if(res == JOptionPane.YES_OPTION) {
                                            RunLDhat.kissprocess();
                                            caller.cancel();
                                            caller = null;

                                        }
				}
			}
		);

                addWindowListener(new WindowAdapter(){
                    public   void   windowClosing(WindowEvent   e)
                    {
                        LDsplitFrameClose =  true;
                        ConfigureFrame.CutButton.setEnabled(true);
                        ConfigureFrame.LoadRawButton.setEnabled(true);
                        ConfigureFrame.LoadResultButton.setEnabled(true);
                    }
                });

		add(panelRouter, BorderLayout.CENTER);
		add(panelParameter, BorderLayout.NORTH);          
		add(panelRunning, BorderLayout.SOUTH);

                
		if(System.getProperty("os.name").toLowerCase().indexOf("win")>=0){
			setSize(800,300);
		}else if(System.getProperty("os.name").toLowerCase().indexOf("mac")>=0){
			setSize(900,300);
		}else{
			setSize(850,300);
		}
                setResizable(false);
		setVisible(true);
	}

	class LDsplitCaller extends SwingWorker<Integer, Integer>
	{
		private boolean stopped = false;
                private boolean LDsplitFram = false;

		public LDsplitCaller(){
			// TODO Auto-generated constructor s
		}

		protected Integer doInBackground() throws Exception
		{
			// Run LDsplit SNP by SNP
                        if(ConfigureContainer.CheckingParameter() == false){     // checking the parameter
                            cancel();
                            return -1;
                        }
                        
                        hotspotWindow_Run = new HotspotWindow();
			if(hotspotWindow_Run.loadSnp(sitesFile, locsFile) == false){
                                cancel();
                                return -1;   // load source data and score data
                        }
			ArrayList<Integer> splitSnp = new ArrayList<Integer> ();                
			splitSnp = hotspotWindow_Run.splitSnps();


                        if(hotspotWindow_Run.test_snp() == false){
                            ParameterChecking.ErrorInforming("Input sequence number should be more than 20 and less than 192");
                            cancel();
                            return -1;
                        }
	   //------------------------------------------------------------------------------------------------//
                        if (stopped || LDsplitFrameClose) {                        // return the GUI stopped in void done.cancel();
                              return -1;
			}
                        //for LD_hat raw plot
                        hotspotWindow_Run.WholeRhoSnp();  //
           //------------------------------------------------------------------------------------------------//
                        // for random generate snip plot
                        for(int countRandom = 0; countRandom < RANDOMEXAMPLENUMBER; countRandom++) {
                            if (stopped || LDsplitFrameClose) {                        // return the GUI stopped in void done.cance
                                   return -1;
			    }
                            //hotspotWindow.splitOneSnp(count);
                             hotspotWindow_Run.splitOneSnpRandom(countRandom);
                             setProgress( 100 * countRandom / ( RANDOMEXAMPLENUMBER+ splitSnp.size() ) );
                        }
            //------------------------------------------------------------------------------------------------//
			// split one
			for (int countSplit =0; countSplit < splitSnp.size(); ++countSplit) {
				if (stopped || LDsplitFrameClose) {                        // return the GUI stopped in void done.can
                                       return -1;
				}
				int snpId = splitSnp.get(countSplit).intValue();    //
				hotspotWindow_Run.splitOneSnp(snpId);          // split one snp(snpId)
				//debug----------
				System.out.printf("finish SNP %d\n\n", snpId);
				//---------------
				setProgress( 100 * ( countSplit+RANDOMEXAMPLENUMBER ) / ( RANDOMEXAMPLENUMBER+ splitSnp.size() ) );
			}
		        return 1;
		}

		protected void done()
		{
			progressBar.setValue(0);
			startJButton.setEnabled(true);
			cancelJButton.setEnabled(false);

			if (stopped || LDsplitFrameClose) {
                           return;
                        }
                        
                        JFrame frame = new JFrame();
			int n = JOptionPane.showConfirmDialog(frame, "Would ou like to save result to a file?",
					"export LDsplit result", JOptionPane.YES_NO_OPTION);
			if (n == JOptionPane.YES_OPTION) {
				JFileChooser fc = new JFileChooser();
				int retVal = fc.showSaveDialog(frame);                 // let frame to become a showDialog
				if (retVal == JFileChooser.APPROVE_OPTION) {
					File resultFile = fc.getSelectedFile();   // where is the selected file
					
					ObjectOutputStream output;
					try {
						output = new ObjectOutputStream(
							new FileOutputStream(resultFile.toString()));	 // resultfile to be a outputstream
						output.writeObject(hotspotWindow_Run);             // call hotspotWindow directly save hotspot window object into a file
						if (output != null) {
							output.close();
						} else {
							System.err.println("No data is written to file " + resultFile.toString());
						}

					} catch ( IOException ioException ) {
						System.err.println("Error opening or closing file " + resultFile.toString());
					}

				} else {
					System.out.println("save file cancelled by user");
				}
			} else if (n == JOptionPane.NO_OPTION) {
				System.out.println("Don't save it!");
			}
                        ///// loading to visualization model
                        JFreeChartTest.hotspotRandomWindow = hotspotWindow_Run;
                        hotspotWindow_Run = null;
                        HashMap<Integer, PairRhoMap> hashmap = JFreeChartTest.hotspotRandomWindow.GetHashMap();
                        ArrayList<Float> snpPos = JFreeChartTest.hotspotRandomWindow.GetSNPMAF();
                        JFreeChartTest jfreechart = new JFreeChartTest(hashmap, snpPos, JFreeChartTest.hotspotRandomWindow);

                        ConfigureFrame.JfreechartPanel.removeAll();
                        ConfigureFrame.JfreechartPanel.revalidate();
                        ConfigureFrame.HistogramPanel.removeAll();
                        ConfigureFrame.HistogramPanel.revalidate();
                        ConfigureFrame.TablelistPanel.removeAll();
                        ConfigureFrame.TablelistPanel.revalidate();

                        ConfigureFrame.JfreechartPanel.setLayout(new BorderLayout());
                        ConfigureFrame.JfreechartPanel.add(jfreechart.sliderJPanel, BorderLayout.NORTH);
                        ConfigureFrame.JfreechartPanel.add(jfreechart.chartPanel, BorderLayout.CENTER);
                        ConfigureFrame.JfreechartPanel.add(jfreechart.southJPanel, BorderLayout.SOUTH);
                        ConfigureFrame.JfreechartPanel.setVisible(true);
                        ConfigureFrame.configureframe.add(ConfigureFrame.JfreechartPanel, BorderLayout.CENTER);

                        ConfigureFrame.HistogramPanel.setPreferredSize(new Dimension(300,200));
                        ConfigureFrame.HistogramPanel.setBorder(BorderFactory.createTitledBorder(BorderFactory.createEtchedBorder(), "Random permutation tests"));
                        ConfigureFrame.TablelistPanel.setPreferredSize(new Dimension(300, 200));
                        ConfigureFrame.TablelistPanel.setBorder(BorderFactory.createTitledBorder(BorderFactory.createEtchedBorder(), "P-values of hotspot-SNP associations"));

                        ConfigureFrame.HotspotPanel.setLayout(new GridLayout(2,1));
                        ConfigureFrame.HotspotPanel.add(ConfigureFrame.HistogramPanel);
                        ConfigureFrame.HotspotPanel.add(ConfigureFrame.TablelistPanel);
                        ConfigureFrame.HotspotPanel.setPreferredSize(new Dimension(300,400));
                        ConfigureFrame.configureframe.add(ConfigureFrame.HotspotPanel, BorderLayout.EAST);

                        ConfigureFrame.configureframe.setVisible(true);
		}

		public void cancel ()
		{
			stopped = true;
                        setProgress(0);
                        startJButton.setEnabled(true);
                        cancelJButton.setEnabled(false);
                        SiteFileButton.setEnabled(true);
                        LocsFileButton.setEnabled(true);
                        hotspotWindow_Run = null;
			// TODO: more actions like ask user to confirm cancelation
		}
	}
}
