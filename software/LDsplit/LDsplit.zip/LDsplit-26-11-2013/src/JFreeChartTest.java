/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ld_split_graphy_interface;
/**
 *
 * @ YANG PENG create LD_Split Chart
 * March/27/2011/
 */
//load package java 2d
import java.awt.event.MouseEvent;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JButton;
import java.awt.Component;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FileDialog;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.awt.Font;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.LayoutManager;
import java.awt.Point;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.lang.Object;

//load package jfree chart
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartFrame;
import org.jfree.chart.ChartMouseEvent;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.renderer.xy.StandardXYItemRenderer;
import org.jfree.chart.renderer.xy.XYItemRenderer;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYLineAndShapeRenderer;

//load package jfree data
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;
import org.jfree.data.xy.DefaultXYDataset;
import org.jfree.data.xy.XYDataset;

//load package jfree util
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Random;
import java.util.Scanner;
import java.util.HashMap;
import java.util.ListIterator;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.AbstractButton;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JSlider;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.table.TableColumnModel;

import org.jfree.data.statistics.HistogramDataset;
import org.jfree.data.statistics.HistogramType;



class PairRhoMap implements Serializable
{
	ArrayList<Float> r0 = new ArrayList<Float> ();
	ArrayList<Float> r1 = new ArrayList<Float> ();

	public void set(ArrayList<Float> mRhoA, ArrayList<Float> mRhoB) {
		r0 = mRhoA;
		r1 = mRhoB;
	}

	public ArrayList<Float> get(int allele) {
		if (allele == 0) {
			return r0;
		} else if (allele == 1) {
			return r1;
		} else {
			System.err.println("allele is not 0 or 1: " + Integer.toString(allele));
			return null;
		}
	}
}



public class JFreeChartTest 
{
    private int LocationID = 0;
    private final JButton leftJButton = new JButton("Left SNP");
    private final JButton rightJButton = new JButton("Right SNP");
    private final JButton hotspotDifferJButton = new JButton("Calculate p-values");
    private final JCheckBox wholerhomapcheckBox = new JCheckBox("Profile of whole population");
    private final JComboBox jc = new JComboBox();
    private JLabel lab = new JLabel("Current SNP:");
    
    private boolean checkboxselected = false;
    private final JButton listPValueJButton = new JButton("AllSNP_Pvalue");
    public final JPanel southJPanel = new JPanel();

    private  JFreeChart chart;
    public  ChartPanel chartPanel;

    // slider box showing
    Box sliderBox = new Box(BoxLayout.Y_AXIS);

    private JLabel silderSNPSelectionlabel = new JLabel("SNP Profile slider:");
    private JSlider silderSNP = new JSlider(SwingConstants.HORIZONTAL);
    private JPanel sliderSNPPanel = new JPanel();

    private JLabel slider1label = new JLabel("left slider:");
    private JSlider slider1 = new JSlider(SwingConstants.HORIZONTAL);
    private JPanel slider1Panel = new JPanel();

    private JLabel slider2label = new JLabel("right slider:");
    private JSlider slider2 = new JSlider(SwingConstants.HORIZONTAL);
    private JPanel slider2Panel = new JPanel();

    public JPanel sliderJPanel = new JPanel();

    private JLabel showlable = new JLabel("Hotspot boundaries(left, right): ");
    private JTextField showValSNP = new JTextField();
    private JTextField showValleft = new JTextField();
    private JTextField showValright = new JTextField();
    private JPanel showJPanel = new JPanel();

    ChangeListener listenerSNP;
    ChangeListener PlotListenerSNP;
    ChangeListener listener1;
    ChangeListener PlotListener1;
    ChangeListener listener2;
    ChangeListener PlotListener2;

    //LD_HAT plot
    private  JRadioButton LoadLDHatRawRadioButton = new JRadioButton("load LD Hat raw data");
    private XYSeries LDHatseries = new XYSeries("Profile of both alleles");

    // load the random file
    private final JButton loadRandomResultJButton = new JButton("LoadRandomFile");
    private final JFrame loadfileframe = new JFrame();
    public static HotspotWindow hotspotRandomWindow ;
    private int RandomSampleSize;// = hotspotRandomWindow.GetRandomHashMap().size();  // default value
    double [] Ro_Diff_Set;// = new double [RandomSampleSize];
    double [] Ro_Diff_Target_Set;

    // P-value calculation
    private double P_value = 0;
    private double [] RhoMapPValue;
    pnorm Pnorm = new pnorm();

    //LDHatRhoMap
    private ArrayList<Integer> LDHatRhoMaps
            = new ArrayList<Integer>();

    //splitRhoMaps
    private HashMap<Integer, HotspotWindow.PairRhoMap> splitRhoMaps
            = new HashMap<Integer, HotspotWindow.PairRhoMap>();
    //snpMaf
    private ArrayList<Float> snppos = new ArrayList<Float>();
    private ArrayList<Integer> IndexRhoMapsKeyMap = new ArrayList<Integer>();
    private ArrayList<Map.Entry<Integer, HotspotWindow.PairRhoMap> > sortRhoMapList =
            new ArrayList<Map.Entry<Integer, HotspotWindow.PairRhoMap> >();

    private double leftboundary = 0.0f, rightboundary = 0.0f, SNPboundary = 0.0f;
    private float MaximalPosition = 0.0f;
    private boolean PVALUEGENERATION = false;

    private void InitialSlider()
    {
        int minimum = 0, maximum = (int)(MaximalPosition+1)*10;

        silderSNP = new JSlider(minimum, maximum);
        silderSNP.setMinorTickSpacing(10);
        silderSNP.setMajorTickSpacing(100);
        silderSNP.setValue(50);
        silderSNP.setPaintTrack(true);
        silderSNP.setSnapToTicks(false);
        silderSNP.setPaintTicks(true);
        silderSNP.setPaintLabels(false);

        slider1 = new JSlider(minimum, maximum);
        slider1.setMinorTickSpacing(10);
        slider1.setMajorTickSpacing(100);
        slider1.setValue(50);
        slider1.setPaintTrack(true);
        slider1.setSnapToTicks(false);
        slider1.setPaintTicks(true);
        slider1.setPaintLabels(false);

        slider2 = new JSlider(minimum, maximum);
        slider2.setMinorTickSpacing(10);
        slider2.setMajorTickSpacing(100);
        slider2.setValue(150);
        slider2.setPaintTrack(true);
        slider2.setSnapToTicks(false);
        slider2.setPaintTicks(true);
        slider2.setPaintLabels(false);

        
        listenerSNP = new ChangeListener()
        {
            public void stateChanged(ChangeEvent event)
            {
                JSlider sourceSNP = (JSlider) event.getSource();
                SNPboundary = (double)sourceSNP.getValue()/(double)10;
                showValSNP.setText("SNP: " + (double)sourceSNP.getValue()/(double)10);
            }
        };

        listener1 = new ChangeListener()
        {
            public void stateChanged(ChangeEvent event)
            {
                JSlider source1 = (JSlider) event.getSource();
                leftboundary = (double)source1.getValue()/(double)10;
                showValleft.setText("L: " + (double)source1.getValue()/(double)10);
            }
        };

        listener2 = new ChangeListener()
        {
            public void stateChanged(ChangeEvent event)
            {
                JSlider source2 = (JSlider) event.getSource();
                rightboundary = (double)source2.getValue()/(double)10;
                showValright.setText( "R: " + (double)source2.getValue()/(double)10 );
            }
        };

        PlotListenerSNP = new ChangeListener()
        {
            public void stateChanged(ChangeEvent event)
            {
                JSlider source = (JSlider) event.getSource();
                double physical_location = (double)source.getValue()/(double)10;

                
            }
        };


        PlotListener1 = new ChangeListener()
        {
            public void stateChanged(ChangeEvent event)
            {
                JSlider source = (JSlider) event.getSource();
                double plot_x = (double)source.getValue()/(double)10;

                XYSeries series0 = new XYSeries("");
                XYSeries series = new XYSeries("Left hotspot boundary");
                series.add(plot_x,0);  series.add(plot_x,80);

                XYSeriesCollection dataset3 = new XYSeriesCollection();
                dataset3.addSeries(series);

                XYLineAndShapeRenderer renderer = new XYLineAndShapeRenderer(false, true);
                renderer.setSeriesPaint(0, Color.YELLOW);
                renderer.setBaseLinesVisible(true);
                renderer.setBaseShapesFilled(false);
                renderer.setBaseShapesVisible(false);

                XYPlot plot = chart.getXYPlot();
                plot.setRenderer(3, renderer);
                plot.setDataset(3, dataset3);

            }
        };

        PlotListener2 = new ChangeListener()
        {
            public void stateChanged(ChangeEvent event)
            {
                JSlider source = (JSlider) event.getSource();
                double plot_x = (double)source.getValue()/(double)10;

                XYSeries series = new XYSeries("Right hotspot boundary");
                series.add(plot_x,0);  series.add(plot_x,80);

                XYSeriesCollection dataset4 = new XYSeriesCollection();
                dataset4.addSeries(series);

                XYLineAndShapeRenderer renderer = new XYLineAndShapeRenderer(false, true);
                renderer.setSeriesPaint(0, Color.YELLOW);
                renderer.setBaseLinesVisible(true);
                renderer.setBaseShapesFilled(false);
                renderer.setBaseShapesVisible(false);

                XYPlot plot = chart.getXYPlot();
                plot.setDataset(4, dataset4);
                plot.setRenderer(4, renderer);

            }
        };

        silderSNP.addChangeListener(listenerSNP);
        silderSNP.addChangeListener(PlotListenerSNP);
        slider1.addChangeListener(listener1);
        slider1.addChangeListener(PlotListener1);
        slider2.addChangeListener(listener2);
        slider2.addChangeListener(PlotListener2);

        sliderJPanel.setLayout(new GridLayout(3,1));
        showValleft.setColumns(5);  showValright.setColumns(5); showValSNP.setColumns(5);
        showJPanel.add(showlable);
        showJPanel.add(showValleft);
        showJPanel.add(showValright);
        //showJPanel.add(showValSNP);

        sliderSNPPanel.add(silderSNPSelectionlabel);
        sliderSNPPanel.add(silderSNP);
        slider1Panel.add(slider1label);
        slider1Panel.add(slider1);
        slider2Panel.add(slider2label);
        slider2Panel.add(slider2);

        sliderJPanel.add(showJPanel,BorderLayout.NORTH);

        //sliderJPanel.add(silderSNP,BorderLayout.CENTER);

        sliderJPanel.add(slider1,BorderLayout.CENTER);
        sliderJPanel.add(slider2,BorderLayout.SOUTH);

    }

    
    private void PlotBoundary()
    {

             XYSeries seriesleft = new XYSeries("Left hotspot boundary");
             seriesleft.add(leftboundary,0);  seriesleft.add(leftboundary,80);
             XYSeriesCollection datasetleft = new XYSeriesCollection();


             datasetleft.addSeries(seriesleft);

             XYSeries seriesright = new XYSeries("Right hotspot boundary");
             seriesright.add(rightboundary,0);  seriesright.add(rightboundary,80);
             XYSeriesCollection datasetright = new XYSeriesCollection();

             datasetright.addSeries(seriesright);

             XYPlot plot = chart.getXYPlot();
             //xyitemrender
             XYLineAndShapeRenderer renderer = new XYLineAndShapeRenderer(false, true);
             renderer.setSeriesPaint(0, Color.YELLOW);
             renderer.setBaseLinesVisible(true);
             renderer.setBaseShapesFilled(false);
             renderer.setBaseShapesVisible(false);

             plot.setDataset(3, datasetleft);
             plot.setRenderer(3, renderer, true);

             plot.setDataset(4, datasetright);
             plot.setRenderer(4, renderer, true);
        
    }


    // calculate Mean and Standard Diviation of Series
    private void P_value_Calculation(double [] arrayNumberlist, double targetNumber)
    {
        double Sum = 0, Mean = 0;
        for(int i =0; i< RandomSampleSize; i++){
           Sum +=  arrayNumberlist[i];
        }
        Mean = Sum/(double)RandomSampleSize;

        double SD = 0; Sum = 0;
        for(int i =0; i< RandomSampleSize; i++){
             Sum += Math.pow((arrayNumberlist[i]-Mean),2);
        }
        SD = Math.sqrt( (Sum/RandomSampleSize) );

        P_value = Pnorm.pnorm_calculate(targetNumber, Mean, SD);

        if(P_value > 0.5)
            P_value = 1 - P_value;
        P_value *= 2;

        System.out.println("p_value: " + Pnorm.pnorm_calculate(targetNumber, Mean, SD) );
    }


    //sort hashmap SplotRhoMaps
    private void SortingSplotRhoMaps()
    {
        sortRhoMapList = new ArrayList<Map.Entry<Integer, HotspotWindow.PairRhoMap> >(splitRhoMaps.entrySet());

        System.out.println(splitRhoMaps.size());
        System.out.println(sortRhoMapList.size());

        Collections.sort(sortRhoMapList, new Comparator<Map.Entry<Integer, HotspotWindow.PairRhoMap>>() {
        public int compare(Map.Entry<Integer, HotspotWindow.PairRhoMap> o1, Map.Entry<Integer, HotspotWindow.PairRhoMap> o2) {
                return (o1.getKey() - o2.getKey());
            }
        });

    }


    public void AssignSplitRhoMaps( HashMap<Integer, HotspotWindow.PairRhoMap> SplitRhoMaps,
            ArrayList<Float> snpPos)
    {
        splitRhoMaps = SplitRhoMaps;
        SortingSplotRhoMaps();
        snppos = snpPos;
        GetMaximalPosition();
        Integer index = new Integer(0);
        for(;index < sortRhoMapList.size();index++)
        {
            IndexRhoMapsKeyMap.add((Integer)sortRhoMapList.get(index).getKey());
        }
        System.out.println(IndexRhoMapsKeyMap.size());
        SpreadIndexRhoMapsKeyMap();
    }

    private void GetMaximalPosition()
    {
        Float id = (Float)snppos.get(0);
        for(int i = 0; i < snppos.size(); i++)
        {
            id = (Float)snppos.get(i);
            if(MaximalPosition < id)
                MaximalPosition = id;
        }
    }


    private void SpreadIndexRhoMapsKeyMap()
    {
        Iterator iterator = IndexRhoMapsKeyMap.iterator();
        while(iterator.hasNext())
        {
            System.out.print( " "+iterator.next());
        }
        System.out.println();
    }

    private void AssignLDHatSeries()
    {
        ArrayList<Float> LDHatArraylist = hotspotRandomWindow.GetWholeRhoMap();
        Float id = (Float)snppos.get(0);

        for(int i = 0; i< LDHatArraylist.size() && i < snppos.size(); i++)
        {
            LDHatseries.add(id, LDHatArraylist.get(i));
            id = (Float)snppos.get(i);
            LDHatseries.add(id,LDHatArraylist.get(i));
        }        
    }


    private XYSeries AssginSeries(Integer StringID, Integer list)
    {
        System.out.println("assignSeries");
        HotspotWindow.PairRhoMap pairrhomap = sortRhoMapList.get(StringID).getValue();

        ArrayList<Float> arraylist = pairrhomap.get(list);
        XYSeries series = new XYSeries("Profile of allele "+list.toString());
  
        Float id = (Float)snppos.get(0);

        System.out.println("pairrhomap.arrarylist size: "+arraylist.size());
        for(int i = 0;i<arraylist.size() && i<snppos.size();i++ )
        {
            series.add(id,arraylist.get(i));
            id = (Float)snppos.get(i);
            series.add(id,arraylist.get(i));
        }
        return series;
    }


    public XYDataset createxydataset()  // create the icon of SNP locus
    {
       DefaultXYDataset xydataset = new DefaultXYDataset();

        ListIterator iterator = snppos.listIterator();
        double [][] datas = new double[2][snppos.size()];
        for(int i=0; i<snppos.size() && iterator.hasNext(); i++)
        {
            datas[0][i] = (Float)iterator.next();
            datas[1][i] = -1.0f;
        }

        xydataset.addSeries("SNPs", datas);
        return xydataset;
    }


    public XYDataset createxydataset2(int index)  // create target SNP locus icon
    {
        DefaultXYDataset xydataset = new DefaultXYDataset();
        Integer StringIndex = IndexRhoMapsKeyMap.get(index);

        double [][] datas = new double[2][1];

        datas[0][0] = (Float)snppos.get(StringIndex);
        datas[1][0] = -2.5f;

        xydataset.addSeries("Target SNP", datas);
        return xydataset;
    }


    // draw the histogram based on Ro
    private void DrawHistogramMap(int LocationID, double [] arrayNumberlist, double targetNumber)
    {
         HistogramDataset dataset = new HistogramDataset();
         dataset.setType(HistogramType.FREQUENCY);
         dataset.addSeries("histogram", arrayNumberlist, 50);

         JFreeChart histogramchart = ChartFactory.createHistogram
               (null, null, null, dataset, PlotOrientation.VERTICAL, false, false, false);

         histogramchart.getRenderingHints();

         XYSeries series = new XYSeries("target_number");
         series.add(Ro_Diff_Target_Set[LocationID],0);  series.add(targetNumber,50);
         XYSeriesCollection targetdataset = new XYSeriesCollection();
         targetdataset.addSeries(series);

         XYPlot plot = histogramchart.getXYPlot();
         plot.setDataset(2, targetdataset);
         XYLineAndShapeRenderer renderer2 = new XYLineAndShapeRenderer();
         plot.setRenderer(2, renderer2);
         P_value_Calculation(Ro_Diff_Set,targetNumber);
         System.out.println(P_value);
         JTextField PvalueText = new JTextField("p_value="+ P_value);

         ChartPanel histogramchartPanel = new ChartPanel(histogramchart);

         ConfigureFrame.HistogramPanel.removeAll();
         ConfigureFrame.HistogramPanel.revalidate();
         ConfigureFrame.HistogramPanel.setLayout(new BorderLayout());
         ConfigureFrame.HistogramPanel.add(histogramchartPanel, BorderLayout.CENTER);
         ConfigureFrame.HistogramPanel.add(PvalueText,BorderLayout.SOUTH);
         ConfigureFrame.HistogramPanel.setVisible(true);

         ConfigureFrame.HotspotPanel.removeAll();
         ConfigureFrame.HotspotPanel.revalidate();
         ConfigureFrame.HotspotPanel.setLayout(new GridLayout(2,1));
         ConfigureFrame.HotspotPanel.add(ConfigureFrame.HistogramPanel);
         ConfigureFrame.HotspotPanel.add(ConfigureFrame.TablelistPanel);
         
         ConfigureFrame.configureframe.add(ConfigureFrame.HotspotPanel, BorderLayout.EAST);
    }


    private void TableListPlot()
    {
       int leftpointID = 0, rightpointID=0;
       if(leftboundary > rightboundary) {
            double templeboundary = rightboundary;
            rightboundary = leftboundary;
            leftboundary = templeboundary;
       }

       for(int i = 0; i<snppos.size();i++ ){
             if( (double)snppos.get(i) > leftboundary){
                  leftpointID = i-1;
                  break;
              }
       }

       for(int i = snppos.size()-1;i >= 0 ;i--){
             if( (double)snppos.get(i) < rightboundary ){
                   rightpointID = i+1;
                   break;
             }
       }

       System.out.println("leftpointID: "+leftpointID+" rightpointID: "+rightpointID);

       double [] Ro_Diff_Set = new double [RandomSampleSize]; int Ro_Diff_Set_index = 0;
       HashMap<Integer, HotspotWindow.PairRhoMap> randomhashmap = hotspotRandomWindow.GetRandomHashMap();

       System.out.println("the size of randomhashmap: "+randomhashmap.size());

       Iterator iter = randomhashmap.entrySet().iterator();

       
       while (iter.hasNext()) {
            Map.Entry entry = (Map.Entry) iter.next();
            Integer key = (Integer)entry.getKey();
            HotspotWindow.PairRhoMap pairRhomap = (HotspotWindow.PairRhoMap)entry.getValue();
            // calcuate Ro0 ro map
            ArrayList<Float> arraylist_0 = pairRhomap.get(0);
            double Ro0 = 0;
            int templefpointID = leftpointID;
            while(templefpointID < rightpointID)
            {
                    Ro0 += arraylist_0.get(templefpointID)*(snppos.get(templefpointID+1)-snppos.get(templefpointID));
                    templefpointID++;
            }
            // calcuate Ro0 ro map
            ArrayList<Float> arraylist_1 = pairRhomap.get(1);
            double Ro1 = 0;
            templefpointID = leftpointID;
            while(templefpointID < rightpointID)
            {
                    Ro1 += arraylist_1.get(templefpointID)*(snppos.get(templefpointID+1)-snppos.get(templefpointID));
                    templefpointID++;
            }

            System.out.println("Ro0: "+Ro0+" Ro1:"+Ro1);
            double Ro_Diff = (Ro0-Ro1)/(Ro0+Ro1);
            Ro_Diff_Set[Ro_Diff_Set_index] = Ro_Diff;
            System.out.println("Ro_Diff_Set"+Ro_Diff_Set_index+": "+Ro_Diff);
            Ro_Diff_Set_index++;
        }
       //calculate mean and SD
        double Sum = 0, Mean = 0;
        for(int i =0; i< RandomSampleSize; i++){
           Sum +=  Ro_Diff_Set[i];
        }
        Mean = Sum/(double)RandomSampleSize;

        double SD = 0; Sum = 0;
        for(int i =0; i< RandomSampleSize; i++){
             Sum += Math.pow((Ro_Diff_Set[i]-Mean),2);
        }
        
        SD = Math.sqrt( (Sum/RandomSampleSize) );

       // calculate RhoMap P Value
       double [] RhoMapPValue = new double [sortRhoMapList.size()];

       for(int index = 0;index < sortRhoMapList.size(); index++)
       {
           HotspotWindow.PairRhoMap pairrhomap = sortRhoMapList.get(index).getValue();
           // calcuate Ro0 ro map
           ArrayList<Float> arraylist_0 = pairrhomap.get(0);
           double Ro0 = 0;
           int templefpointID = leftpointID;
           while(templefpointID < rightpointID)
           {
                Ro0 += arraylist_0.get(templefpointID)*( snppos.get(templefpointID+1)-snppos.get(templefpointID) );
                templefpointID++;
           }
           // calcuate Ro0 ro map
           ArrayList<Float> arraylist_1 = pairrhomap.get(1);
           double Ro1 = 0;
           templefpointID = leftpointID;
           while(templefpointID < rightpointID)
           {
                Ro1 += arraylist_1.get(templefpointID)*( snppos.get(templefpointID+1)-snppos.get(templefpointID) );
                templefpointID++;
           }

           System.out.println("Ro0: "+Ro0+" Ro1:"+Ro1);

           double Ro_Diff_Target = (Ro0-Ro1)/(Ro0+Ro1);
           System.out.println("Ro_Diff_Target: "+Ro_Diff_Target);
           // calculate P-value of the series
           double pvalue = Pnorm.pnorm_calculate(Ro_Diff_Target, Mean, SD);

           if(pvalue > 0.5)
                pvalue = 1 - pvalue;
           pvalue *= 2;

           RhoMapPValue[index] = pvalue;

        }

        final String[] columnNames = {"Index", "SNP Location", "P value"};
        final Object[][] dataset = new Object[sortRhoMapList.size()][3];
        for(int index =0; index < sortRhoMapList.size(); index++){
            //dataset[index][0] = index+1;
            dataset[index][0] = sortRhoMapList.get(index).getKey();
            dataset[index][1] = snppos.get(sortRhoMapList.get(index).getKey());
            dataset[index][2] = RhoMapPValue[index];
        }

        final JButton SaveButton = new JButton("Save");
        final JButton LoadButton = new JButton("Load");
        JPanel buttonPanel = new JPanel();
        buttonPanel.add(SaveButton);

        final JTable PValuelistTable = new JTable( dataset, columnNames );
        ConfigureFrame.TablelistPanel.removeAll();
        ConfigureFrame.TablelistPanel.revalidate();
        JScrollPane TablelistPanel= new JScrollPane( PValuelistTable );

        ConfigureFrame.TablelistPanel.setLayout(new BorderLayout());
        ConfigureFrame.TablelistPanel.add(TablelistPanel, BorderLayout.CENTER);
        ConfigureFrame.TablelistPanel.add(buttonPanel, BorderLayout.SOUTH);
        ConfigureFrame.TablelistPanel.setVisible(true);

        ConfigureFrame.HotspotPanel.removeAll();
        ConfigureFrame.HotspotPanel.revalidate();
        ConfigureFrame.HotspotPanel.setLayout(new GridLayout(2,1));
        ConfigureFrame.HotspotPanel.add(ConfigureFrame.HistogramPanel);
        ConfigureFrame.HotspotPanel.add(ConfigureFrame.TablelistPanel);
        ConfigureFrame.HotspotPanel.setPreferredSize(new Dimension(300,400));
        ConfigureFrame.configureframe.add(ConfigureFrame.HotspotPanel, BorderLayout.EAST);

        SaveButton.addActionListener(
          new ActionListener(){
                public void actionPerformed(ActionEvent e)
                {
                     JFrame frame = new JFrame();
                     int n = JOptionPane.showConfirmDialog(frame, "Would ou like to save result to a file?",
                    "export PValueList result", JOptionPane.YES_NO_OPTION);
                     if (n == JOptionPane.YES_OPTION) {
                            JFileChooser fc = new JFileChooser();
                            int retVal = fc.showSaveDialog(frame);                 // let frame to become a showDialog
                            if (retVal == JFileChooser.APPROVE_OPTION) {
                                    File resultFile = fc.getSelectedFile();
                                    
                                    fc.setSelectedFile(new File("tableList.csv"));

                                    int nRows = PValuelistTable.getRowCount();
                                    int nCols = PValuelistTable.getColumnCount();
                                    String tablestring = "";
                                    for (int i = 0; i< nRows; i++) {
                                        for (int j = 0; j< nCols; j++) {
                                                tablestring += String.valueOf(PValuelistTable.getValueAt(i, j)) + "\t";
                                        }
                                        tablestring += "\r\n";
                                    }
                                    try{
                                        FileWriter filewriter = new FileWriter(resultFile);
                                        filewriter.write(tablestring);
                                        filewriter.flush();
                                        filewriter.close();
                                    }catch ( IOException ioException ){
                                            System.err.println("Error opening or closing file " + resultFile.toString());
                                    }

                      }
                }
            }
          }
        );

    }


    //
    private void RoMap(double leftboundary,double rightboundary)
    {
        int leftpointID = 0, rightpointID=0;
        if(leftboundary < rightboundary) {
             for(int i = 0; i<snppos.size();i++ )
             {
                   if( (Float)snppos.get(i) > leftboundary){
                        leftpointID = i-1;
                        break;
                   }
             }

             for(int i = snppos.size();i > 0 ;i--)
             {
                    if( (Float)snppos.get(i) < rightboundary ){
                        rightpointID = i+1;
                        break;
                    }
             }

             if(leftpointID != 0 || rightpointID != 0){
               }
           }

           else{
            }

           HotspotWindow.PairRhoMap pairrhomap = sortRhoMapList.get(LocationID).getValue();
           ArrayList<Float> arraylist_0 = pairrhomap.get(0);
           double Ro0 = 0;
           while(leftpointID < rightpointID){
                 Ro0 += arraylist_0.get(leftpointID)*(snppos.get(leftpointID)-snppos.get(leftpointID+1));
           }

           ArrayList<Float> arraylist_1 = pairrhomap.get(1);
           double Ro1 = 0;
           while(leftpointID < rightpointID)
           {
                Ro1 += arraylist_1.get(leftpointID)*(snppos.get(leftpointID)-snppos.get(leftpointID+1));
           }

           double Ro_Diff = (Ro0-Ro1)/(Ro0+Ro1);
    }


    public JFreeChartTest(HashMap<Integer, HotspotWindow.PairRhoMap> SplitRhoMaps, ArrayList<Float> SnpMaf, HotspotWindow hotspotrandomwindow)
    {
      hotspotRandomWindow = hotspotrandomwindow;
      RandomSampleSize = hotspotRandomWindow.GetRandomHashMap().size();
      Ro_Diff_Set = new double [hotspotRandomWindow.GetRandomHashMap().size()];
      AssignSplitRhoMaps(SplitRhoMaps,SnpMaf);
      //------------------------------------------------------------//
      AssignLDHatSeries();
      //------------------------------------------------------------//
      //ListIterator Iterator = splitRhoMaps.;
      XYSeries series = AssginSeries(0,0);
      XYSeries series1 = AssginSeries(0,1);

      XYSeriesCollection dataset = new XYSeriesCollection();
      dataset.addSeries(series);
      dataset.addSeries(series1);
      //dataset.addSeries(LDHatseries);

      if(ConfigureContainer.GetRandomSample() != 0 )
           RandomSampleSize = ConfigureContainer.GetRandomSample();

      Ro_Diff_Target_Set = new double [sortRhoMapList.size()];
      RhoMapPValue = new double [sortRhoMapList.size()];
      PVALUEGENERATION = false;
 
      chart = ChartFactory.createXYLineChart("", "Physical locations(kb)","Recombination rate(cM/Mb)",dataset,PlotOrientation.VERTICAL,true,true,false);
      XYPlot plot = chart.getXYPlot();
      
      XYDataset xydatacatter = createxydataset();
      XYItemRenderer renderer1 = new XYLineAndShapeRenderer(false, true);
      renderer1.setSeriesPaint(0, Color.ORANGE);
      plot.setDataset(1, xydatacatter);
      plot.setRenderer(1, renderer1);
      

      XYDataset xydatacatter2 = createxydataset2(LocationID);
      XYItemRenderer renderer2 = new XYLineAndShapeRenderer(false, true);
      renderer2.setSeriesPaint(0, Color.BLUE);
      plot.setDataset(2, xydatacatter2);
      plot.setRenderer(2, renderer2);

      ValueAxis rangeAxis = plot.getRangeAxis();
      rangeAxis.setUpperBound(80);
      rangeAxis.setLowerBound(-3);

      chartPanel = new ChartPanel(chart);
     
      leftJButton.setEnabled(true);
      rightJButton.setEnabled(true);
      listPValueJButton.setEnabled(false);

      southJPanel.add(wholerhomapcheckBox);
      southJPanel.add(leftJButton);
      southJPanel.add(rightJButton);
      southJPanel.add(hotspotDifferJButton);
      southJPanel.add(lab);
      southJPanel.add(jc);
      

      InitialSlider();
      initialJButton();
      initialJCombo();
 }

    
    
    private void initialJCombo(){
    	Iterator iterator = IndexRhoMapsKeyMap.iterator();
        while(iterator.hasNext())
        {
            String newitem = Float.toString(snppos.get( (Integer)iterator.next()));
            jc.addItem(newitem);
        }
    	
    	jc.addActionListener(
    		    new ActionListener()
    		    {
    			  public void actionPerformed(ActionEvent e)
    			  {
    				  LocationID = jc.getSelectedIndex();
    	                          //if( LocationID < sortRhoMapList.size()-1 )
    	                          //{
    	                                 //LocationID++;
    	                                 XYSeries series1 = AssginSeries(LocationID,0);
    	                                 XYSeries series2 = AssginSeries(LocationID,1);

    	                                 XYSeriesCollection dataset = new XYSeriesCollection();

    	                                 dataset.addSeries(series1);
    	                                 dataset.addSeries(series2);
    	                                 //--------------------------------------------//
    	                                 if(checkboxselected == true)
    	                                            dataset.addSeries(LDHatseries);
    	                                 //--------------------------------------------//
    	                                 chart = ChartFactory.createXYLineChart("","Physical locations(kb)","Recombination rate(cM/Mb)",dataset,PlotOrientation.VERTICAL,true,true,false);
    	                                 XYPlot plot = chart.getXYPlot();

    	                                 XYDataset xydatacatter = createxydataset();
    	                                 XYItemRenderer renderer1 = new XYLineAndShapeRenderer(false, true);
    	                                 renderer1.setSeriesPaint(0, Color.ORANGE);

    	                                 plot.setDataset(1, xydatacatter);
    	                                 plot.setRenderer(1, renderer1);

    	                                 XYDataset xydatacatter2 = createxydataset2(LocationID);
    	                                 XYItemRenderer renderer2 = new XYLineAndShapeRenderer(false, true);
    	                                 renderer2.setSeriesPaint(0, Color.BLUE);
    	                                 plot.setDataset(2, xydatacatter2);
    	                                 plot.setRenderer(2, renderer2);

    	                                 PlotBoundary();

    	                                 ValueAxis rangeAxis = plot.getRangeAxis();
    	                                 rangeAxis.setUpperBound(80);
    	                                 rangeAxis.setLowerBound(-3);

    	                                  chartPanel.removeAll();

    	                                    //chartPanel.repaint();
    	                                  chartPanel.revalidate();
    	                                  chartPanel = null;
    	                                  chartPanel= new ChartPanel(chart);

    	                                  chartPanel.setPreferredSize(new Dimension(600, 350));
    	                                  chartPanel.setMouseZoomable(true, false);

    	                                  ConfigureFrame.JfreechartPanel.removeAll();
    	                                  ConfigureFrame.JfreechartPanel.revalidate();

    	                                  ConfigureFrame.JfreechartPanel.setLayout(new BorderLayout());
    	                                  ConfigureFrame.JfreechartPanel.add(sliderJPanel, BorderLayout.NORTH);
    	                                  ConfigureFrame.JfreechartPanel.add(chartPanel, BorderLayout.CENTER);
    	                                  ConfigureFrame.JfreechartPanel.add(southJPanel, BorderLayout.SOUTH);
    	                                  ConfigureFrame.configureframe.add(ConfigureFrame.JfreechartPanel, BorderLayout.CENTER);

    	                                  if(PVALUEGENERATION == true)
    	                                       DrawHistogramMap(LocationID,Ro_Diff_Set, Ro_Diff_Target_Set[LocationID]);

    	                                  try {
    	                                        Thread.sleep(500);
    	                                    } catch (InterruptedException ex) {
    	                                        Logger.getLogger(JFreeChartTest.class.getName()).log(Level.SEVERE, null, ex);
    	                                    }

    	                                //}
    	                  }
    	              }
    	      );

    }

 private void initialJButton()
 {
     ActionListener sliceActionListener = new ActionListener() {
      public void actionPerformed(ActionEvent actionEvent) {
        AbstractButton RadioButton = (AbstractButton) actionEvent.getSource();
        if(actionEvent.getSource() == LoadLDHatRawRadioButton){

            XYSeries series1 = AssginSeries(LocationID,0);
             XYSeriesCollection dataset = new XYSeriesCollection();

          }
         }
     };

     rightJButton.addActionListener(
	    new ActionListener()
	    {
		  public void actionPerformed(ActionEvent e)
		  {
                          if( LocationID < sortRhoMapList.size()-1 )
                          {
                        	  	LocationID++;
                                 
                                jc.setSelectedIndex(LocationID);
                  
                                 
                                 XYSeries series1 = AssginSeries(LocationID,0);
                                 XYSeries series2 = AssginSeries(LocationID,1);

                                 XYSeriesCollection dataset = new XYSeriesCollection();

                                 dataset.addSeries(series1);
                                 dataset.addSeries(series2);
                                 //--------------------------------------------//
                                 if(checkboxselected == true)
                                            dataset.addSeries(LDHatseries);
                                 //--------------------------------------------//
                                 chart = ChartFactory.createXYLineChart("","Physical locations(kb)","Recombination rate(cM/Mb)",dataset,PlotOrientation.VERTICAL,true,true,false);
                                 XYPlot plot = chart.getXYPlot();

                                 XYDataset xydatacatter = createxydataset();
                                 XYItemRenderer renderer1 = new XYLineAndShapeRenderer(false, true);
                                 renderer1.setSeriesPaint(0, Color.ORANGE);

                                 plot.setDataset(1, xydatacatter);
                                 plot.setRenderer(1, renderer1);

                                 XYDataset xydatacatter2 = createxydataset2(LocationID);
                                 XYItemRenderer renderer2 = new XYLineAndShapeRenderer(false, true);
                                 renderer2.setSeriesPaint(0, Color.BLUE);
                                 plot.setDataset(2, xydatacatter2);
                                 plot.setRenderer(2, renderer2);

                                 PlotBoundary();

                                 ValueAxis rangeAxis = plot.getRangeAxis();
                                 rangeAxis.setUpperBound(80);
                                 rangeAxis.setLowerBound(-3);

                                  chartPanel.removeAll();

                                    //chartPanel.repaint();
                                  chartPanel.revalidate();
                                  chartPanel = null;
                                  chartPanel= new ChartPanel(chart);

                                  chartPanel.setPreferredSize(new Dimension(600, 350));
                                  chartPanel.setMouseZoomable(true, false);

                                  ConfigureFrame.JfreechartPanel.removeAll();
                                  ConfigureFrame.JfreechartPanel.revalidate();

                                  ConfigureFrame.JfreechartPanel.setLayout(new BorderLayout());
                                  ConfigureFrame.JfreechartPanel.add(sliderJPanel, BorderLayout.NORTH);
                                  ConfigureFrame.JfreechartPanel.add(chartPanel, BorderLayout.CENTER);
                                  ConfigureFrame.JfreechartPanel.add(southJPanel, BorderLayout.SOUTH);
                                  ConfigureFrame.configureframe.add(ConfigureFrame.JfreechartPanel, BorderLayout.CENTER);

                                  if(PVALUEGENERATION == true)
                                       DrawHistogramMap(LocationID,Ro_Diff_Set, Ro_Diff_Target_Set[LocationID]);

                                  try {
                                        Thread.sleep(500);
                                    } catch (InterruptedException ex) {
                                        Logger.getLogger(JFreeChartTest.class.getName()).log(Level.SEVERE, null, ex);
                                    }

                                }
                  }
              }
      );

      leftJButton.addActionListener(
			new ActionListener()
			{
				public void actionPerformed(ActionEvent e)
				{
                                    if( LocationID >0 )
                                    {
                                        LocationID--;
                                        jc.setSelectedIndex(LocationID);
                                        XYSeries series1 = AssginSeries(LocationID,0);
                                        XYSeries series2 = AssginSeries(LocationID,1);

                                        XYSeriesCollection dataset = new XYSeriesCollection();

                                        dataset.addSeries(series1);
                                        dataset.addSeries(series2);
                                        //-------------------------------------------//
                                        if(checkboxselected == true)
                                            dataset.addSeries(LDHatseries);
                                        //-------------------------------------------//
                                        chart = ChartFactory.createXYLineChart("", "Physical locations(kb)","Recombination rate(cM/Mb)",dataset,PlotOrientation.VERTICAL,true,true,false);
                                        //JFreeChart jfreechart = ChartFactory.createScatterPlot("SNP locus","x-axis","y-axis", createxydataset(), PlotOrientation.VERTICAL, true,true,false);
                                        XYPlot plot = chart.getXYPlot();

                                        XYDataset xydatacatter = createxydataset();
                                        XYItemRenderer renderer1 = new XYLineAndShapeRenderer(false, true);
                                        renderer1.setSeriesPaint(0, Color.ORANGE);
                                        plot.setDataset(1, xydatacatter);
                                        plot.setRenderer(1, renderer1);

                                        XYDataset xydatacatter2 = createxydataset2(LocationID);
                                        XYItemRenderer renderer2 = new XYLineAndShapeRenderer(false, true);
                                        renderer2.setSeriesPaint(0, Color.BLUE);
                                        plot.setDataset(2, xydatacatter2);
                                        plot.setRenderer(2, renderer2);
                                        PlotBoundary();

                                        ValueAxis rangeAxis = plot.getRangeAxis();
                                        rangeAxis.setUpperBound(80);
                                        rangeAxis.setLowerBound(-3);

                                        chartPanel.removeAll();
                                        chartPanel.revalidate();
                                        chartPanel = null;
                                        chartPanel= new ChartPanel(chart);

                                        ConfigureFrame.JfreechartPanel.removeAll();
                                        ConfigureFrame.JfreechartPanel.revalidate();
                                        ConfigureFrame.JfreechartPanel.setLayout(new BorderLayout());
                                        ConfigureFrame.JfreechartPanel.add(sliderJPanel, BorderLayout.NORTH);
                                        ConfigureFrame.JfreechartPanel.add(chartPanel, BorderLayout.CENTER);
                                        ConfigureFrame.JfreechartPanel.add(southJPanel, BorderLayout.SOUTH);
                                        ConfigureFrame.configureframe.add(ConfigureFrame.JfreechartPanel, BorderLayout.CENTER);
                                        //add(chartPanel, BorderLayout.CENTER);
                                        if(PVALUEGENERATION == true)
                                            DrawHistogramMap(LocationID,Ro_Diff_Set, Ro_Diff_Target_Set[LocationID]);

                                        try {
                                        Thread.sleep(500);
                                        } catch (InterruptedException ex) {
                                            Logger.getLogger(JFreeChartTest.class.getName()).log(Level.SEVERE, null, ex);
                                        }
                                    }
                                }
                        }
      );



      loadRandomResultJButton.addActionListener(
             new ActionListener(){
                    public void actionPerformed(ActionEvent e)
                    {
                          FileDialog filedialog = new FileDialog(loadfileframe,"open final data file dialog",FileDialog.LOAD);
                          filedialog.setVisible(true);
                          String str = filedialog.getDirectory()+ filedialog.getFile();
                          System.out.println(str);
                          FileInputStream inputfile = null;
                          ObjectInputStream objectinput=null;
                          try {
                                 inputfile = new FileInputStream(str.toString());
                                 objectinput = new ObjectInputStream(inputfile);
                                 hotspotRandomWindow = (HotspotWindow) objectinput.readObject();
                                 //RandomSampleSize = hotspotRandomWindow.GetRandomHashMap().size();

                          } catch (FileNotFoundException ex) {
                                    Logger.getLogger(LDsplitRunner.class.getName()).log(Level.SEVERE, null, ex);
                          }catch (IOException ex) {
                                    Logger.getLogger(LDsplitRunner.class.getName()).log(Level.SEVERE, null, ex);
                           }catch (ClassNotFoundException ex) {
                                    Logger.getLogger(LDsplitRunner.class.getName()).log(Level.SEVERE, null, ex);
                           }
                    }
             }
      );

      hotspotDifferJButton.addActionListener(
              new ActionListener(){
                        public void actionPerformed(ActionEvent e)
			{
                           int leftpointID = 0, rightpointID=0;
                           if(leftboundary > rightboundary) {
                                double templeboundary = rightboundary;
                                rightboundary = leftboundary;
                                leftboundary = templeboundary;
                           }

                           for(int i = 0; i<snppos.size();i++ )
                           {
                                 if( (double)snppos.get(i) > leftboundary){
                                      leftpointID = i-1;
                                      break;
                                  }
                           }

                           for(int i = snppos.size()-1;i >= 0 ;i--)
                           {
                                 if( (double)snppos.get(i) < rightboundary ){
                                       rightpointID = i+1;
                                       break;
                                 }
                           }
                           
                           int Ro_Diff_Set_index = 0;
                           RandomSampleSize = 0;
                           HashMap<Integer, HotspotWindow.PairRhoMap> randomhashmap = hotspotRandomWindow.GetRandomHashMap();

                           Iterator iter = randomhashmap.entrySet().iterator();
                           //double [] Ro_Diff_Set = new double [randomhashmap.size()];
                           while (iter.hasNext()) {
                                Map.Entry entry = (Map.Entry) iter.next();
                                Integer key = (Integer)entry.getKey();
                                HotspotWindow.PairRhoMap pairRhomap = (HotspotWindow.PairRhoMap)entry.getValue();
                                // calcuate Ro0 ro map
                                ArrayList<Float> arraylist_0 = pairRhomap.get(0);
                                double Ro0 = 0;
                                int templefpointID = leftpointID;
                                while(templefpointID < rightpointID)
                                {
                                        Ro0 += arraylist_0.get(templefpointID)*(snppos.get(templefpointID+1)-snppos.get(templefpointID));
                                        templefpointID++;
                                }
                                // calcuate Ro0 ro map
                                ArrayList<Float> arraylist_1 = pairRhomap.get(1);
                                double Ro1 = 0;
                                templefpointID = leftpointID;
                                while(templefpointID < rightpointID)
                                {
                                        Ro1 += arraylist_1.get(templefpointID)*(snppos.get(templefpointID+1)-snppos.get(templefpointID));
                                        templefpointID++;
                                }

                                System.out.println(RandomSampleSize+ " "+"Ro0: "+Ro0+" Ro1:"+Ro1);
                                double Ro_Diff = (Ro0-Ro1)/(Ro0+Ro1);
                                Ro_Diff_Set[RandomSampleSize] = Ro_Diff;
                                System.out.println("Ro_Diff_Set"+RandomSampleSize+": "+Ro_Diff);
                                RandomSampleSize++;
                            }

                           for(int i = 0; i< snppos.size();i++)
                           {
                                System.out.println("snppos"+i+" :"+snppos.get(i) );
                           }

                           Ro_Diff_Target_Set = new double [sortRhoMapList.size()];
                           System.out.println("sortRhoMapList.size(): " + sortRhoMapList.size());
                           for(int index = 0;index < sortRhoMapList.size(); index++)
                           {
                               HotspotWindow.PairRhoMap pairrhomap = sortRhoMapList.get(index).getValue();
                               // calcuate Ro0 ro map
                               ArrayList<Float> arraylist_0 = pairrhomap.get(0);
                               double Ro0 = 0;
                               int templefpointID = leftpointID;
                               while(templefpointID < rightpointID)
                               {
                                    Ro0 += arraylist_0.get(templefpointID)*( snppos.get(templefpointID+1)-snppos.get(templefpointID) );
                                    templefpointID++;
                               }
                               // calcuate Ro0 ro map
                               ArrayList<Float> arraylist_1 = pairrhomap.get(1);
                               double Ro1 = 0;
                               templefpointID = leftpointID;
                               while(templefpointID < rightpointID)
                               {
                                    Ro1 += arraylist_1.get(templefpointID)*( snppos.get(templefpointID+1)-snppos.get(templefpointID) );
                                    templefpointID++;
                               }

                               System.out.println(index+" "+"Ro0: "+Ro0+" Ro1:"+Ro1);

                               Ro_Diff_Target_Set[index] =  (Ro0-Ro1)/(Ro0+Ro1);
                           }
                           // testing
                           /*
                           Scanner scanner = new Scanner(System.in);
                           String stringNumbers = scanner.nextLine();
                           System.out.println(stringNumbers);
                           */
                           
                           HotspotWindow.PairRhoMap pairrhomap = sortRhoMapList.get(LocationID).getValue();
                           // calcuate Ro0 ro map
                           ArrayList<Float> arraylist_0 = pairrhomap.get(0);
                           double Ro0 = 0;
                           int templefpointID = leftpointID;
                           while(templefpointID < rightpointID)
                           {
                                Ro0 += arraylist_0.get(templefpointID)*( snppos.get(templefpointID+1)-snppos.get(templefpointID) );
                                templefpointID++;
                           }
                           // calcuate Ro0 ro map
                           ArrayList<Float> arraylist_1 = pairrhomap.get(1);
                           double Ro1 = 0;
                           templefpointID = leftpointID;
                           while(templefpointID < rightpointID)
                           {
                                Ro1 += arraylist_1.get(templefpointID)*( snppos.get(templefpointID+1)-snppos.get(templefpointID) );
                                templefpointID++;
                           }

                           System.out.println("Ro0: "+Ro0+" Ro1:"+Ro1);

                           double Ro_Diff_Target = (Ro0-Ro1)/(Ro0+Ro1);
                           System.out.println("Ro_Diff_Target: "+Ro_Diff_Target);
                           System.out.println("RandomSampleSize: " + RandomSampleSize );
                           P_value_Calculation(Ro_Diff_Set,Ro_Diff_Target);
                           // draw histogram map of series
                           DrawHistogramMap(LocationID,Ro_Diff_Set,Ro_Diff_Target);
                           TableListPlot();

                           leftJButton.setEnabled(true);
                           rightJButton.setEnabled(true);
                           listPValueJButton.setEnabled(true);
                           PVALUEGENERATION = true;

                        }
              }
         );


         wholerhomapcheckBox.addActionListener(
              new ActionListener(){
                  public void actionPerformed(ActionEvent actionEvent)
                  {
                        AbstractButton abstractButton = (AbstractButton)actionEvent.getSource();
                        checkboxselected = abstractButton.getModel().isSelected();
                        XYSeries series1 = AssginSeries(LocationID,0);
                        XYSeries series2 = AssginSeries(LocationID,1);

                        XYSeriesCollection dataset = new XYSeriesCollection();

                        dataset.addSeries(series1);
                        dataset.addSeries(series2);
                        if(checkboxselected == true)
                            dataset.addSeries(LDHatseries);
                        chart = ChartFactory.createXYLineChart("", "Physical locations(kb)","Recombination rate(cM/Mb)",dataset,PlotOrientation.VERTICAL,true,true,false);
                        XYPlot plot = chart.getXYPlot();

                        XYDataset xydatacatter = createxydataset();
                        XYItemRenderer renderer1 = new XYLineAndShapeRenderer(false, true);
                        renderer1.setSeriesPaint(0, Color.ORANGE);
                        plot.setDataset(1, xydatacatter);
                        plot.setRenderer(1, renderer1);

                        XYDataset xydatacatter2 = createxydataset2(LocationID);
                        XYItemRenderer renderer2 = new XYLineAndShapeRenderer(false, true);
                        renderer2.setSeriesPaint(0, Color.BLUE);
                        plot.setDataset(2, xydatacatter2);
                        plot.setRenderer(2, renderer2);
                        PlotBoundary();

                        ValueAxis rangeAxis = plot.getRangeAxis();
                        rangeAxis.setUpperBound(80);
                        rangeAxis.setLowerBound(-3);

                        chartPanel.removeAll();
                        chartPanel.revalidate();
                        chartPanel = null;
                        chartPanel= new ChartPanel(chart);

                        ConfigureFrame.JfreechartPanel.removeAll();
                        ConfigureFrame.JfreechartPanel.revalidate();
                        ConfigureFrame.JfreechartPanel.setLayout(new BorderLayout());
                        ConfigureFrame.JfreechartPanel.add(sliderJPanel, BorderLayout.NORTH);
                        ConfigureFrame.JfreechartPanel.add(chartPanel, BorderLayout.CENTER);
                        ConfigureFrame.JfreechartPanel.add(southJPanel, BorderLayout.SOUTH);
                        ConfigureFrame.configureframe.add(ConfigureFrame.JfreechartPanel, BorderLayout.CENTER);
                  }
         }
        );


         listPValueJButton.addActionListener(
              new ActionListener(){
                        public void actionPerformed(ActionEvent e)
			{
                           int leftpointID = 0, rightpointID=0;
                           if(leftboundary > rightboundary) {
                                double templeboundary = rightboundary;
                                rightboundary = leftboundary;
                                leftboundary = templeboundary;
                           }

                           for(int i = 0; i<snppos.size();i++ )
                           {
                                 if( (double)snppos.get(i) > leftboundary){
                                      leftpointID = i-1;
                                      break;
                                  }
                           }

                           for(int i = snppos.size()-1;i >= 0 ;i--)
                           {
                                 if( (double)snppos.get(i) < rightboundary ){
                                       rightpointID = i+1;
                                       break;
                                 }
                           }

                           System.out.println("leftpointID: "+leftpointID+" rightpointID: "+rightpointID);

                           double [] Ro_Diff_Set = new double [RandomSampleSize]; int Ro_Diff_Set_index = 0;
                           HashMap<Integer, HotspotWindow.PairRhoMap> randomhashmap = hotspotRandomWindow.GetRandomHashMap();

                           System.out.println("the size of randomhashmap: "+randomhashmap.size());

                           Iterator iter = randomhashmap.entrySet().iterator();

                           while (iter.hasNext()) {
                                Map.Entry entry = (Map.Entry) iter.next();
                                Integer key = (Integer)entry.getKey();
                                HotspotWindow.PairRhoMap pairRhomap = (HotspotWindow.PairRhoMap)entry.getValue();
                                // calcuate Ro0 ro map
                                ArrayList<Float> arraylist_0 = pairRhomap.get(0);
                                double Ro0 = 0;
                                int templefpointID = leftpointID;
                                while(templefpointID < rightpointID)
                                {
                                        Ro0 += arraylist_0.get(templefpointID)*(snppos.get(templefpointID+1)-snppos.get(templefpointID));
                                        templefpointID++;
                                }
                                // calcuate Ro0 ro map
                                ArrayList<Float> arraylist_1 = pairRhomap.get(1);
                                double Ro1 = 0;
                                templefpointID = leftpointID;
                                while(templefpointID < rightpointID)
                                {
                                        Ro1 += arraylist_1.get(templefpointID)*(snppos.get(templefpointID+1)-snppos.get(templefpointID));
                                        templefpointID++;
                                }

                                System.out.println(Ro_Diff_Set_index+" "+"Ro0: "+Ro0+" Ro1:"+Ro1);
                                double Ro_Diff = (Ro0-Ro1)/(Ro0+Ro1);
                                Ro_Diff_Set[Ro_Diff_Set_index] = Ro_Diff;
                                System.out.println("Ro_Diff_Set"+Ro_Diff_Set_index+": "+Ro_Diff);
                                Ro_Diff_Set_index++;
                            }
                           Scanner scanner = new Scanner(System.in);
                            String stringNumbers = scanner.nextLine();
                            System.out.println();
                           //calculate mean and SD
                            double Sum = 0, Mean = 0;
                            for(int i =0; i< RandomSampleSize; i++){
                               Sum +=  Ro_Diff_Set[i];
                            }
                            Mean = Sum/(double)RandomSampleSize;

                            double SD = 0; Sum = 0;
                            for(int i =0; i< RandomSampleSize; i++){
                                 Sum += Math.pow((Ro_Diff_Set[i]-Mean),2);
                            }
                            SD = Math.sqrt( (Sum/RandomSampleSize) );

                           // calculate RhoMap P Value
                           double [] RhoMapPValue = new double [sortRhoMapList.size()];
                           System.out.println("number of sortRhoMapList: " + sortRhoMapList.size());
                           for(int index = 0;index < sortRhoMapList.size(); index++)
                           {
                               HotspotWindow.PairRhoMap pairrhomap = sortRhoMapList.get(index).getValue();
                               // calcuate Ro0 ro map
                               ArrayList<Float> arraylist_0 = pairrhomap.get(0);
                               double Ro0 = 0;
                               int templefpointID = leftpointID;
                               while(templefpointID < rightpointID)
                               {
                                    Ro0 += arraylist_0.get(templefpointID)*( snppos.get(templefpointID+1)-snppos.get(templefpointID) );
                                    templefpointID++;
                               }
                               // calcuate Ro0 ro map
                               ArrayList<Float> arraylist_1 = pairrhomap.get(1);
                               double Ro1 = 0;
                               templefpointID = leftpointID;
                               while(templefpointID < rightpointID)
                               {
                                    Ro1 += arraylist_1.get(templefpointID)*( snppos.get(templefpointID+1)-snppos.get(templefpointID) );
                                    templefpointID++;
                               }

                               System.out.println(index+ " Ro0: "+Ro0+" Ro1:"+Ro1);

                               double Ro_Diff_Target = (Ro0-Ro1)/(Ro0+Ro1);
                               System.out.println("Ro_Diff_Target: "+Ro_Diff_Target);

                               double pvalue = Pnorm.pnorm_calculate(Ro_Diff_Target, Mean, SD);

                               if(pvalue > 0.5)
                                    pvalue = 1 - pvalue;
                               pvalue *= 2;

                               RhoMapPValue[index] = pvalue;

                            }

                            final String[] columnNames = {"Index", "SNP Location", "P value"};
                            final Object[][] dataset = new Object[sortRhoMapList.size()][3];
                            for(int index =0; index < sortRhoMapList.size(); index++){
                                dataset[index][0] = sortRhoMapList.get(index).getKey();
                                dataset[index][1] = snppos.get(sortRhoMapList.get(index).getKey());
                                dataset[index][2] = RhoMapPValue[index];
                            }

                            final JTable PValuelistTable = new JTable( dataset, columnNames );
                            
                            ConfigureFrame.TablelistPanel.removeAll();
                            ConfigureFrame.TablelistPanel.revalidate();
                            ConfigureFrame.TablelistPanel.setVisible(true);

                            ConfigureFrame.HotspotPanel.removeAll();
                            ConfigureFrame.HotspotPanel.revalidate();
                            ConfigureFrame.HotspotPanel.setLayout(new GridLayout(2,1));
                            ConfigureFrame.HotspotPanel.add(ConfigureFrame.HistogramPanel);
                            ConfigureFrame.HotspotPanel.add(ConfigureFrame.TablelistPanel);
                            ConfigureFrame.HotspotPanel.setPreferredSize(new Dimension(300,400));
                            ConfigureFrame.configureframe.add(ConfigureFrame.HotspotPanel, BorderLayout.EAST);

                            final JButton SaveButton = new JButton("Save");
                            final JButton LoadButton = new JButton("Load");
                            JPanel buttonPanel = new JPanel();
                            buttonPanel.add(SaveButton);
                            buttonPanel.add(LoadButton);

                            SaveButton.addActionListener(
                              new ActionListener(){
                                    public void actionPerformed(ActionEvent e)
                                    {
                                         JFrame frame = new JFrame();
                                         int n = JOptionPane.showConfirmDialog(frame, "Would ou like to save result to a file?",
					"export PValueList result", JOptionPane.YES_NO_OPTION);
                                         if (n == JOptionPane.YES_OPTION) {
                                                JFileChooser fc = new JFileChooser();
                                                fc.setSelectedFile(new File("ListTable.csv"));
                                                int retVal = fc.showSaveDialog(frame);                 // let frame to become a showDialog
                                                if (retVal == JFileChooser.APPROVE_OPTION) {
                                                        File resultFile = fc.getSelectedFile();

                                                try {
                                                    BufferedWriter bw = new BufferedWriter(
                                                            new FileWriter(resultFile.toString()));

                                                    TableColumnModel columnModel = PValuelistTable.getColumnModel();
                                                    StringBuilder builder = new StringBuilder();

                                                    // output boundary
                                                    builder.append("left boundary: ").append(showValleft.getText()).append(",");
                                                    builder.append("right boundary: ").append(showValright.getText());
                                                    bw.write(builder.toString());
                                                    bw.newLine();
                                                    bw.flush();
                                                    builder.setLength(0);
                                                    
                                                    for (int i = 0, colum = PValuelistTable.getColumnCount(); i < colum; i++) {
                                                        builder.append(columnModel.getColumn(i).getHeaderValue()).append(",");
                                                    }
                                                    builder.deleteCharAt(builder.length() - 1);
                                                    bw.write(builder.toString());
                                                    bw.newLine();
                                                    bw.flush();
                                                    
                                                    for (int i = 0, colum = PValuelistTable.getRowCount(); i < colum; i++) {
                                                        builder.setLength(0);
                                                        for (int j = 0, m = PValuelistTable.getColumnCount(); j < m; j++) {
                                                            builder.append(PValuelistTable.getValueAt(i,j)).append(",");
                                                        }
                                                        builder.deleteCharAt(builder.length() - 1);
                                                        bw.write(builder.toString());
                                                        if (i != n - 1) {
                                                            bw.newLine();
                                                        }
                                                        bw.flush();
                                                    }
                                                    bw.close();
                                                } catch (FileNotFoundException e1) {
                                                    e1.printStackTrace();
                                                } catch (IOException e1) {
                                                    e1.printStackTrace();
                                                }

                                          }
                                    }
                                }
                              }
                            );

                            LoadButton.addActionListener(
                               new ActionListener(){
                                   public void actionPerformed(ActionEvent e)
                                   {
                                          FileDialog filedialog = new FileDialog(loadfileframe,"open PValue data file dialog",FileDialog.LOAD);
                                          filedialog.setVisible(true);
                                          String str = filedialog.getDirectory()+ filedialog.getFile();
                                          System.out.println(str);
                                          FileInputStream inputfile = null;
                                          ObjectInputStream objectinput=null;
                                          try {
                                                 inputfile = new FileInputStream(str.toString());
                                                 objectinput = new ObjectInputStream(inputfile);
                                                 Object[][] datasetload =  (Object[][])objectinput.readObject();
                                                 JTable PValuelistTable = new JTable( datasetload, columnNames );
                                                 JScrollPane PValuelistPane = new JScrollPane( PValuelistTable );

                                                 JFrame jframeTable = new JFrame();
                                                 jframeTable.add(PValuelistPane);
                                                 jframeTable.pack();
                                                 jframeTable.setVisible(true);

                                          } catch (FileNotFoundException ex) {
                                                    Logger.getLogger(LDsplitRunner.class.getName()).log(Level.SEVERE, null, ex);
                                          }catch (IOException ex) {
                                                    Logger.getLogger(LDsplitRunner.class.getName()).log(Level.SEVERE, null, ex);
                                           }catch (ClassNotFoundException ex) {
                                                    Logger.getLogger(LDsplitRunner.class.getName()).log(Level.SEVERE, null, ex);
                                           }

                                   }
                               }
                            );

                        }
              }
         );

 }

}

