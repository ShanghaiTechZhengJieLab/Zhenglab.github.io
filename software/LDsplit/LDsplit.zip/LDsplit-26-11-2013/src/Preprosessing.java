/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package ld_split_graphy_interface;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;
import java.io.StringReader;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;
/**
 *
 * @author Yang Peng
 */
public class Preprosessing {

    ArrayList<String> hapSeq = new ArrayList<String>();
    // physical positions of SNPs
    ArrayList<Float> snpPos = new ArrayList<Float>(); // in unit of kb

    public boolean loadSnp(String sitesFileName, String locsFileName) throws FileNotFoundException
    {
		// parse sites files
		File sitesFile = new File(sitesFileName);
		Scanner scanner = new Scanner(new FileReader(sitesFile));
		int numSeq = 0;
		try {
			if (scanner.hasNext()) {
				String line = scanner.nextLine();
				String[] items = line.split("\\s+");
				numSeq = Integer.parseInt(items[0]);
			}

			int seqCount = 0;
			while (scanner.hasNext()) {
				String line = scanner.nextLine();
				if ( line.startsWith(">") == false ) { // not a headline
					hapSeq.add(line);
					seqCount ++;
				}
				assert(seqCount == numSeq);
			}
		} finally {
			scanner.close();
		}

		// parse locs file
		File locsFile = new File(locsFileName);
		scanner = new Scanner(new FileReader(locsFile));
		try {
			int numSnp = 0;
			if (scanner.hasNext()) {
				String line = scanner.nextLine();
				String[] items = line.split("\\s+");
				numSnp = Integer.parseInt(items[0]);
			}

			int snpCount = 0;
			while (scanner.hasNext()) {
				String line = scanner.nextLine();
				snpPos.add(new Float(line));
				snpCount ++;
			}
			assert(numSnp == snpCount);
		} finally {
			scanner.close();
		}

		// check consistency of data
		Iterator<String> itr = hapSeq.iterator();
		while (itr.hasNext()) {
			String hap = (String)itr.next();

			if (hap.length() != snpPos.size()) {
				System.out.println("Haplotype length unequal to number of SNP");
				return false;
			}
		}
		return true;
	}

    public void Transformation() throws FileNotFoundException
    {
          test_snp();
         for(int i = 0; i< snpPos.size(); i++){
              splitPopu(i);
          }

    }

    public void test_snp()
    {
		System.out.println("number of haplotypes: " + hapSeq.size());
		for (int i = 0; i < hapSeq.size(); ++i) {
                        System.out.println(">Seq"+String.valueOf(i));
			System.out.println(hapSeq.get(i));
		}

		System.out.println("SNP locations: ");
		for (int i=0; i < snpPos.size(); ++i) {
			System.out.println(snpPos.get(i).toString());
		}
   }

    private void splitPopu(int snpId)
    {
	      //char OneType = hapSeq.get(0).charAt(snpId);
              HashMap<Character, Integer> SNIP_Percentage_Statistics = new HashMap<Character, Integer>();
              for (int i = 0; i < hapSeq.size(); ++i) {
			String hap = hapSeq.get(i);
                        char  charsequence[] = hap.toCharArray();
			char allele = hap.charAt(snpId); 
                        if(allele != '0' && allele != '1')
                        {
                                if(allele == 'N' || allele =='?'){
                                     Random generator = new Random();
                                     charsequence[snpId] = Character.forDigit(generator.nextInt(2), 10);
                                }else {
                                    if(SNIP_Percentage_Statistics.get(charsequence[snpId]) == null)
                                        SNIP_Percentage_Statistics.put(charsequence[snpId], 0);
                                    Integer count = SNIP_Percentage_Statistics.get(charsequence[snpId]);
                                    count ++;
                                    SNIP_Percentage_Statistics.put(charsequence[snpId], count);
                                }
                         }

                         hap  = String.valueOf(charsequence);
                         hapSeq.set(i, hap);
	       }

              System.out.println("dasdsadadadad");

              if(SNIP_Percentage_Statistics.size() == 2 || SNIP_Percentage_Statistics.size() == 1){
                  Iterator Iter = SNIP_Percentage_Statistics.keySet().iterator();
                  Character FirstKey = (Character)Iter.next();
                  for (int i = 0; i < hapSeq.size(); ++i) {
                       String hap = hapSeq.get(i);
                       char  charsequence[] = hap.toCharArray();
                       char allele = hap.charAt(snpId);
                       if(allele != '0' && allele !='1'){
                           if(allele == FirstKey){
                                charsequence[snpId] = '0';
                           }
                           else {
                                charsequence[snpId] = '1';
                           }
                       }
                       hap  = String.valueOf(charsequence);
                       hapSeq.set(i, hap);
                  }
              }
              else{
                  Iterator Iter = SNIP_Percentage_Statistics.keySet().iterator();
                  double Minimal_Percentage = 1.0;
                  Character Minimal_Char = ' ';
                  
                  while (Iter.hasNext()) {
                        Character key = (Character)Iter.next();
                        Integer value = SNIP_Percentage_Statistics.get(key);
                        if( ((double)value/(double)hapSeq.size()) < Minimal_Percentage){
                            Minimal_Percentage = (double)value/(double)hapSeq.size();
                            Minimal_Char = key;
                      }
                  }

                  if(Minimal_Percentage > 0.05){
                      for (int i = 0; i < hapSeq.size(); ++i) {
                           String hap = hapSeq.get(i);
                           char  charsequence[] = hap.toCharArray();
                           charsequence[snpId] = '0';
                           hap  = String.valueOf(charsequence);
                           hapSeq.set(i, hap);
                      }
                  }else{
                      int j = 0;
                      while(hapSeq.get(j).charAt(snpId) == '0' || hapSeq.get(j).charAt(snpId) == '1'
                              || hapSeq.get(j).charAt(snpId) == Minimal_Char)
                          j++;

                      Character First_Char = hapSeq.get(j).charAt(snpId);

                      for (int i = 0; i < hapSeq.size(); ++i) {
                           String hap = hapSeq.get(i);
                           char charsequence[] = hap.toCharArray();
                           if(charsequence[snpId] != '0' &&  charsequence[snpId] != '1'){
                               if(charsequence[snpId] == Minimal_Char){
                                   Random generator = new Random();
                                   charsequence[snpId] = Character.forDigit(generator.nextInt(2), 10);
                               }
                               else if(charsequence[snpId] == First_Char){
                                   charsequence[snpId] = '1';
                               }else{
                                   charsequence[snpId] = '0';
                               }
                          }
                          hap  = String.valueOf(charsequence);
                          hapSeq.set(i, hap);
                      }

                  }

              }
              System.out.println("finishing....");
              test_snp();
      }

}
